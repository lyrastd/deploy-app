package com.example.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

class SpeechHelper(
    private val context: Context,
    private val onTranscript: (String) -> Unit,
    private val onListeningChange: (Boolean) -> Unit,
    private val onError: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private val recognizerIntent: Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Reconhecimento de voz não está disponível.")
            return
        }

        stopListening()

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        onListeningChange(true)
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    
                    override fun onEndOfSpeech() {
                        onListeningChange(false)
                    }

                    override fun onError(error: Int) {
                        onListeningChange(false)
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Erro de gravação de áudio."
                            SpeechRecognizer.ERROR_CLIENT -> "Conexão de áudio ocupada."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissão de microfone ausente."
                            SpeechRecognizer.ERROR_NETWORK -> "Erro de conexão à internet."
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Limite de tempo de rede atingido."
                            SpeechRecognizer.ERROR_NO_MATCH -> "Repita o comando, por favor."
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Assistente ocupado, tente de novo."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nenhum comando de voz detectado."
                            else -> "Falha no reconhecimento de voz ($error)."
                        }
                        onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotBlank()) {
                            onTranscript(text)
                        } else {
                            onError("Não entendi o comando.")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                startListening(recognizerIntent)
            }
        } catch (e: Exception) {
            Log.e("LyraSpeechHelper", "Speech recognizer crash prevention", e)
            onError("Erro ao iniciar microfone: ${e.localizedMessage}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.let {
                it.stopListening()
                it.destroy()
            }
        } catch (e: Exception) {
            Log.e("LyraSpeechHelper", "Speech recognizer cleanup crash prevention", e)
        }
        speechRecognizer = null
        onListeningChange(false)
    }
}
