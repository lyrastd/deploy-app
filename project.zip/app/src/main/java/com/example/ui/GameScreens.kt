package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.BorderStroke
import kotlin.random.Random
import androidx.compose.ui.layout.layout
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.activity.compose.BackHandler
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.PlayerProfile
import com.example.ui.theme.*
import com.example.game.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.exp
import androidx.compose.ui.graphics.asImageBitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

// Static Avatar configurations
val AVATAR_EMOJIS = listOf("👵", "🥋", "🧑‍🔬", "🤠", "🐼", "🤖", "🔥", "⚡")
val AVATAR_LABELS = listOf(
    "Dona Rute (Chinelada)",
    "Ninja do SBP",
    "Dr. Cientista",
    "Xerife do Sertão",
    "Urso Esmagador",
    "Exterminador 3000",
    "Mestre do Fogo",
    "Dedo de Raio"
)

// Splatter Skin Theme color profiles
fun getSplatColor(skinId: String): Color {
    return when (skinId) {
        "green" -> Color(0xFF39FF14) // Neon toxic slime
        "blue" -> Color(0xFF00E5FF) // Plasma blue
        "rainbow" -> Color(0xFFFF4081) // Neon Pink (Dynamic gradient color during drawing)
        else -> Color(0xFFD32F2F) // Classic Red guts
    }
}

// Pure function for stable randomness without object allocation
fun getStableRandom(seed: Long, index: Int): Float {
    // 1. Thoroughly mix the seed so sequential seeds yield wildly different initial states
    var x = (seed xor 0x5DEECE66DL) * 25214903917L + index * 1103515245L + 12345L
    x = x and 0x7fffffffL
    // 2. High-entropy integer hashing (MurmurHash3 finalizer) to scramble bits perfectly
    x = (x xor (x ushr 16)) * 0x85ebca6bL
    x = x and 0x7fffffffL
    x = (x xor (x ushr 13)) * 0xc2b2ae35L
    x = x and 0x7fffffffL
    x = x xor (x ushr 16)
    return (x and 0x7fffffffL).toFloat() / 2147483647f
}

fun androidx.compose.ui.graphics.drawscope.DrawScope.drawProceduralLeaf(center: Offset, scale: Float, rotationDegrees: Float, baseColor: Color) {
    drawContext.canvas.save()
    drawContext.canvas.translate(center.x, center.y)
    drawContext.canvas.rotate(rotationDegrees)
    drawContext.canvas.scale(scale, scale)

    val leafPath = Path().apply {
        moveTo(0f, -60f)
        quadraticTo(45f, -20f, 0f, 60f)
        quadraticTo(-45f, -20f, 0f, -60f)
        close()
    }

    val shadowPath = Path().apply {
        moveTo(8f, -45f)
        quadraticTo(45f + 8f, -20f + 15f, 8f, 75f)
        quadraticTo(-45f + 8f, -20f + 15f, 8f, -45f)
        close()
    }
    
    drawPath(path = shadowPath, color = Color(0x12000000))
    drawPath(path = leafPath, color = baseColor)

    drawLine(
        color = baseColor.copy(alpha = 0.5f),
        start = Offset(0f, -60f),
        end = Offset(0f, 60f),
        strokeWidth = 3f
    )

    drawContext.canvas.restore()
}

@Composable
fun SplatterItem(splat: SplatterInstance) {
    val col = remember { getSplatColor(splat.skinId) }
    
    // Drive continuous high-precision time state
    val timeNow = remember { mutableStateOf(System.currentTimeMillis()) }
    
    LaunchedEffect(splat.id) {
        val animationEndTime = splat.timestamp + 3500L
        while (System.currentTimeMillis() < animationEndTime) {
            withFrameMillis { frameTime ->
                timeNow.value = System.currentTimeMillis()
            }
        }
        timeNow.value = splat.timestamp + 3500L
    }
    
    // We position the center box at (splat.x, splat.y)
    // We use a larger Canvas size to allow independent droplets and gravity drips to expand fully without clipping bounds!
    Box(
        modifier = Modifier
            .layoutRelativePosition(splat.x, splat.y)
            .wrapContentSize(),
        contentAlignment = Alignment.Center
    ) {
        val canvasSizeDp = (splat.sizeDp * 2.5f).dp
        Canvas(modifier = Modifier.size(canvasSizeDp)) {
            // Our base insect radius scale for reference mapping
            val r = (splat.sizeDp.dp.toPx() / 2f)
            val center = Offset(size.width / 2f, size.height / 2f)
            
            // Calculate elapsed time and dynamic physics factors
            val ageMs = (timeNow.value - splat.timestamp).coerceAtLeast(0L)
            
            // Explosion phase (0 to 300ms) with high initial friction
            val expProgress = (ageMs / 300f).coerceIn(0f, 1f)
            val expEase = 1f - exp(-expProgress * 4.5f) // Exponential deceleration
            
            // Central pool progressive soft-expansion
            val poolProgress = (ageMs / 200f).coerceIn(0f, 1f)
            val poolScale = 1f - (1f - poolProgress) * (1f - poolProgress)
            
            // Gravity slow-dripping phase (300ms to 3.5 seconds)
            val gravityTime = (ageMs - 300L).coerceAtLeast(0L)
            val gravityProgress = (gravityTime.toFloat() / 3200f).coerceIn(0f, 1f) // 0f to 1f
            
            // Slowly slide central pool down a bit
            val poolDripY = r * 0.12f * gravityProgress
            
            // 1. Draw overlapping organic pools for an irregular, highly realistic shape
            val poolSegments = 5 + (getStableRandom(splat.id, 1000) * 3).toInt() // 5 to 8 overlapping circles
            for (i in 0 until poolSegments) {
                val segmentSeed = splat.id + i * 37
                // Random angle and distance offset from center for organic asymmetrical layout
                val pAngle = getStableRandom(segmentSeed, 10) * 2 * Math.PI.toFloat()
                val pMaxDist = getStableRandom(segmentSeed, 20) * r * 0.28f
                val pDist = pMaxDist * expEase
                
                val pOx = cos(pAngle) * pDist
                val pOy = sin(pAngle) * pDist + poolDripY
                
                val pBaseRadius = r * (0.38f + getStableRandom(segmentSeed, 30) * 0.32f)
                val pRadius = pBaseRadius * poolScale
                
                drawCircle(
                    color = col,
                    radius = pRadius,
                    center = Offset(center.x + pOx, center.y + pOy)
                )
            }
            
            // 2. Heavy flowing gravity streams dripping downwards from the main pool
            val heavyDripCount = 2 + (getStableRandom(splat.id, 1100) * 2).toInt() // 2 to 3 main drips
            for (j in 0 until heavyDripCount) {
                val dripSeed = splat.id + j * 73
                // Position stream symmetrically around the bottom bounds of the central pool
                val rootXOffset = (getStableRandom(dripSeed, 40) - 0.5f) * r * 0.65f
                val rootYOffset = getStableRandom(dripSeed, 50) * r * 0.18f + poolDripY
                
                val dripFactor = 0.25f + getStableRandom(dripSeed, 60) * 1.1f
                val currentDripLength = r * 0.8f * gravityProgress * dripFactor
                
                val start = Offset(center.x + rootXOffset, center.y + rootYOffset)
                val end = Offset(center.x + rootXOffset, center.y + rootYOffset + currentDripLength)
                
                val dripWidth = r * (0.05f + getStableRandom(dripSeed, 70) * 0.07f) * (1f - gravityProgress * 0.2f)
                
                if (gravityProgress > 0.01f) {
                    drawLine(
                        color = col,
                        start = start,
                        end = end,
                        strokeWidth = dripWidth,
                        cap = StrokeCap.Round
                    )
                    // Draw a neat sliding drop head at the tip
                    drawCircle(
                        color = col,
                        radius = dripWidth * 0.85f,
                        center = end
                    )
                }
            }
            
            // 3. Draw high-pressure rapid spurts / spikes
            val spurtCount = 3 + (getStableRandom(splat.id, 1200) * 3).toInt() // 3 to 5 rays
            for (i in 0 until spurtCount) {
                val raySeed = splat.id + i * 51
                val sAngle = getStableRandom(raySeed, 80) * 2 * Math.PI.toFloat()
                
                val sStartDist = r * 0.25f
                val sMaxLen = r * (0.55f + getStableRandom(raySeed, 90) * 0.7f)
                
                val sEndDist = sStartDist + (sMaxLen - sStartDist) * expEase
                val sStartDistCurrent = sStartDist + (sMaxLen * 0.25f - sStartDist) * (ageMs / 300f).coerceIn(0f, 1f)
                
                if (sEndDist > sStartDistCurrent) {
                    val sStartX = center.x + cos(sAngle) * sStartDistCurrent
                    val sStartY = center.y + sin(sAngle) * sStartDistCurrent + poolDripY
                    val sEndX = center.x + cos(sAngle) * sEndDist
                    val sEndY = center.y + sin(sAngle) * sEndDist + poolDripY
                    
                    val sWidth = r * (0.045f + getStableRandom(raySeed, 100) * 0.075f) * (1f - expProgress * 0.25f)
                    drawLine(
                        color = col,
                        start = Offset(sStartX, sStartY),
                        end = Offset(sEndX, sEndY),
                        strokeWidth = sWidth,
                        cap = StrokeCap.Round
                    )
                }
            }
            
            // 4. Satellite fine spray (Respingos) flying out and dripping independently!
            // Up to 25 completely independent satellite micro-droplets
            val dropletCount = 12 + (getStableRandom(splat.id, 1300) * 13).toInt() 
            for (i in 0 until dropletCount) {
                val dropSeed = splat.id + i * 19
                val dAngle = getStableRandom(dropSeed, 110) * 2 * Math.PI.toFloat()
                // Maximum launch distance of each individual droplet
                val dMaxFlightDist = r * (0.5f + getStableRandom(dropSeed, 120) * 1.55f)
                val dFlightDist = dMaxFlightDist * expEase
                
                // Flight landing coords
                val dLandX = center.x + cos(dAngle) * dFlightDist
                val dLandY = center.y + sin(dAngle) * dFlightDist
                
                // Check if this specific droplet drips down due to gravity landing
                val willDrip = getStableRandom(dropSeed, 130) > 0.44f
                val dripVelocity = if (willDrip) (0.35f + getStableRandom(dropSeed, 140) * 1.5f) else 0.04f
                val dDripY = r * 0.85f * gravityProgress * dripVelocity
                
                val dCurrentX = dLandX
                val dCurrentY = dLandY + dDripY
                
                val dBaseRad = r * (0.024f + getStableRandom(dropSeed, 150) * 0.066f)
                // Droplets shrink slightly as they flow down, leaving a thin trail
                val dRad = dBaseRad * (1f - gravityProgress * 0.3f)
                
                if (willDrip && gravityProgress > 0.05f) {
                    // Draw a thin sliding trail line behind the droplet
                    drawLine(
                        color = col.copy(alpha = 0.55f * (1f - gravityProgress * 0.45f)),
                        start = Offset(dLandX, dLandY),
                        end = Offset(dCurrentX, dCurrentY),
                        strokeWidth = dRad * 0.5f,
                        cap = StrokeCap.Round
                    )
                }
                
                drawCircle(
                    color = col,
                    radius = dRad,
                    center = Offset(dCurrentX, dCurrentY)
                )
            }
            
            // 5. Draw visceral details in the core for organic premium depth
            val innerCol = if (splat.bugType == BugType.CENTIPEDE || splat.bugType == BugType.SCORPION) {
                Color(0xFF39FF14) // Radioactive neon green venom!
            } else {
                when (splat.skinId) {
                    "green" -> Color(0xFFD4FF2D) // Neon green guts
                    "blue" -> Color(0xFFC0F0FF) // Cyber neon glow
                    "rainbow" -> Color(0xFFFFF760) // Vivid neon highlight
                    else -> Color(0xFFFF7E7E) // Visceral pinkish-orange red
                }
            }
            
            val visCount = 2 + (getStableRandom(splat.id, 1400) * 2).toInt() // 2 to 3 spots
            for (i in 0 until visCount) {
                val visSeed = splat.id + i * 29
                val vAngle = getStableRandom(visSeed, 160) * 2 * Math.PI.toFloat()
                val vMaxDist = getStableRandom(visSeed, 170) * r * 0.16f
                val vDist = vMaxDist * expEase
                
                val vOx = cos(vAngle) * vDist
                val vOy = sin(vAngle) * vDist + poolDripY
                
                val vTargetRadius = r * (0.12f + getStableRandom(visSeed, 180) * 0.14f)
                val vRadius = vTargetRadius * poolScale
                
                drawCircle(
                    color = innerCol,
                    radius = vRadius,
                    center = Offset(center.x + vOx, center.y + vOy)
                )
            }
            
            // 6. Scattered shattered carapaces and crushed exoskeleton parts
            val fragCol = when (splat.bugType) {
                BugType.ANT -> Color(0xFF2A1612)
                BugType.TERMITE -> Color(0xFF513A2F)
                BugType.COCKROACH -> Color(0xFF422105)
                BugType.SPIDER -> Color(0xFF1B1B1B)
                BugType.BEETLE -> Color(0xFF0F2610)
                BugType.WASP -> Color(0xFF212121)
                BugType.SCORPION -> Color(0xFF1C1324) // Dark violet-charcoal exoskeleton
                BugType.CENTIPEDE -> Color(0xFF0A3317) // Toxic green carapace
            }
            
            val totalFrags = when (splat.bugType) {
                BugType.SPIDER -> 4 + (getStableRandom(splat.id, 1500) * 3).toInt() // many legs
                BugType.BEETLE -> 3 + (getStableRandom(splat.id, 1500) * 3).toInt() // heavy shell shards
                else -> 2 + (getStableRandom(splat.id, 1500) * 3).toInt()
            }
            
            // Exoskeletons scatter and slowly slide down slightly less than liquid
            val fragDripY = poolDripY * 0.35f
            
            for (i in 0 until totalFrags) {
                val fragSeed = splat.id + i * 43
                val fAngle = getStableRandom(fragSeed, 190) * 2 * Math.PI.toFloat()
                val fMaxDist = r * (0.2f + getStableRandom(fragSeed, 200) * 0.55f)
                val fDist = fMaxDist * expEase
                
                val fx = center.x + cos(fAngle) * fDist
                val fy = center.y + sin(fAngle) * fDist + fragDripY
                
                val representation = (getStableRandom(fragSeed, 210) * 3).toInt()
                if (splat.bugType == BugType.SPIDER && representation == 0) {
                    // Spider leg segment, bent
                    val jointAngle = fAngle + 0.8f + getStableRandom(fragSeed, 220) * 1.5f
                    val len1 = r * (0.16f + getStableRandom(fragSeed, 230) * 0.16f) * poolScale
                    val len2 = r * (0.11f + getStableRandom(fragSeed, 240) * 0.13f) * poolScale
                    
                    val midX = fx + cos(fAngle) * len1
                    val midY = fy + sin(fAngle) * len1
                    val endX = midX + cos(jointAngle) * len2
                    val endY = midY + sin(jointAngle) * len2
                    
                    drawLine(
                        color = fragCol,
                        start = Offset(fx, fy),
                        end = Offset(midX, midY),
                        strokeWidth = r * 0.04f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = fragCol,
                        start = Offset(midX, midY),
                        end = Offset(endX, endY),
                        strokeWidth = r * 0.035f,
                        cap = StrokeCap.Round
                    )
                } else if (splat.bugType == BugType.BEETLE && representation == 1) {
                    // Carapace shards
                    val shardRad = r * (0.11f + getStableRandom(fragSeed, 250) * 0.13f) * poolScale
                    drawCircle(color = fragCol, radius = shardRad, center = Offset(fx, fy))
                    drawLine(
                        color = Color.White.copy(alpha = 0.42f),
                        start = Offset(fx - shardRad * 0.4f, fy - shardRad * 0.4f),
                        end = Offset(fx + shardRad * 0.3f, fy + shardRad * 0.3f),
                        strokeWidth = r * 0.018f
                    )
                } else {
                    // Generic segment
                    if (getStableRandom(fragSeed, 260) > 0.52f) {
                        val ovalRad = r * (0.06f + getStableRandom(fragSeed, 270) * 0.12f) * poolScale
                        drawCircle(color = fragCol, radius = ovalRad, center = Offset(fx, fy))
                    } else {
                        val sLen = r * (0.12f + getStableRandom(fragSeed, 280) * 0.15f) * poolScale
                        drawLine(
                            color = fragCol,
                            start = Offset(fx, fy),
                            end = Offset(fx + cos(fAngle + 1f) * sLen, fy + sin(fAngle + 1f) * sLen),
                            strokeWidth = r * 0.035f,
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
            
            // 7. Extra wasp-specific yellow warning stripes
            if (splat.bugType == BugType.WASP) {
                val wSeed = splat.id + 1600
                val wAngle = getStableRandom(wSeed, 300) * 2 * Math.PI.toFloat()
                val wMaxDist = r * 0.3f
                val wDist = wMaxDist * expEase
                
                val wx = center.x + cos(wAngle) * wDist
                val wy = center.y + sin(wAngle) * wDist + fragDripY
                
                val waspScale = (ageMs / 250f).coerceIn(0f, 1f)
                val wRad = r * (0.05f + getStableRandom(wSeed, 310) * 0.08f) * (1f - (1f - waspScale) * (1f - waspScale))
                
                drawCircle(
                    color = Color(0xFFFFD600), // Wasp yellow highlight
                    radius = wRad,
                    center = Offset(wx, wy)
                )
            }
        }
    }
}

// Map skin ID to printable label
val SKINS_CATALOG = listOf(
    Triple("default", "Sangue Orgânico 🔴", 0),
    Triple("green", "Gosma Ácida Toxica 🟢", 150),
    Triple("blue", "Plasma Radioativo 🔵", 300),
    Triple("rainbow", "Festa Arco-Íris 🌈", 500)
)

@Composable
fun BugSmasherNavigation(viewModel: InsectGameViewModel) {
    val navController = rememberNavController()
    val gameState by viewModel.currentGameState.collectAsStateWithLifecycle()

    // Observe game state to auto-navigate to / from "game" screen instantly
    LaunchedEffect(gameState) {
        when (gameState) {
            is GameState.Playing -> {
                if (navController.currentDestination?.route != "game") {
                    navController.navigate("game") {
                        popUpTo("menu") { saveState = true }
                        launchSingleTop = true
                    }
                }
            }
            is GameState.Idle -> {
                // Return to menu from game safely without breaking navigation graph
                if (navController.currentDestination?.route == "game") {
                    navController.popBackStack()
                }
            }
            else -> {}
        }
    }

    NavHost(
        navController = navController,
        startDestination = "menu"
    ) {
        composable("menu") {
            MainMenuScreen(viewModel = viewModel, navController = navController)
        }
        composable("profile") {
            ProfileScreen(viewModel = viewModel, navController = navController)
        }
        composable("levels") {
            LevelSelectScreen(viewModel = viewModel, navController = navController)
        }
        composable("leaderboard") {
            LeaderboardScreen(viewModel = viewModel, navController = navController)
        }
        composable("shop") {
            ShopScreen(viewModel = viewModel, navController = navController)
        }
        composable("game") {
            GameScreen(viewModel = viewModel, navController = navController)
        }
        composable("competitive") {
            CompetitiveScreen(viewModel = viewModel, navController = navController)
        }
        composable("about") {
            AboutScreen(viewModel = viewModel, navController = navController)
        }
    }
}

// ----------------- MAIN MENU SCREEN -----------------
@Composable
fun MainMenuScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val maybeProfile by viewModel.currentProfileState.collectAsStateWithLifecycle()
    val soundMuted by viewModel.soundMuted.collectAsStateWithLifecycle()
    
    // Aesthetic insect animation in the menu background
    var wigglingAngle by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            wigglingAngle += 5f
            delay(50)
        }
    }

    Scaffold { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(SoftEggshell, TiledStageBackground)
                    )
                )
        ) {
            // Draw stylized crawling bugs behind menu cards for playfulness
            Canvas(modifier = Modifier.fillMaxSize()) {
                val menuBugX = size.width * 0.15f
                val menuBugY = size.height * 0.35f + sin(wigglingAngle * 0.05f) * 60f
                val rotation = 45f + sin(wigglingAngle * 0.08f) * 15f
                
                // Draw decorative ant using theme color with alpha
                drawCircle(
                    color = ForestGreen.copy(alpha = 0.15f),
                    center = Offset(menuBugX, menuBugY),
                    radius = 35f
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header bar (settings and active account tag)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile button representing current user
                    val profile = maybeProfile
                    val onlineUser by viewModel.firebaseUsername.collectAsStateWithLifecycle()
                    if (profile != null) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SageGreenLight,
                            border = BorderStroke(1.dp, BorderLightSystem),
                            modifier = Modifier
                                .clickable { 
                                    viewModel.playButtonClick()
                                    navController.navigate("profile") 
                                }
                                .testTag("menu_profile_badge")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = AVATAR_EMOJIS.getOrElse(profile.avatarId) { "👵" },
                                    fontSize = 24.sp
                                )
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = profile.nickname,
                                            color = SageGreenDense,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        if (profile.onlineUsername != null) {
                                            Text("🛡️", fontSize = 12.sp)
                                        }
                                    }
                                    Text(
                                        text = "🪙 ${profile.gold} | FASE ${profile.levelReached}",
                                        color = MutedGreyGreen,
                                        fontSize = 11.sp
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = "Mudar Contas",
                                    tint = ForestGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    } else {
                        // Creating default loading placeholder if database not ready
                        CircularProgressIndicator(color = ForestGreen, modifier = Modifier.size(24.dp))
                    }

                    // Sound and Session controllers
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (onlineUser != null) {
                            IconButton(
                                onClick = { viewModel.logoutUser() },
                                modifier = Modifier
                                    .background(Color(0xFFFCE8E6), CircleShape)
                                    .border(1.dp, Color(0xFFF5C2C1), CircleShape)
                                    .testTag("menu_logout_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = "Deslogar da conta",
                                    tint = Color(0xFFD04444)
                                )
                            }
                        }

                        // Audio control
                        IconButton(
                            onClick = { viewModel.toggleMute() },
                            modifier = Modifier
                                .background(SageGreenLight, CircleShape)
                                .border(1.dp, BorderLightSystem, CircleShape)
                                .testTag("mute_audio_button")
                        ) {
                            Icon(
                                imageVector = if (soundMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                contentDescription = "Mudo / Ativar Som",
                                tint = SageGreenDense
                            )
                        }

                        // Info / About Us control
                        IconButton(
                            onClick = {
                                viewModel.playButtonClick()
                                navController.navigate("about")
                            },
                            modifier = Modifier
                                .background(SageGreenLight, CircleShape)
                                .border(1.dp, BorderLightSystem, CircleShape)
                                .testTag("menu_about_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Sobre Nós",
                                tint = SageGreenDense
                            )
                        }
                    }
                }

                // Game Title Arcade Label
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 16.dp)
                ) {
                    Text(
                        text = "🪲 ESMAgA 🪳",
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        color = ForestGreen,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.offset(y = (-4).dp)
                    )
                    Text(
                        text = "INS ETOS !",
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Black,
                        color = DarkForestText,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SageGreenLight,
                        border = BorderStroke(1.dp, BorderLightSystem),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        Text(
                            text = "Ataque Tóxico com o Dedo",
                            color = SageGreenDense,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }

                // Modes Grid Blocks
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Campaign mode card
                    Button(
                        onClick = {
                            viewModel.playButtonClick()
                            navController.navigate("levels")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(84.dp)
                            .shadow(8.dp)
                            .testTag("mode_campaign_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🗺️", fontSize = 36.sp)
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = "Campanha Singleplayer",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Atravesse fases táticas com objetivos e chefes",
                                    fontSize = 12.sp,
                                    color = SoftEggshell
                                )
                            }
                        }
                    }

                    // Endless ranked survival
                    Button(
                        onClick = {
                            viewModel.playButtonClick()
                            viewModel.startEndless()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SageGreenLight),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.5.dp, ForestGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(84.dp)
                            .shadow(4.dp)
                            .testTag("mode_endless_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🕒", fontSize = 36.sp)
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = "Sobrevivência Ranqueada",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = SageGreenDense
                                )
                                Text(
                                    text = "Esmague sem parar e concorra no Leaderboard",
                                    fontSize = 12.sp,
                                    color = MutedGreyGreen
                                )
                            }
                        }
                    }

                    // Competitive online betting mode
                    Button(
                        onClick = {
                            viewModel.playButtonClick()
                            navController.navigate("competitive")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5A93B)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(84.dp)
                            .shadow(4.dp)
                            .testTag("mode_competitive_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🛡️", fontSize = 36.sp)
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = "Modo Competitivo 🏆",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Desafie pessoas reais apostando dinheiro do jogo!",
                                    fontSize = 12.sp,
                                    color = SoftEggshell
                                )
                            }
                        }
                    }
                }

                // Submenu footer buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Button(
                        onClick = { 
                            viewModel.playButtonClick()
                            navController.navigate("leaderboard") 
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, BorderLightSystem),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .testTag("menu_ranking_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Leaderboard, null, tint = DarkForestText)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rankings", color = DarkForestText, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { 
                            viewModel.playButtonClick()
                            navController.navigate("shop") 
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, BorderLightSystem),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .testTag("menu_shop_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.ShoppingCart, null, tint = DarkForestText)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Shopping", color = DarkForestText, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ----------------- PROFILE MANAGEMENT SCREEN -----------------
@Composable
fun ProfileScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val profilesList by viewModel.repository.allProfiles.collectAsStateWithLifecycle(emptyList())
    var isCreatingNew by remember { mutableStateOf(false) }
    var nicknameInput by remember { mutableStateOf("") }
    var selectedAvatarIdx by remember { mutableStateOf(0) }

    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Gerenciar Contas de Jogadores", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.playButtonClick(); navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Voltar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SoftEggshell,
                    titleContentColor = DarkForestText,
                    navigationIconContentColor = DarkForestText
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(SoftEggshell)
        ) {
            if (isCreatingNew) {
                // Account creations block
                Card(
                     modifier = Modifier
                         .fillMaxWidth()
                         .padding(16.dp)
                         .align(Alignment.Center)
                         .testTag("account_creation_card"),
                     shape = RoundedCornerShape(16.dp),
                     colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                     border = BorderStroke(1.dp, BorderLightSystem)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Nova Conta de Treino 🛠️",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkForestText
                        )

                        OutlinedTextField(
                            value = nicknameInput,
                            onValueChange = { if (it.length <= 15) nicknameInput = it },
                            label = { Text("Nome do Jogador") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = DarkForestText,
                                unfocusedTextColor = DarkForestText,
                                focusedLabelColor = ForestGreen,
                                unfocusedLabelColor = MutedGreyGreen,
                                focusedBorderColor = ForestGreen,
                                unfocusedBorderColor = BorderLightSystem
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("nickname_input_field")
                        )

                        Text(
                            text = "Selecione seu Avatar/Meme:",
                            color = ForestGreen,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        // Horizontal avatars listing
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(AVATAR_EMOJIS.size) { idx ->
                                val active = selectedAvatarIdx == idx
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (active) ForestGreen else SoftEggshell)
                                        .border(
                                            width = 2.dp,
                                            color = if (active) ForestGreen else BorderLightSystem,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { selectedAvatarIdx = idx }
                                        .testTag("avatar_select_$idx"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(AVATAR_EMOJIS[idx], fontSize = 28.sp)
                                        Text(
                                            text = AVATAR_LABELS[idx].split(" ").first(),
                                            color = if (active) Color.White else DarkForestText,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.playButtonClick(); isCreatingNew = false },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ForestGreen),
                                border = BorderStroke(1.5.dp, ForestGreen)
                            ) {
                                Text("Cancelar")
                            }

                            Button(
                                onClick = {
                                    viewModel.playButtonClick()
                                    if (nicknameInput.isNotBlank()) {
                                        viewModel.createAndSwitchProfile(nicknameInput, selectedAvatarIdx)
                                        nicknameInput = ""
                                        isCreatingNew = false
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("confirm_create_account_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                            ) {
                                Text("Salvar Conta", color = Color.White)
                            }
                        }
                    }
                }
            } else {
                // Profile selector listing
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Compartilhe este aparelho! Registre diferentes contas, acumule pontuações individuais e dispute no ranking de esmagamento.",
                        color = MutedGreyGreen,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Online User / Logout Action
                    val onlineUser by viewModel.firebaseUsername.collectAsStateWithLifecycle()
                    if (onlineUser != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .testTag("online_status_card"),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0D4)), // Warm highlight
                            border = BorderStroke(1.5.dp, Color(0xFFE5A93B)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("🛡️", fontSize = 28.sp)
                                    Column {
                                        Text(
                                            text = "CONTA ONLINE CONECTADA",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFC08010)
                                        )
                                        Text(
                                            text = "@$onlineUser",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DarkForestText
                                        )
                                    }
                                }

                                Button(
                                    onClick = { viewModel.logoutUser() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD04444)),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("profile_logout_button")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ExitToApp,
                                            contentDescription = "Deslogar",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text("Deslogar", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { viewModel.playButtonClick(); isCreatingNew = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .testTag("add_account_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Criar Nova Conta / Atleta", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(profilesList) { profile ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("profile_card_${profile.nickname}"),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (profile.isCurrentUser) SageGreenLight else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                shape = RoundedCornerShape(12.dp),
                                border = if (profile.isCurrentUser) {
                                    BorderStroke(1.5.dp, ForestGreen)
                                } else {
                                    BorderStroke(1.dp, BorderLightSystem)
                                }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(AVATAR_EMOJIS.getOrElse(profile.avatarId) { "👵" }, fontSize = 32.sp)
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = profile.nickname,
                                                    color = DarkForestText,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp
                                                )
                                                if (profile.onlineUsername != null) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = CircleShape,
                                                        color = Color(0xFFFFF0D4),
                                                        border = BorderStroke(1.dp, Color(0xFFE5A93B))
                                                    ) {
                                                        Text(
                                                            text = "Nuvem ☁️",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFC08010),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                if (profile.isCurrentUser) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = CircleShape,
                                                        color = ForestGreen
                                                    ) {
                                                        Text(
                                                            text = "Ativo",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Text(
                                                text = "🔥 Recorde: ${profile.highScoreEndless} pont | 🪙 ${profile.gold} moedas",
                                                color = MutedGreyGreen,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "🕷️ Total Esmagado: ${profile.totalSquashed} insetos",
                                                color = SageGreenDense.copy(alpha = 0.8f),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        // Activate button
                                        if (!profile.isCurrentUser) {
                                            IconButton(
                                                onClick = { viewModel.playButtonClick(); viewModel.switchActiveProfile(profile.id) },
                                                modifier = Modifier.background(SageGreenLight, CircleShape)
                                            ) {
                                                Icon(Icons.Default.Check, "Ativar", tint = ForestGreen)
                                            }
                                        }
                                        // Delete button (can delete only if more than 1 profile exists or it's not active)
                                        if (profilesList.size > 1 && !profile.isCurrentUser) {
                                            IconButton(
                                                onClick = { viewModel.playButtonClick(); viewModel.deleteProfile(profile.id) }
                                            ) {
                                                Icon(Icons.Default.Delete, "Excluir", tint = Color(0xFFBF616A))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------- LEVEL ROADMAP SELECT SCREEN (SINGLEPLAYER) -----------------
@Composable
fun LevelSelectScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val activeProfile by viewModel.currentProfileState.collectAsStateWithLifecycle()
    
    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Desafios da Campanha 🗺️", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.playButtonClick(); navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Voltar", tint = DarkForestText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SoftEggshell, titleContentColor = DarkForestText)
            )
        }
    ) { padding ->
        val currentMaxReached = activeProfile?.levelReached ?: 1

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(SoftEggshell)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "Vença cada fase esmagando as pragas taticas dentro do tempo. Moedas bônus valiosas são dadas na primeira vitória de cada patamar!",
                        color = MutedGreyGreen,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                items(LevelCatalog.levels) { level ->
                    val isUnlocked = level.id <= currentMaxReached
                    
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .alpha(if (isUnlocked) 1.0f else 0.5f)
                            .testTag("level_select_card_${level.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUnlocked) SageGreenLight else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        border = if (isUnlocked && level.id == currentMaxReached) {
                            BorderStroke(2.dp, ForestGreen)
                        } else {
                            BorderStroke(1.dp, BorderLightSystem)
                        },
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(if (isUnlocked) ForestGreen else Color.Gray),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(level.id.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                    Text(
                                        text = level.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = if (isUnlocked) DarkForestText else Color.Gray
                                    )
                                }

                                if (!isUnlocked) {
                                    Icon(Icons.Default.Lock, "Bloqueado", tint = Color.Gray)
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color.White,
                                        border = BorderStroke(1.dp, ForestGreen)
                                    ) {
                                        Text(
                                            text = "Metas: ${level.targetScore} PTS",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ForestGreen,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Text(
                                text = level.description,
                                color = MutedGreyGreen,
                                fontSize = 12.sp
                            )

                            HorizontalDivider(color = BorderLightSystem)

                            // Scenario description + Reward pill
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(level.scenario.emojiBackground, fontSize = 12.sp)
                                    Text(
                                        text = "Cenário: ${level.scenario.displayName}",
                                        fontSize = 11.sp,
                                        color = MutedGreyGreen
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("🪙", fontSize = 12.sp)
                                    Text(
                                        text = "+${level.goldReward} Bônus",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SageGreenDense
                                    )
                                }
                            }

                            if (isUnlocked) {
                                Button(
                                    onClick = { viewModel.playButtonClick(); viewModel.startCampaign(level) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("play_campaign_level_${level.id}"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Esmagar Agora!", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------- LEADERBOARD SCREEN -----------------
@Composable
fun LeaderboardScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val context = LocalContext.current
    var webViewUrl by remember { mutableStateOf<String?>(null) }
    val isOnline = viewModel.firebaseUsername.collectAsStateWithLifecycle().value != null
    val localProfiles by viewModel.repository.allProfiles.collectAsStateWithLifecycle(emptyList())
    val globalProfiles by viewModel.globalRankingList.collectAsStateWithLifecycle()

    val profiles = if (isOnline) globalProfiles else localProfiles

    LaunchedEffect(isOnline) {
        if (isOnline) {
            viewModel.refreshGlobalRanking()
        }
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Competição Ranqueada 🏆", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.playButtonClick(); navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Voltar", tint = DarkForestText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SoftEggshell, titleContentColor = DarkForestText)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(SoftEggshell)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Intro banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                    border = BorderStroke(1.dp, BorderLightSystem)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "👑 Liga de Combate de Insetos",
                            color = SageGreenDense,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Dispute pontuação com as outras contas locais registradas no seu celular e com outros assassinos profissionais virtuais!",
                            color = MutedGreyGreen,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Leaderboard header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Posição / Atleta", fontSize = 12.sp, color = SageGreenDense, fontWeight = FontWeight.Bold)
                    Text("Pontos Sobrevivência", fontSize = 12.sp, color = SageGreenDense, fontWeight = FontWeight.Bold)
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(profiles.size) { index ->
                        val item = profiles[index]
                        
                        val rankNum = index + 1
                        val medal = when (rankNum) {
                            1 -> "🥇 "
                            2 -> "🥈 "
                            3 -> "🥉 "
                            else -> "⚓ "
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("leaderboard_user_${item.nickname}"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (item.isCurrentUser) SageGreenLight else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = if (item.isCurrentUser) {
                                BorderStroke(1.5.dp, ForestGreen)
                            } else {
                                BorderStroke(1.dp, BorderLightSystem)
                            }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = "$rankNum",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp,
                                        color = if (item.isCurrentUser) ForestGreen else DarkForestText,
                                        modifier = Modifier.width(20.dp)
                                    )
                                    Text(AVATAR_EMOJIS.getOrElse(item.avatarId) { "👵" }, fontSize = 28.sp)
                                    
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = item.nickname,
                                                color = DarkForestText,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            if (item.isCurrentUser) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "(Você)",
                                                    fontSize = 10.sp,
                                                    color = ForestGreen
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Esmagou: ${item.totalSquashed} bichos",
                                            fontSize = 11.sp,
                                            color = MutedGreyGreen
                                        )
                                        if (!item.instagram.isNullOrBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.clickable {
                                                    viewModel.playButtonClick()
                                                    webViewUrl = "https://www.instagram.com/${item.instagram}"
                                                }
                                            ) {
                                                Text("📸", fontSize = 10.sp)
                                                Text(
                                                    text = "@${item.instagram}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFC13584)
                                                )
                                            }
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "$medal${item.highScoreEndless} pts",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp,
                                        color = ForestGreen
                                    )
                                    Text(
                                        text = "Fases: ${item.levelReached}/8",
                                        fontSize = 10.sp,
                                        color = SageGreenDense.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (webViewUrl != null) {
            InAppWebViewDialog(
                url = webViewUrl!!,
                onDismiss = { webViewUrl = null }
            )
        }
    }
}

// ----------------- SHOP INTEGRATED SCREEN -----------------
@Composable
fun ShopScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val activeProfile by viewModel.currentProfileState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableStateOf(0) } // 0: items, 1: scenarios, 2: look

    val profile = activeProfile

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Arcade Armaria & Shopping 🪙", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.playButtonClick(); navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Voltar", tint = DarkForestText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SoftEggshell, titleContentColor = DarkForestText)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(SoftEggshell)
        ) {
            if (profile == null) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = ForestGreen)
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Coin Counter Banner
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                        border = BorderStroke(1.dp, BorderLightSystem)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Saldo de Moedas", fontSize = 12.sp, color = MutedGreyGreen)
                                Text("🪙 ${profile.gold} Moedas", fontSize = 20.sp, fontWeight = FontWeight.Black, color = ForestGreen)
                            }
                            Text(
                                text = "Compre powerups para te ajudarem nas fases difíceis ou mude a gosma de estourar!",
                                fontSize = 11.sp,
                                color = SageGreenDense.copy(alpha = 0.8f),
                                modifier = Modifier.width(180.dp),
                                textAlign = TextAlign.End
                            )
                        }
                    }

                    // Tabs row
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = SoftEggshell,
                        contentColor = ForestGreen
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { viewModel.playButtonClick(); selectedTab = 0 },
                            text = { Text("Arsenal Powerups", fontWeight = FontWeight.Bold) },
                            selectedContentColor = ForestGreen,
                            unselectedContentColor = MutedGreyGreen
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { viewModel.playButtonClick(); selectedTab = 1 },
                            text = { Text("Cenários", fontWeight = FontWeight.Bold) },
                            selectedContentColor = ForestGreen,
                            unselectedContentColor = MutedGreyGreen
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { viewModel.playButtonClick(); selectedTab = 2 },
                            text = { Text("Estilos Gosma", fontWeight = FontWeight.Bold) },
                            selectedContentColor = ForestGreen,
                            unselectedContentColor = MutedGreyGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(modifier = Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        when (selectedTab) {
                            0 -> {
                                // Arsenal list
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    // 1. Insecticide spray
                                    ShopItemCard(
                                        title = "Dedetização SBP 💨",
                                        desc = "Sufoca e esmaga instantaneamente TODOS os insetos comuns presentes no visor do celular.",
                                        price = 45,
                                        ownedNum = profile.sprayCount,
                                        userGold = profile.gold,
                                        onBuy = { viewModel.playButtonClick(); viewModel.buyPowerup("spray", 45) },
                                        testTag = "buy_spray_card"
                                    )

                                    // 2. Ice freeze clock
                                    ShopItemCard(
                                        title = "Névoa Glacial / Relógio de Gelo ❄️",
                                        desc = "Garante 6 segundos de tempo congelado onde as pragas rastejam 70% mais lentas.",
                                        price = 35,
                                        ownedNum = profile.freezeCount,
                                        userGold = profile.gold,
                                        onBuy = { viewModel.playButtonClick(); viewModel.buyPowerup("freeze", 35) },
                                        testTag = "buy_freeze_card"
                                    )

                                    // 3. Heavy Stomp Shoes
                                    ShopItemCard(
                                        title = "Super Sapato de Chumbo 🥾",
                                        desc = "Dobra o tamanho dos seus dedos por 8 segundos. Mata escaravelhos couraçados com 1 toque!",
                                        price = 50,
                                        ownedNum = profile.tripleSquashCount,
                                        userGold = profile.gold,
                                        onBuy = { viewModel.playButtonClick(); viewModel.buyPowerup("shoe", 50) },
                                        testTag = "buy_shoe_card"
                                    )
                                }
                            }
                            1 -> {
                                // Scenarios
                                val unlockedScns = profile.purchasedScenarios.split(",")
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    for (scn in ScenarioType.values()) {
                                        val isOwned = unlockedScns.contains(scn.id)
                                        val isSelected = profile.selectedScenario == scn.id
                                        
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                                            border = BorderStroke(1.dp, BorderLightSystem)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text(scn.emojiBackground, fontSize = 24.sp)
                                                        Text(scn.displayName, fontWeight = FontWeight.Bold, color = DarkForestText, fontSize = 16.sp)
                                                    }
                                                    Text(scn.description, fontSize = 11.sp, color = MutedGreyGreen)
                                                }

                                                Spacer(modifier = Modifier.width(8.dp))

                                                if (isOwned) {
                                                    if (isSelected) {
                                                        Button(
                                                            onClick = {},
                                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF81C784)),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text("Equipado ✓", fontSize = 11.sp, color = Color.Black)
                                                        }
                                                    } else {
                                                        OutlinedButton(
                                                            onClick = { viewModel.playButtonClick(); viewModel.selectScenario(scn.id) },
                                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ForestGreen),
                                                            border = BorderStroke(1.5.dp, ForestGreen),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text("Equipar", fontSize = 11.sp)
                                                        }
                                                    }
                                                } else {
                                                    Button(
                                                        onClick = { viewModel.playButtonClick(); viewModel.buyScenario(scn.id, scn.cost) },
                                                        enabled = profile.gold >= scn.cost,
                                                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Text("🪙 ${scn.cost}", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            2 -> {
                                // Splat skins
                                val unlockedSkins = profile.purchasedSkins.split(",")
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    for (skin in SKINS_CATALOG) {
                                        val skinId = skin.first
                                        val label = skin.second
                                        val price = skin.third
                                        val isOwned = unlockedSkins.contains(skinId)
                                        val isSelected = profile.selectedSkin == skinId

                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                                            border = BorderStroke(1.dp, BorderLightSystem)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                                                    // Little splash color demo
                                                    Box(
                                                        modifier = Modifier
                                                            .size(24.dp)
                                                            .clip(CircleShape)
                                                            .background(getSplatColor(skinId))
                                                    )
                                                    Column {
                                                        Text(label, fontWeight = FontWeight.Bold, color = DarkForestText, fontSize = 15.sp)
                                                        Text("Explode os insetos com estéticas personalizadas.", fontSize = 11.sp, color = MutedGreyGreen)
                                                    }
                                                }
                                                
                                                if (isOwned) {
                                                    if (isSelected) {
                                                        Button(
                                                            onClick = {},
                                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF81C784)),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text("Equipado ✓", fontSize = 11.sp, color = Color.Black)
                                                        }
                                                    } else {
                                                        OutlinedButton(
                                                            onClick = { viewModel.playButtonClick(); viewModel.selectSkin(skinId) },
                                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text("Equipar", fontSize = 11.sp)
                                                        }
                                                    }
                                                } else {
                                                    Button(
                                                        onClick = { viewModel.playButtonClick(); viewModel.buySkin(skinId, price) },
                                                        enabled = profile.gold >= price,
                                                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Text("🪙 $price", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShopItemCard(
    title: String,
    desc: String,
    price: Int,
    ownedNum: Int,
    userGold: Int,
    onBuy: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = SageGreenLight),
        border = BorderStroke(1.dp, BorderLightSystem)
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = DarkForestText, fontSize = 15.sp)
                Text(desc, fontSize = 11.sp, color = MutedGreyGreen)
                Text("Estoque no bolso: $ownedNum unidades", fontSize = 10.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onBuy,
                enabled = userGold >= price,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Comprar", fontSize = 10.sp, color = Color.White)
                    Text("🪙 $price", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
            }
        }
    }
}

// ----------------- COMPREHENSIVE ARCADE GAME SCREEN -----------------
@Composable
fun GameScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val activeProfile by viewModel.currentProfileState.collectAsStateWithLifecycle()
    val gameState by viewModel.currentGameState.collectAsStateWithLifecycle()
    val score by viewModel.score.collectAsStateWithLifecycle()
    val goldEarned by viewModel.goldEarned.collectAsStateWithLifecycle()
    val lives by viewModel.lives.collectAsStateWithLifecycle()
    val timeLeft by viewModel.timeLeftSec.collectAsStateWithLifecycle()

    val bugsList by viewModel.activeBugs.collectAsStateWithLifecycle()
    val splattersList by viewModel.activeSplatters.collectAsStateWithLifecycle()
    val vfxList by viewModel.activeVFX.collectAsStateWithLifecycle()
    val frameTick by viewModel.frameTick.collectAsStateWithLifecycle()

    val p = activeProfile
    val chosenScenario by viewModel.currentGameScenario.collectAsStateWithLifecycle()
    
    val isHurtFlame by viewModel.isScreenHurt.collectAsStateWithLifecycle()
    val isShakingScreen by viewModel.isScreenShake.collectAsStateWithLifecycle()
    val isScreenPoisoned by viewModel.isScreenPoisoned.collectAsStateWithLifecycle()
    val poisonCdRemainingMs by viewModel.poisonDurationLeftMs.collectAsStateWithLifecycle()

    val freezeCdRemainingMs by viewModel.freezeDurationLeftMs.collectAsStateWithLifecycle()
    val shoeCdRemainingMs by viewModel.shoeDurationLeftMs.collectAsStateWithLifecycle()

    val activeDrops by viewModel.activeDrops.collectAsStateWithLifecycle()
    val poisonClouds by viewModel.poisonClouds.collectAsStateWithLifecycle()
    val activePoisonGunTimeLeftMs by viewModel.activePoisonGunTimeLeftMs.collectAsStateWithLifecycle()
    val activePoisonTrailTimeLeftMs by viewModel.activePoisonTrailTimeLeftMs.collectAsStateWithLifecycle()

    BackHandler {
        if (gameState is GameState.Playing) {
            viewModel.pauseGame()
        } else {
            viewModel.quitToMenu()
        }
    }

    // Main UI-synchronized game frame loop driving high-frequency updates on VSYNC pulses!
    LaunchedEffect(gameState) {
        if (gameState is com.example.game.GameState.Playing) {
            var lastTime = System.currentTimeMillis()
            var smoothedDeltaMs = 16.67f
            while (true) {
                withFrameMillis { frameTime ->
                    val now = System.currentTimeMillis()
                    val actualDelta = now - lastTime
                    lastTime = now
                    
                    // Cap elapsed milliseconds to prevent sudden large leaping steps during frame-rate micro-drops
                    val rawDeltaMs = actualDelta.coerceIn(4L, 40L)
                    
                    // Low-pass running average filter (80% previous frame weight, 20% current frame weight)
                    // This guarantees linear, completely jitter-free movement on all 60Hz, 90Hz, and 120Hz screens
                    smoothedDeltaMs = smoothedDeltaMs * 0.8f + rawDeltaMs * 0.2f
                    
                    viewModel.gameTick(smoothedDeltaMs.toLong())
                }
            }
        }
    }

    // Smooth screen shake offsets
    val shakeOffset = if (isShakingScreen) {
        Random.nextInt(-12, 12).toFloat()
    } else 0f

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // Display level configuration (Campaign or Endless metrics)
    val levelName = when (gameState) {
        is GameState.Playing -> {
            if (viewModel.timeLeftSec.value > 1000) "MODO SOBREVIVÊNCIA 🏆" else "FASE ${LevelCatalog.levels.find { it.timeLimitSec == viewModel.timeLeftSec.value || it.targetScore == 150 /* approximate target check */ }?.id ?: 1} 🗺️"
        }
        else -> "Esmagamento"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(chosenScenario.primaryColor))
            .pointerInput(activePoisonGunTimeLeftMs, activePoisonTrailTimeLeftMs) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val dragActive = activePoisonGunTimeLeftMs > 0L || activePoisonTrailTimeLeftMs > 0L
                        event.changes.forEach { change ->
                            if (change.pressed) {
                                val relX = change.position.x / size.width
                                val relY = change.position.y / size.height
                                if (dragActive) {
                                    viewModel.handlePointerInput(relX, relY, isDragging = change.previousPressed)
                                } else if (!change.previousPressed) {
                                    viewModel.handlePointerInput(relX, relY, isDragging = false)
                                }
                                change.consume()
                            }
                        }
                    }
                }
            }
            .testTag("game_tapping_box")
    ) {
        // 1. Draw custom scenario grids / checkers on the canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = shakeOffset.dp)
        ) {
            when (chosenScenario) {
                ScenarioType.KITCHEN -> {
                    val cols = 4
                    val rows = 8
                    val tileWidth = size.width / cols
                    val tileHeight = size.height / rows
                    val groutColor = Color(0xFFCED2C4)

                    for (col in 0 until cols) {
                        for (row in 0 until rows) {
                            val left = col * tileWidth
                            val top = row * tileHeight
                            
                            drawRect(
                                color = Color(0xFFE2E3DD),
                                topLeft = Offset(left, top),
                                size = Size(tileWidth, tileHeight)
                            )
                            drawRect(
                                color = Color(0x28FFFFFF),
                                topLeft = Offset(left + 2f, top + 2f),
                                size = Size(tileWidth - 4f, tileHeight - 4f)
                            )
                            drawRect(
                                color = Color(0x1F000000),
                                topLeft = Offset(left + tileWidth - 8f, top + 2f),
                                size = Size(6f, tileHeight - 4f)
                            )
                            drawRect(
                                color = Color(0x1F000000),
                                topLeft = Offset(left + 2f, top + tileHeight - 8f),
                                size = Size(tileWidth - 4f, 6f)
                            )
                        }
                    }
                    
                    for (x in 1 until cols) {
                        drawLine(
                            color = groutColor,
                            start = Offset(x * tileWidth, 0f),
                            end = Offset(x * tileWidth, size.height),
                            strokeWidth = 6f
                        )
                    }
                    for (y in 1 until rows) {
                        drawLine(
                            color = groutColor,
                            start = Offset(0f, y * tileHeight),
                            end = Offset(size.width, y * tileHeight),
                            strokeWidth = 6f
                        )
                    }
                }
                ScenarioType.PICNIC -> {
                    val squareSize = size.width / 6f
                    val redColor = Color(0x50E57373)

                    for (col in 0..(size.width / squareSize).toInt() + 1) {
                        if (col % 2 == 0) {
                            drawRect(
                                color = redColor,
                                topLeft = Offset(col * squareSize, 0f),
                                size = Size(squareSize, size.height)
                            )
                        }
                    }

                    for (row in 0..(size.height / squareSize).toInt() + 1) {
                        if (row % 2 == 0) {
                            drawRect(
                                color = redColor,
                                topLeft = Offset(0f, row * squareSize),
                                size = Size(size.width, squareSize)
                            )
                        }
                    }

                    for (col in 0..(size.width / (squareSize / 3f)).toInt() + 1) {
                        drawLine(
                            color = Color(0x0C000000),
                            start = Offset(col * (squareSize / 3f), 0f),
                            end = Offset(col * (squareSize / 3f), size.height),
                            strokeWidth = 1.5f
                        )
                    }
                    for (row in 0..(size.height / (squareSize / 3f)).toInt() + 1) {
                        drawLine(
                            color = Color(0x0C000000),
                            start = Offset(0f, row * (squareSize / 3f)),
                            end = Offset(size.width, row * (squareSize / 3f)),
                            strokeWidth = 1.5f
                        )
                    }
                }
                ScenarioType.GARDEN -> {
                    val soilBrush = Brush.linearGradient(
                        colors = listOf(Color(0xFFE8F5E9), Color(0xFFC8E6C9)),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    )
                    drawRect(brush = soilBrush)

                    drawProceduralLeaf(Offset(size.width * 0.20f, size.height * 0.15f), 1.1f, 32f, Color(0xFF81C784))
                    drawProceduralLeaf(Offset(size.width * 0.85f, size.height * 0.28f), 1.3f, -45f, Color(0xFF4CAF50))
                    drawProceduralLeaf(Offset(size.width * 0.38f, size.height * 0.48f), 0.9f, 115f, Color(0xFF66BB6A))
                    drawProceduralLeaf(Offset(size.width * 0.76f, size.height * 0.62f), 1.2f, -80f, Color(0xFF388E3C))
                    drawProceduralLeaf(Offset(size.width * 0.25f, size.height * 0.82f), 1.0f, 18f, Color(0xFF2E7D32))
                    drawProceduralLeaf(Offset(size.width * 0.82f, size.height * 0.90f), 1.15f, 55f, Color(0xFF66BB6A))

                    val grassColor = Color(0x401B5E20)
                    for (i in 0..8) {
                        val startX = size.width * (i / 8f)
                        val gp = Path().apply {
                            moveTo(startX, size.height)
                            quadraticTo(
                                startX - 30f, size.height - 180f,
                                startX - 55f - (i * 5f), size.height - 300f
                            )
                        }
                        drawPath(path = gp, color = grassColor, style = Stroke(width = 6f))
                    }

                    val dappledSunlight1 = Brush.radialGradient(
                        colors = listOf(Color(0x35FFFDE7), Color.Transparent),
                        center = Offset(size.width * 0.3f, size.height * 0.2f),
                        radius = 280f
                    )
                    val dappledSunlight2 = Brush.radialGradient(
                        colors = listOf(Color(0x2AFFFDE7), Color.Transparent),
                        center = Offset(size.width * 0.75f, size.height * 0.65f),
                        radius = 380f
                    )
                    drawCircle(brush = dappledSunlight1, radius = 280f, center = Offset(size.width * 0.3f, size.height * 0.2f))
                    drawCircle(brush = dappledSunlight2, radius = 380f, center = Offset(size.width * 0.75f, size.height * 0.65f))
                }
                ScenarioType.SEWER -> {
                    val rowCount = 16
                    val rowHeight = size.height / rowCount
                    val colCount = 4
                    val brickWidth = size.width / colCount
                    val groutColor = Color(0xFF141714)

                    for (r in 0..rowCount) {
                        val y = r * rowHeight
                        drawLine(
                            color = groutColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 6f
                        )
                        
                        val xOffset = if (r % 2 == 0) 0f else brickWidth / 2f
                        for (c in -1..colCount + 1) {
                            val x = c * brickWidth + xOffset
                            drawLine(
                                color = groutColor,
                                start = Offset(x, y),
                                end = Offset(x, y + rowHeight),
                                strokeWidth = 6f
                            )
                        }
                    }

                    val grateCenter = Offset(size.width * 0.5f, size.height * 0.5f)
                    val grateRadius = size.width * 0.26f

                    drawCircle(
                        color = Color(0x60000000),
                        center = grateCenter + Offset(4f, 10f),
                        radius = grateRadius
                    )

                    drawCircle(
                        color = Color(0xFF323632),
                        center = grateCenter,
                        radius = grateRadius
                    )
                    drawCircle(
                        color = Color(0xFF181C18),
                        center = grateCenter,
                        radius = grateRadius,
                        style = Stroke(width = 12f)
                    )

                    val slotCount = 6
                    val slotSpacing = grateRadius * 2f / (slotCount + 1)
                    for (i in 1..slotCount) {
                        val slotY = grateCenter.y - grateRadius + i * slotSpacing
                        val dy = kotlin.math.sqrt((grateRadius * grateRadius) - (slotY - grateCenter.y) * (slotY - grateCenter.y))
                        if (!dy.isNaN()) {
                            drawLine(
                                color = Color(0xFF0C0E0C),
                                start = Offset(grateCenter.x - dy + 18f, slotY),
                                end = Offset(grateCenter.x + dy - 18f, slotY),
                                strokeWidth = 12f
                            )
                        }
                    }

                    val slimeColor = Color(0xFF22C55E)
                    val puddle1 = Brush.radialGradient(
                        colors = listOf(slimeColor.copy(alpha = 0.45f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.85f),
                        radius = 280f
                    )
                    val puddle2 = Brush.radialGradient(
                        colors = listOf(slimeColor.copy(alpha = 0.35f), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.15f),
                        radius = 240f
                    )
                    drawCircle(brush = puddle1, radius = 280f, center = Offset(size.width * 0.15f, size.height * 0.85f))
                    drawCircle(brush = puddle2, radius = 240f, center = Offset(size.width * 0.85f, size.height * 0.15f))
                }
                ScenarioType.WOOD -> {
                    // Draw base wood color
                    drawRect(color = Color(0xFFD7CCC8))
                    
                    // Draw vertical wood planks
                    val plankCount = 5
                    val plankWidth = size.width / plankCount
                    val darkBrown = Color(0xFF8D6E63)
                    val lightAccent = Color(0x28FFFFFF)
                    
                    for (i in 1 until plankCount) {
                        val x = i * plankWidth
                        // Plank partition lines
                        drawLine(
                            color = darkBrown.copy(alpha = 0.5f),
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 5f
                        )
                        drawLine(
                            color = lightAccent,
                            start = Offset(x + 3f, 0f),
                            end = Offset(x + 3f, size.height),
                            strokeWidth = 2f
                        )
                    }

                    // Wood grains/texture inside each plank
                    for (i in 0 until plankCount) {
                        val centerX = (i + 0.5f) * plankWidth
                        val knotY = size.height * (0.25f + (i * 0.15f) % 0.6f)
                        
                        // Wood knot rings
                        drawCircle(
                            color = darkBrown.copy(alpha = 0.15f),
                            center = Offset(centerX, knotY),
                            radius = plankWidth * 0.4f,
                            style = Stroke(width = 3f)
                        )
                        drawCircle(
                            color = darkBrown.copy(alpha = 0.12f),
                            center = Offset(centerX, knotY),
                            radius = plankWidth * 0.2f,
                            style = Stroke(width = 2f)
                        )
                        
                        // Soft wavy wood lines
                        val gp = Path().apply {
                            moveTo(centerX - plankWidth * 0.35f, 0f)
                            quadraticTo(
                                centerX - plankWidth * 0.2f, size.height * 0.4f,
                                centerX - plankWidth * 0.4f, size.height
                            )
                        }
                        drawPath(gp, color = darkBrown.copy(alpha = 0.1f), style = Stroke(width = 4f))

                        val gp2 = Path().apply {
                            moveTo(centerX + plankWidth * 0.35f, 0f)
                            quadraticTo(
                                centerX + plankWidth * 0.45f, size.height * 0.6f,
                                centerX + plankWidth * 0.25f, size.height
                            )
                        }
                        drawPath(gp2, color = darkBrown.copy(alpha = 0.1f), style = Stroke(width = 3f))
                    }
                }
                ScenarioType.SAND -> {
                    // Sand base warm color
                    drawRect(color = Color(0xFFFFF9C4))
                    
                    val duneColor = Color(0xFFFFE082)
                    
                    // Wave/dune trails
                    for (i in 1..6) {
                        val dY = size.height * (i / 7f)
                        val gp = Path().apply {
                            moveTo(0f, dY)
                            quadraticTo(
                                size.width * 0.35f, dY - 60f + (i * 10f),
                                size.width * 0.7f, dY + 40f
                            )
                            quadraticTo(
                                size.width * 0.9f, dY + 70f,
                                size.width, dY - 20f
                            )
                        }
                        drawPath(gp, color = duneColor.copy(alpha = 0.35f), style = Stroke(width = 12f))
                    }
                    
                    // Little sand sparkles/dots
                    val rnd = java.util.Random(42L)
                    for (s in 0..120) {
                        val sX = rnd.nextFloat() * size.width
                        val sY = rnd.nextFloat() * size.height
                        val shiny = rnd.nextBoolean()
                        drawCircle(
                            color = if (shiny) Color.White.copy(alpha = 0.7f) else Color(0xFFFFB74D).copy(alpha = 0.5f),
                            center = Offset(sX, sY),
                            radius = if (shiny) 2f else 3.5f
                        )
                    }
                }
                ScenarioType.TEXTILE -> {
                    // Blue-cyan linen cozy texturized background
                    drawRect(color = Color(0xFFE0F2F1))
                    
                    val threadColor = Color(0x3580DEEA)
                    val denseSpacing = 16f
                    
                    // Horizontal linen thread guides
                    var yOffset = 0f
                    while (yOffset < size.height) {
                        drawLine(
                            color = threadColor,
                            start = Offset(0f, yOffset),
                            end = Offset(size.width, yOffset),
                            strokeWidth = 2f
                        )
                        yOffset += denseSpacing
                    }
                    
                    // Vertical linen thread guides
                    var xOffset = 0f
                    while (xOffset < size.width) {
                        drawLine(
                            color = threadColor,
                            start = Offset(xOffset, 0f),
                            end = Offset(xOffset, size.height),
                            strokeWidth = 2f
                        )
                        xOffset += denseSpacing
                    }

                    // Cozy soft cloth napkins stitches along margins
                    val margin = 32f
                    var stitchX = margin
                    val stitchStep = 24f
                    while (stitchX <= size.width - margin) {
                        drawCircle(Color(0xFF006064).copy(alpha = 0.4f), 3f, Offset(stitchX, margin))
                        drawCircle(Color(0xFF006064).copy(alpha = 0.4f), 3f, Offset(stitchX, size.height - margin))
                        stitchX += stitchStep
                    }
                    var stitchY = margin
                    while (stitchY <= size.height - margin) {
                        drawCircle(Color(0xFF006064).copy(alpha = 0.4f), 3f, Offset(margin, stitchY))
                        drawCircle(Color(0xFF006064).copy(alpha = 0.4f), 3f, Offset(size.width - margin, stitchY))
                        stitchY += stitchStep
                    }
                }
                ScenarioType.SPACE -> {
                    // Futuristic scifi panel floors
                    drawRect(color = Color(0xFF262626))
                    
                    val paneWidth = size.width / 3f
                    val paneHeight = size.height / 6f
                    val beamColor = Color(0xFF1F1F1F)
                    val edgeHighlight = Color(0x1EFFFFFF)
                    
                    // Square neon structural panel matrix
                    for (row in 0..6) {
                        val y = row * paneHeight
                        drawLine(
                            color = beamColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 8f
                        )
                        drawLine(
                            color = edgeHighlight,
                            start = Offset(0f, y + 4f),
                            end = Offset(size.width, y + 4f),
                            strokeWidth = 2.5f
                        )
                        
                        for (col in 0..3) {
                            val x = col * paneWidth
                            drawLine(
                                color = beamColor,
                                start = Offset(x, y),
                                end = Offset(x, y + paneHeight),
                                strokeWidth = 8f
                            )
                            drawLine(
                                color = edgeHighlight,
                                start = Offset(x + 4f, y),
                                end = Offset(x + 4f, y + paneHeight),
                                strokeWidth = 2.5f
                            )

                            // Glowing cyan indicator beads
                            if ((row + col) % 2 == 0) {
                                drawCircle(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                                    center = Offset(x, y),
                                    radius = 16f
                                )
                                drawCircle(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.8f),
                                    center = Offset(x, y),
                                    radius = 4f
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Draw blood splatters from history
        for (splat in splattersList) {
            key(splat.id) {
                SplatterItem(splat = splat)
            }
        }

        // 2.1. Draw active poison clouds on the ground
        for (cloud in poisonClouds) {
            key(cloud.id) {
                val age = System.currentTimeMillis() - cloud.spawnTimeMs
                val alphaFactor = (1.0f - age.toFloat() / cloud.durationMs).coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .layoutRelativePosition(cloud.x, cloud.y)
                        .alpha(alphaFactor * 0.65f)
                        .size(72.dp)
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                                colors = listOf(Color(0xFF4CAF50), Color(0x334CAF50), Color.Transparent),
                                radius = 100f
                            ),
                            shape = CircleShape
                        )
                        .border(1.dp, Color(0x664CAF50), shape = CircleShape)
                ) {
                    Text(
                        text = "☣️",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }

        // 2.2. Draw active temporary collectible drops
        for (drop in activeDrops) {
            key(drop.id) {
                val pulseScale = 1.0f + kotlin.math.sin((frameTick * 0.15f).toDouble()).toFloat() * 0.1f
                Box(
                    modifier = Modifier
                        .layoutRelativePosition(drop.x, drop.y)
                        .graphicsLayer {
                            scaleX = pulseScale
                            scaleY = pulseScale
                        }
                        .size(52.dp)
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                                colors = listOf(Color(drop.type.color).copy(alpha = 0.5f), Color.Transparent),
                                radius = 80f
                            )
                        )
                        .border(2.dp, Color(drop.type.color).copy(alpha = 0.8f), shape = CircleShape)
                        .testTag("temp_drop_${drop.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = drop.type.emoji, fontSize = 28.sp)
                }
            }
        }

        // 3. Draw active insects
        for (bug in bugsList) {
            if (bug.isSmashed) continue
            
            key(bug.id) {
                Box(
                    modifier = Modifier
                        .layoutRelativePosition(bug.x, bug.y)
                        .graphicsLayer {
                            // Apply squeeze anim scale upon spawning or tapping
                            scaleX = bug.scale
                            scaleY = bug.scale
                            rotationZ = if (bug.type == BugType.SPIDER) bug.angle + 180f else bug.angle
                        }
                        .size(bug.type.sizeDp.dp)
                        .testTag("active_bug_${bug.type.name}_${bug.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (bug.isInfected) {
                        // Soft green glowing aura background under the insect
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(Color(0x3339FF14), shape = CircleShape)
                                .border(1.5.dp, Color(0xFF39FF14), shape = CircleShape)
                        )
                    }

                    // Render matching insect emoji head-body cleanly without over-insect line decorators
                    Text(
                        text = when (bug.type) {
                            BugType.ANT -> "🐜"
                            BugType.TERMITE -> "🦟"
                            BugType.COCKROACH -> "🪳"
                            BugType.SPIDER -> "🕷️"
                            BugType.BEETLE -> "🐞" // beetle
                            BugType.WASP -> "🐝" // wasp avoidance
                            BugType.SCORPION -> "🦂" // scorpion poison hazard
                            BugType.CENTIPEDE -> "🐛" // centipede rapid elite mutant
                        },
                        fontSize = (bug.type.sizeDp - 6).sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // 4. Paint floating floating pop-ups VFX text
        for (vfx in vfxList) {
            key(vfx.id) {
                Box(
                    modifier = Modifier
                        .layoutRelativePosition(vfx.x, vfx.y + vfx.yOffset)
                        .alpha(vfx.alpha)
                        .wrapContentSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.72f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(vfx.color)),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = vfx.text,
                            color = Color(vfx.color),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // 5. Frozen Ice slow overlay indicator
        if (freezeCdRemainingMs > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x35B2EBF2))
                    .border(5.dp, Color(0xFF00E5FF))
            ) {
                Text(
                    text = "TEMPO CONGELADO ❄️ ${"%.1f".format(freezeCdRemainingMs / 1000f)}s",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 120.dp)
                )
            }
        }

        // 6. Super Shoe heavy stomps indicator
        if (shoeCdRemainingMs > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(6.dp, Color(0xFFFFD700))
            ) {
                Text(
                    text = "DEDOS PESADOS 🥾 ${"%.1f".format(shoeCdRemainingMs / 1000f)}s",
                    color = Color(0xFFFFD700),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 145.dp)
                )
            }
        }

        // 7. Visual screen-hurt red flash border overlay
        if (isHurtFlame) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(8.dp, Color.Red)
                    .background(Color(0x35FF0000))
            )
        }

        // 8. Visual screen-poisoned toxic green mist border overlay
        if (isScreenPoisoned) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(8.dp, Color(0xFF4CAF50))
                    .background(Color(0x301B5E20))
            ) {
                Text(
                    text = "☣️ ENVENENADO! ${"%.1f".format(poisonCdRemainingMs / 1000f)}s",
                    color = Color(0xFF4CAF50),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 170.dp)
                )
            }
        }

        // 9. Active Temporary Poison Gun
        if (activePoisonGunTimeLeftMs > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(5.dp, Color(0xFF00E5FF))
            ) {
                Text(
                    text = "PISTOLA DE VENENO ATIVA 🔫 ${"%.1f".format(activePoisonGunTimeLeftMs / 1000f)}s (ARRASTE)",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 195.dp)
                )
            }
        }

        // 10. Active Temporary Poison Cloud Trail painting
        if (activePoisonTrailTimeLeftMs > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(5.dp, Color(0xFF4CAF50))
            ) {
                Text(
                    text = "☣️ TRILHA QUÍMICA ☣️ ${"%.1f".format(activePoisonTrailTimeLeftMs / 1000f)}s (ARRASTE)",
                    color = Color(0xFF4CAF50),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 195.dp)
                )
            }
        }

        // 8. Active HUD HUD dashboards
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Level stats and Paused trigger
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.pauseGame() },
                    modifier = Modifier.background(Color(0x77000000), CircleShape)
                ) {
                    Icon(Icons.Default.Pause, "Pausar", tint = Color.White)
                }

                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = levelName,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                // Audio toggler
                val soundMuted by viewModel.soundMuted.collectAsStateWithLifecycle()
                IconButton(
                    onClick = { viewModel.toggleMute() },
                    modifier = Modifier.background(Color(0x77000000), CircleShape)
                ) {
                    Icon(
                        imageVector = if (soundMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Muto",
                        tint = Color.White
                    )
                }
            }

            // High scores, Hearts group, Time clock box
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Score & Golden earned card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.72f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text("SCORE", fontSize = 9.sp, color = Color.LightGray)
                        Text("$score pts", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFFEBCB8B))
                        Text("🪙 Earned: $goldEarned", fontSize = 9.sp, color = Color(0xFFA3BE8C), fontWeight = FontWeight.Bold)
                    }
                }

                // Lives health card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.72f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("game_lives_indicator")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("VIDAS", fontSize = 9.sp, color = Color.LightGray)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Max 5 hearts
                            repeat(5) { idx ->
                                Text(
                                    text = if (idx < lives) "❤️" else "🖤",
                                    fontSize = 14.sp,
                                    modifier = Modifier.alpha(if (idx < lives) 1f else 0.4f)
                                )
                            }
                        }
                    }
                }

                // Clock timer card (only if not endless countdown index)
                if (timeLeft < 9000) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (timeLeft <= 5) Color(0x99BF616A) else Color.Black.copy(alpha = 0.72f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("game_timer_indicator")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("TEMPO", fontSize = 9.sp, color = Color.LightGray)
                            Text(
                                "${timeLeft}s",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = if (timeLeft <= 5) Color.White else Color(0xFFEBCB8B)
                            )
                        }
                    }
                }
            }
        }

        // 9. Bottom Arsenal panel dock (powerups inventory count)
        val pRef = p
        if (pRef != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .align(Alignment.BottomCenter),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.72f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, ForestGreen)
                ) {
                    Row(
                        modifier = Modifier.padding(symmetric = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Spray trigger
                        PowerupDockButton(
                            symbol = "💨",
                            label = "Spray",
                            count = pRef.sprayCount,
                            onClick = { viewModel.useSprayPowerup() },
                            enabled = pRef.sprayCount > 0,
                            testTag = "fire_spray_button"
                        )

                        // Freeze trigger
                        PowerupDockButton(
                            symbol = "❄️",
                            label = "Gelo",
                            count = pRef.freezeCount,
                            onClick = { viewModel.useFreezePowerup() },
                            enabled = pRef.freezeCount > 0,
                            testTag = "fire_freeze_button"
                        )

                        // Shoe heavy stomp damage boost trigger
                        PowerupDockButton(
                            symbol = "🥾",
                            label = "Sapato",
                            count = pRef.tripleSquashCount,
                            onClick = { viewModel.useShoePowerup() },
                            enabled = pRef.tripleSquashCount > 0,
                            testTag = "fire_shoe_button"
                        )
                    }
                }
            }
        }

        // 10. Pause Modal window overlay
        if (gameState is GameState.Paused) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f))
                    .testTag("game_paused_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftEggshell),
                    border = BorderStroke(1.5.dp, BorderLightSystem)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Jogo Pausado ⏸️",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = DarkForestText
                        )

                        Text(
                            text = "O cronômetro está congelado temporariamente. Prepare os seus dedos para continuar esmagando!",
                            color = MutedGreyGreen,
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp
                        )

                        Button(
                            onClick = { viewModel.resumeGame() },
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("resume_game_button")
                        ) {
                            Text("Retomar Partida", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel.quitToMenu() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ForestGreen),
                            border = BorderStroke(1.5.dp, ForestGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("quit_game_button")
                        ) {
                            Text("Sair para o Menu")
                        }
                    }
                }
            }
        }

        // 11. Post Match Game Over Overlay
        if (gameState is GameState.GameOver) {
            val endState = gameState as GameState.GameOver
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.82f))
                    .testTag("game_over_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftEggshell),
                    border = BorderStroke(2.dp, Color(0xFFBF616A))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("💀 FIM DE JOGO!", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color(0xFFBF616A))
                        
                        Text(
                            text = "Os insetos escaparam ou você tocou nas vespas venenosas!",
                            color = MutedGreyGreen,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                            border = BorderStroke(1.dp, BorderLightSystem),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Pontuação Final", fontSize = 11.sp, color = MutedGreyGreen)
                                Text("${endState.finalScore} PTS", fontSize = 32.sp, fontWeight = FontWeight.Black, color = ForestGreen)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("🪙 Moedas Adquiridas: +${endState.goldEarned}", fontSize = 12.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.quitToMenu() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ForestGreen),
                                border = BorderStroke(1.5.dp, ForestGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Menu Principal")
                            }

                            Button(
                                onClick = {
                                    viewModel.retryCurrentMatch()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Repetir", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 12. Post Match Victory Overlay
        if (gameState is GameState.Victory) {
            val winState = gameState as GameState.Victory
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.82f))
                    .testTag("game_victory_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftEggshell),
                    border = BorderStroke(2.dp, ForestGreen)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("🎉 VITÓRIA TOTAL!", fontSize = 28.sp, fontWeight = FontWeight.Black, color = ForestGreen)
                        
                        Text(
                            text = "Excelente mira! Meta cumprida com maestria.",
                            color = MutedGreyGreen,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                            border = BorderStroke(1.dp, BorderLightSystem),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Pontos Acumulados", fontSize = 11.sp, color = MutedGreyGreen)
                                Text("${winState.finalScore} PTS", fontSize = 32.sp, fontWeight = FontWeight.Black, color = ForestGreen)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("🪙", fontSize = 14.sp)
                                    Text("Gold Recebido (Bônus incluído): +${winState.goldEarned}", fontSize = 12.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (winState.nextLevelUnlocked) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SageGreenDense
                            ) {
                                Text(
                                    text = "NOVA FASE DESBLOQUEADA EM CAMPANHA!",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.quitToMenu() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ForestGreen),
                                border = BorderStroke(1.5.dp, ForestGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Roadmap Fases")
                            }

                            Button(
                                onClick = {
                                    viewModel.advanceToNextCampaignLevelOrMenu()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Continuar", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Custom layout modifier that places things according to a percentage boundary (0f..1f)
private fun Modifier.layoutRelativePosition(
    relX: Float,
    relY: Float
): Modifier = this.layout { measurable, constraints ->
    val placeable = measurable.measure(constraints)
    layout(placeable.width, placeable.height) {
        val posX = (relX * constraints.maxWidth) - (placeable.width / 2f)
        val posY = (relY * constraints.maxHeight) - (placeable.height / 2f)
        placeable.place(posX.toInt(), posY.toInt())
    }
}

@Composable
fun PowerupDockButton(
    symbol: String,
    label: String,
    count: Int,
    onClick: () -> Unit,
    enabled: Boolean,
    testTag: String
) {
    IconButton(
        onClick = { if (enabled) onClick() },
        enabled = enabled,
        modifier = Modifier
            .size(54.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .background(if (enabled) ForestGreen.copy(alpha = 0.2f) else Color(0x11FFFFFF), RoundedCornerShape(12.dp))
            .border(1.dp, if (enabled) ForestGreen else Color.Transparent, RoundedCornerShape(12.dp))
            .testTag(testTag)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(symbol, fontSize = 24.sp)
            Text(
                text = "$label ($count)",
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = if (enabled) Color.White else Color.Gray,
                maxLines = 1
            )
        }
    }
}

// ---------------------- EXTENSION HELPERS ----------------------
fun Modifier.padding(symmetric: Dp, vertical: Dp): Modifier {
    return this.padding(start = symmetric, end = symmetric, top = vertical, bottom = vertical)
}

// ----------------- ABOUT US SCREEN (SOBRE NÓS) -----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val context = LocalContext.current
    val clipboardManager = remember { context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager }
    var webViewUrl by remember { mutableStateOf<String?>(null) }

    val isSuperuser by viewModel.isSuperuser.collectAsStateWithLifecycle()
    val globalPixKey by viewModel.globalPixKey.collectAsStateWithLifecycle()
    val globalPixQrBase64 by viewModel.globalPixQrBase64.collectAsStateWithLifecycle()
    val isLoadingOnline by viewModel.isLoadingOnline.collectAsStateWithLifecycle()

    var adminPixKey by remember(globalPixKey) { mutableStateOf(globalPixKey) }
    var adminQrCodeBase64 by remember(globalPixQrBase64) { mutableStateOf(globalPixQrBase64 ?: "") }

    LaunchedEffect(Unit) {
        viewModel.fetchGlobalPixConfig()
    }

    val customBitmap = remember(globalPixQrBase64) {
        if (!globalPixQrBase64.isNullOrEmpty()) {
            try {
                val decodedString = android.util.Base64.decode(globalPixQrBase64, android.util.Base64.DEFAULT)
                android.graphics.BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    val adminPreviewBitmap = remember(adminQrCodeBase64) {
        if (adminQrCodeBase64.isNotEmpty()) {
            try {
                val decodedString = android.util.Base64.decode(adminQrCodeBase64, android.util.Base64.DEFAULT)
                android.graphics.BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes()
                inputStream?.close()
                if (bytes != null) {
                    val originalBitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (originalBitmap != null) {
                        // Optimize and scale down image to maximum 350px width/height to dramatically reduce base64 payload size
                        val maxDimension = 350
                        val width = originalBitmap.width
                        val height = originalBitmap.height
                        val finalBitmap = if (width > maxDimension || height > maxDimension) {
                            val ratio = width.toFloat() / height.toFloat()
                            val newWidth: Int
                            val newHeight: Int
                            if (ratio > 1) {
                                newWidth = maxDimension
                                newHeight = (maxDimension / ratio).toInt()
                            } else {
                                newHeight = maxDimension
                                newWidth = (maxDimension * ratio).toInt()
                            }
                            android.graphics.Bitmap.createScaledBitmap(originalBitmap, newWidth, newHeight, true)
                        } else {
                            originalBitmap
                        }

                        val outputStream = java.io.ByteArrayOutputStream()
                        finalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, outputStream)
                        val compressedBytes = outputStream.toByteArray()
                        val base64String = android.util.Base64.encodeToString(compressedBytes, android.util.Base64.NO_WRAP)
                        adminQrCodeBase64 = base64String
                        android.widget.Toast.makeText(context, "Imagem de QR Code carregada na memória!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "Erro ao carregar imagem: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sobre Nós", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.playButtonClick(); navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Voltar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SoftEggshell,
                    titleContentColor = DarkForestText,
                    navigationIconContentColor = DarkForestText
                ),
                modifier = Modifier.testTag("about_back_bar")
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(SoftEggshell, TiledStageBackground)
                    )
                )
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                item {
                    // Logo/Avatar block
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(100.dp)
                            .background(SageGreenLight, CircleShape)
                            .border(2.dp, ForestGreen, CircleShape)
                            .shadow(2.dp, CircleShape)
                    ) {
                        Text("💻✨", fontSize = 48.sp)
                    }
                }

                item {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "LyraStudio",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = ForestGreen
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SageGreenLight,
                            border = BorderStroke(1.dp, BorderLightSystem)
                        ) {
                            Text(
                                text = "Desenvolvedor Independente",
                                color = SageGreenDense,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, BorderLightSystem),
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(4.dp, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(15.dp)
                        ) {
                            Text(
                                text = "Criando jogos e soluções inteligentes com paixão e precisão em cada linha de código. Nossa missão é entregar experiências de altíssima qualidade, com interfaces fluidas e excelente usabilidade.",
                                fontSize = 14.sp,
                                color = MutedGreyGreen,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }

                // Global Pix configuration admin panel
                if (isSuperuser) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(2.dp, ForestGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(6.dp, RoundedCornerShape(16.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "⚙️ PAINEL ADMINISTRATIVO (PIX)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ForestGreen,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text(
                                    text = "Configure a chave Copia e Cola do Pix e importe uma imagem de QR Code para visualização de todos os outros jogadores.",
                                    fontSize = 12.sp,
                                    color = MutedGreyGreen,
                                    lineHeight = 18.sp
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Cadeia Copia e Cola Pix escrita:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = DarkForestText)
                                    OutlinedTextField(
                                        value = adminPixKey,
                                        onValueChange = { adminPixKey = it },
                                        placeholder = { Text("Insira o código Pix Copia e Cola...") },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = ForestGreen,
                                            unfocusedBorderColor = BorderLightSystem
                                        ),
                                        singleLine = false,
                                        maxLines = 4
                                    )
                                }

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Visualização do QR Code:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = DarkForestText, modifier = Modifier.fillMaxWidth())

                                    Box(
                                        modifier = Modifier
                                            .size(130.dp)
                                            .background(Color.White, RoundedCornerShape(8.dp))
                                            .border(1.dp, BorderLightSystem, RoundedCornerShape(8.dp))
                                            .padding(8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (adminPreviewBitmap != null) {
                                            androidx.compose.foundation.Image(
                                                bitmap = adminPreviewBitmap.asImageBitmap(),
                                                contentDescription = "Visual Pix QR Code",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = androidx.compose.ui.layout.ContentScale.Fit
                                            )
                                        } else {
                                            Text("Padrão Procedural Ativado", fontSize = 11.sp, color = MutedGreyGreen, textAlign = TextAlign.Center)
                                        }
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Button(
                                            onClick = {
                                                viewModel.playButtonClick()
                                                pickerLauncher.launch("image/*")
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = SageGreenLight,
                                                contentColor = SageGreenDense
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Importar 📸", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.playButtonClick()
                                                adminQrCodeBase64 = ""
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = DangerRedLight,
                                                contentColor = DangerRedDense
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f),
                                            enabled = adminQrCodeBase64.isNotEmpty()
                                        ) {
                                            Text("Limpar ❌", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Button(
                                    onClick = {
                                        viewModel.playButtonClick()
                                        viewModel.saveCustomPixData(adminPixKey, adminQrCodeBase64)
                                        android.widget.Toast.makeText(context, "Configuração de Pix salva no Firebase!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ForestGreen,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isLoadingOnline
                                ) {
                                    if (isLoadingOnline) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                                    } else {
                                        Text("Salvar Configuração Pix Global 💾", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "CONTATO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedGreyGreen,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp)
                    )
                }

                // Contact Cards
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, BorderLightSystem),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.playButtonClick()
                                val clip = android.content.ClipData.newPlainText("E-mail LyraStudio", "lyrastudio.smartsolutions@gmail.com")
                                clipboardManager.setPrimaryClip(clip)
                                android.widget.Toast.makeText(context, "E-mail copiado!", android.widget.Toast.LENGTH_SHORT).show()
                            }
                            .shadow(2.dp, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(SageGreenLight, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("✉️", fontSize = 20.sp)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "E-mail de Suporte",
                                    fontSize = 12.sp,
                                    color = MutedGreyGreen
                                )
                                Text(
                                    text = "lyrastudio.smartsolutions@gmail.com",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkForestText
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copiar E-mail",
                                tint = ForestGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, BorderLightSystem),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.playButtonClick()
                                webViewUrl = "https://www.instagram.com/th.lyra/"
                            }
                            .shadow(2.dp, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(SageGreenLight, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("📸", fontSize = 20.sp)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Instagram",
                                    fontSize = 12.sp,
                                    color = MutedGreyGreen
                                )
                                Text(
                                    text = "@th.lyra",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkForestText
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Acessar Instagram",
                                tint = ForestGreen,
                                modifier = Modifier.size(18.dp).rotate(180f)
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = "CONTRIBUIR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedGreyGreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 4.dp, top = 8.dp)
                    )
                }

                // Pix Donation Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, BorderLightSystem),
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(4.dp, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "Gostou do jogo? Considere apoiar com uma contribuição espontânea via Pix para incentivar novos recursos e projetos!",
                                fontSize = 14.sp,
                                color = DarkForestText,
                                textAlign = TextAlign.Center,
                                lineHeight = 20.sp
                            )

                            // Show QR Code inside a nice card frame
                            Box(
                                modifier = Modifier
                                    .size(170.dp)
                                    .background(Color.White, RoundedCornerShape(12.dp))
                                    .border(1.dp, BorderLightSystem, RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (customBitmap != null) {
                                    androidx.compose.foundation.Image(
                                        bitmap = customBitmap.asImageBitmap(),
                                        contentDescription = "Pix QR Code Importado",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                                    )
                                } else {
                                    ProceduralQrCode(modifier = Modifier.fillMaxSize())
                                }
                            }

                            Text(
                                text = "Aponte a câmera do seu banco para o QR Code ou copie o código abaixo.",
                                fontSize = 12.sp,
                                color = MutedGreyGreen,
                                textAlign = TextAlign.Center,
                                lineHeight = 16.sp
                            )

                            Button(
                                onClick = {
                                    viewModel.playButtonClick()
                                    val clip = android.content.ClipData.newPlainText(
                                        "Pix Copia e Cola LyraStudio",
                                        globalPixKey
                                    )
                                    clipboardManager.setPrimaryClip(clip)
                                    android.widget.Toast.makeText(context, "Código de Pix copiado!", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF32BCAD),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("copy_pix_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar Pix",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Copiar Pix Copia e Cola",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Obrigado por apoiar desenvolvedores independentes! ❤️",
                        fontSize = 12.sp,
                        color = MutedGreyGreen,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        if (webViewUrl != null) {
            InAppWebViewDialog(
                url = webViewUrl!!,
                onDismiss = { webViewUrl = null }
            )
        }
    }
}

@Composable
fun ProceduralQrCode(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val sizePx = size.width
        val gridSize = 21 // 21x21 QR Code grid
        val cellSize = sizePx / gridSize

        // Draw background white
        drawRect(color = Color.White)

        // Seeded random for dots so they stay identical across recomposition
        val random = java.util.Random(1337)

        // Draw finder patterns (top-left, top-right, bottom-left)
        fun drawFinder(offsetX: Int, offsetY: Int) {
            // Outer 7x7 square
            drawRect(
                color = Color.Black,
                topLeft = Offset(offsetX * cellSize, offsetY * cellSize),
                size = Size(7 * cellSize, 7 * cellSize)
            )
            // Inner 5x5 white square
            drawRect(
                color = Color.White,
                topLeft = Offset((offsetX + 1) * cellSize, (offsetY + 1) * cellSize),
                size = Size(5 * cellSize, 5 * cellSize)
            )
            // Center 3x3 black square
            drawRect(
                color = Color.Black,
                topLeft = Offset((offsetX + 2) * cellSize, (offsetY + 2) * cellSize),
                size = Size(3 * cellSize, 3 * cellSize)
            )
        }

        drawFinder(0, 0)
        drawFinder(gridSize - 7, 0)
        drawFinder(0, gridSize - 7)

        // Helper function to check if cell is inside a finder pattern
        fun isFinder(x: Int, y: Int): Boolean {
            if (x < 8 && y < 8) return true // Top-left
            if (x >= gridSize - 8 && y < 8) return true // Top-right
            if (x < 8 && y >= gridSize - 8) return true // Bottom-left
            return false
        }

        // Reserve center area for logo
        val centerStart = gridSize / 2 - 2
        val centerEnd = gridSize / 2 + 2

        for (x in 0 until gridSize) {
            for (y in 0 until gridSize) {
                if (isFinder(x, y)) continue
                // Reserve center 5x5 for logo so it looks super clean
                if (x in centerStart..centerEnd && y in centerStart..centerEnd) continue

                // Random black or white based on seed
                if (random.nextBoolean()) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(x * cellSize, y * cellSize),
                        size = Size(cellSize + 0.5f, cellSize + 0.5f) // small overlap to avoid tiny lines
                    )
                }
            }
        }

        // Draw centered Pix-like diamond logo
        val logoSize = 5 * cellSize
        val logoLeft = (gridSize / 2f - 2.5f) * cellSize
        val logoTop = (gridSize / 2f - 2.5f) * cellSize

        // Background of center logo (white boundary)
        drawRect(
            color = Color.White,
            topLeft = Offset(logoLeft - 1f, logoTop - 1f),
            size = Size(logoSize + 2f, logoSize + 2f)
        )

        // Draw Pix central diamond symbol in beautiful Teal color
        val pixColor = Color(0xFF32BCAD)
        val centerPx = sizePx / 2f
        val dSize = 1.8f * cellSize

        // Diamond paths
        val p1 = Path().apply {
            moveTo(centerPx, centerPx - dSize)
            lineTo(centerPx + dSize, centerPx)
            lineTo(centerPx, centerPx + dSize)
            lineTo(centerPx - dSize, centerPx)
            close()
        }
        drawPath(path = p1, color = pixColor)
    }
}
