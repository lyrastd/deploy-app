package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Color Palette
val SoftEggshell = Color(0xFFF7FBF1)
val DarkForestText = Color(0xFF191D17)
val ForestGreen = Color(0xFF386A20)
val SageGreenLight = Color(0xFFD7E8CD)
val SageGreenDense = Color(0xFF111F0E)
val MutedGreyGreen = Color(0xFF43493F)
val BorderLightSystem = Color(0xFFDFE4D7)
val TiledStageBackground = Color(0xFFE2E3DD)
val GridTileDots = Color(0xFFCED0C8)
val DangerRedLight = Color(0xFFFFDAD6)
val DangerRedDense = Color(0xFF410002)

// Old colors mapped back for backwards compatibility if needed
val Purple80 = ForestGreen
val PurpleGrey80 = SageGreenLight
val Pink80 = DangerRedLight
val Purple40 = ForestGreen
val PurpleGrey40 = MutedGreyGreen
val Pink40 = DangerRedDense
