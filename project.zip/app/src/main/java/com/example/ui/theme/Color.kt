package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Frosted Glass Palette (Vibrant & Translucent)
val LyraPrimary = Color(0xFF22D3EE)       // Glowing Neon Cyan (Hex: 22D3EE)
val LyraSecondary = Color(0xFFD946EF)     // Neon Fuchsia/Magenta (Hex: D946EF)
val LyraTertiary = Color(0xFF3B82F6)      // Tech Royal Blue (Hex: 3B82F6)

val DarkBackground = Color(0xFF020617)    // Deep Slate 950 base
val DarkSurface = Color(0xFF0F172A)       // Sleek Slate 900 base panel
val DarkSurfaceElevated = Color(0xFF1E293B) // Layered active states

val LyraGlowGreen = Color(0xFF10B981)     // AI Success Green
val LyraGlowRed = Color(0xFFEF4444)       // Voice Mic listening warning
val TextPrimary = Color(0xFFF8FAFC)       // High contrast crystal silver
val TextSecondary = Color(0xFF94A3B8)     // Soft slate description label

// Frosted Glass Translucency & Neon Glow Accents
val GlassBgOnly = Color(0x0DFFFFFF)       // White 5% translucent
val GlassBgCard = Color(0x14FFFFFF)       // White 8% standard glass container
val GlassBorderLight = Color(0x26FFFFFF)  // White 15% glass top-edge light border
val GlassBorderMuted = Color(0x13FFFFFF)  // White 7% subtle glass boundaries
val NeonGlowCyan = Color(0x3322D3EE)      // Cyan accent halo glow
val NeonGlowFuchsia = Color(0x33D946EF)   // Fuchsia accent halo glow

