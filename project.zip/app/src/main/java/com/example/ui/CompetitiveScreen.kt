package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.data.FirebaseChallenge
import com.example.data.PlayerProfile
import com.example.game.InsectGameViewModel

// Re-declare local palette fallbacks to prevent compile issues
private val ForestGreen = Color(0xFF2E6B47)
private val SoftEggshell = Color(0xFFF9F6EE)
private val DarkForestText = Color(0xFF1E3A24)
private val SageGreenLight = Color(0xFFE8F5E9)
private val SageGreenDense = Color(0xFF2E7D32)
private val MutedGreyGreen = Color(0xFF758F7D)
private val BorderLightSystem = Color(0xFFE0E2DF)

@Composable
fun CompetitiveScreen(viewModel: InsectGameViewModel, navController: NavController) {
    val context = LocalContext.current
    val firebaseUser by viewModel.firebaseUsername.collectAsStateWithLifecycle()
    val firebaseEmail by viewModel.firebaseUserEmail.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoadingOnline.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val authSuccess by viewModel.authSuccessMessage.collectAsStateWithLifecycle()
    
    val profile by viewModel.currentProfileState.collectAsStateWithLifecycle()

    // Status updates
    LaunchedEffect(authError) {
        authError?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.authError.value = null
        }
    }
    LaunchedEffect(authSuccess) {
        authSuccess?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.authSuccessMessage.value = null
        }
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Arena de Combate Online ⚔️", fontWeight = FontWeight.Bold, color = DarkForestText) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.playButtonClick(); navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = DarkForestText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SoftEggshell)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(SoftEggshell)
        ) {
            if (firebaseUser == null) {
                // Connection Form
                AuthenticationPortal(viewModel)
            } else {
                // Online Competitive Lobby
                CompetitiveDashboard(viewModel, profile, navController)
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = ForestGreen)
                }
            }
        }
    }
}

@Composable
fun AuthenticationPortal(viewModel: InsectGameViewModel) {
    var isSignUp by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var selectedAvatarIdx by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = SageGreenLight),
                border = BorderStroke(1.dp, BorderLightSystem)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🚀 Arena Multiplayer Real",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = SageGreenDense
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Crie ou acesse sua conta por E-mail para registrar seu ranque global real, sincronizar suas moedas e desafiar outros jogadores de verdade!",
                        fontSize = 11.sp,
                        color = MutedGreyGreen
                    )
                }
            }
        }

        // Segmented Switcher
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(24.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { viewModel.playButtonClick(); isSignUp = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isSignUp) ForestGreen else Color.Transparent,
                        contentColor = if (!isSignUp) Color.White else DarkForestText
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Já Tenho Conta", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Button(
                    onClick = { viewModel.playButtonClick(); isSignUp = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSignUp) ForestGreen else Color.Transparent,
                        contentColor = if (isSignUp) Color.White else DarkForestText
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Criar Nova", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        item {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Endereço de E-mail") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                leadingIcon = { Icon(Icons.Default.Email, null) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ForestGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_email_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Senha") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                leadingIcon = { Icon(Icons.Default.Lock, null) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ForestGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_password_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
        }

        if (isSignUp) {
            item {
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.lowercase().replace(" ", "") },
                    label = { Text("Nome de Usuário (chave primária)") },
                    supportingText = { Text("Tudo minúsculo, sem espaços ou símbolos") },
                    leadingIcon = { Icon(Icons.Default.AlternateEmail, null) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ForestGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_username_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "Escolha seu Avatar de Duelo:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkForestText,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        items(AVATAR_EMOJIS.size) { idx ->
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(
                                        if (selectedAvatarIdx == idx) SageGreenLight else Color.White,
                                        CircleShape
                                    )
                                    .border(
                                        width = if (selectedAvatarIdx == idx) 2.dp else 1.dp,
                                        color = if (selectedAvatarIdx == idx) ForestGreen else BorderLightSystem,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        viewModel.playButtonClick()
                                        selectedAvatarIdx = idx
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(AVATAR_EMOJIS[idx], fontSize = 28.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    viewModel.playButtonClick()
                    if (isSignUp) {
                        viewModel.registerOnlineUser(email, password, username, selectedAvatarIdx)
                    } else {
                        viewModel.loginOnlineUser(email, password)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("auth_submit_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (isSignUp) "Registrar Conta & Jogar! 🎮" else "Acessar Arena ⚔️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun CompetitiveDashboard(
    viewModel: InsectGameViewModel,
    profile: PlayerProfile?,
    navController: NavController
) {
    val firebaseUser by viewModel.firebaseUsername.collectAsStateWithLifecycle()
    val ranking by viewModel.globalRankingList.collectAsStateWithLifecycle()
    val friends by viewModel.friendsMap.collectAsStateWithLifecycle()
    val challenges by viewModel.challengesList.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0 = Desafios, 1 = Amigos, 2 = Ranking Global

    // Auto update resources occasionally
    LaunchedEffect(Unit) {
        viewModel.refreshGlobalRanking()
        viewModel.refreshFriends()
        viewModel.refreshChallenges()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Player info header card
        if (profile != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .shadow(4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLightSystem)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(SageGreenLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(AVATAR_EMOJIS.getOrElse(profile.avatarId) { "👵" }, fontSize = 28.sp)
                        }
                        Column {
                            Text(
                                text = "@$firebaseUser",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = DarkForestText
                            )
                            Text(
                                text = "🪙 ${profile.gold} Moedas | Récord: ${profile.highScoreEndless} Pts",
                                fontSize = 11.sp,
                                color = MutedGreyGreen
                            )
                        }
                    }

                    // Logout Button
                    OutlinedButton(
                        onClick = { viewModel.logoutUser() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        border = BorderStroke(1.dp, Color.Red),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.ExitToApp, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sair", fontSize = 11.sp)
                    }
                }
            }
        }

        // TabLayout switcher
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = SoftEggshell,
            contentColor = ForestGreen
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { viewModel.playButtonClick(); activeTab = 0; viewModel.refreshChallenges() },
                text = { Text("Desafios ⚔️", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { viewModel.playButtonClick(); activeTab = 1; viewModel.refreshFriends() },
                text = { Text("Amigos 👥", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = activeTab == 2,
                onClick = { viewModel.playButtonClick(); activeTab = 2; viewModel.refreshGlobalRanking() },
                text = { Text("Ranking Global 🏆", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
        }

        // Content panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            when (activeTab) {
                0 -> ChallengesTabContent(viewModel, challenges, friends, profile)
                1 -> FriendsTabContent(viewModel, friends)
                2 -> OnlineRankingTabContent(viewModel, ranking, firebaseUser)
            }
        }
    }
}

@Composable
fun ChallengesTabContent(
    viewModel: InsectGameViewModel,
    challenges: List<FirebaseChallenge>,
    friends: Map<String, String>,
    profile: PlayerProfile?
) {
    var targetUser by remember { mutableStateOf("") }
    var betAmountStr by remember { mutableStateOf("25") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Create challenge block
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLightSystem)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "⚔️ Lançar Desafio de Aposta",
                        fontWeight = FontWeight.Bold,
                        color = DarkForestText,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = targetUser,
                            onValueChange = { targetUser = it.lowercase().trim() },
                            label = { Text("Apelido do Amigo") },
                            placeholder = { Text("ex: ninjasbp") },
                            modifier = Modifier.weight(1.3f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ForestGreen)
                        )

                        OutlinedTextField(
                            value = betAmountStr,
                            onValueChange = { betAmountStr = it.filter { c -> c.isDigit() } },
                            label = { Text("Aposta 🪙") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.7f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ForestGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            viewModel.playButtonClick()
                            val betAmount = betAmountStr.toIntOrNull() ?: 0
                            viewModel.sendChallenge(targetUser, betAmount)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Iniciar Duelo!", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // List Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Lutas Pendentes & Resultados",
                    fontWeight = FontWeight.Bold,
                    color = SageGreenDense,
                    fontSize = 13.sp
                )
                IconButton(onClick = { viewModel.playButtonClick(); viewModel.refreshChallenges() }) {
                    Icon(Icons.Default.Refresh, "Atualizar", tint = ForestGreen)
                }
            }
        }

        if (challenges.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Nenhum duelo registrado. Desafie seus amigos!",
                        color = MutedGreyGreen,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(challenges) { challenge ->
                val isChallenger = (viewModel.firebaseUsername.value == challenge.challenger)
                val opponentName = if (isChallenger) challenge.opponent else challenge.challenger
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderLightSystem)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "Duelo contra @$opponentName",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = DarkForestText
                                )
                                Text(
                                    text = "Aposta: 🪙 ${challenge.betAmount} Moedas",
                                    fontSize = 12.sp,
                                    color = Color(0xFFC78414),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            
                            // Badge indicating state
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (challenge.status) {
                                    "pending" -> Color(0xFFFFF3E0)
                                    "accepted" -> Color(0xFFE8F5E9)
                                    "completed" -> Color(0xFFECEFF1)
                                    else -> Color(0xFFFFEBEE)
                                },
                                contentColor = when (challenge.status) {
                                    "pending" -> Color(0xFFE65100)
                                    "accepted" -> ForestGreen
                                    "completed" -> Color(0xFF37474F)
                                    else -> Color(0xFFC62828)
                                }
                            ) {
                                Text(
                                    text = when (challenge.status) {
                                        "pending" -> "Pendente"
                                        "accepted" -> "Aceito!"
                                        "completed" -> "Concluído"
                                        else -> "Recusado"
                                    }.uppercase(),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Match stats detail
                        if (challenge.status == "accepted" || challenge.status == "completed") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.LightGray.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "@${challenge.challenger}: ${if (challenge.challengerScore >= 0) "${challenge.challengerScore} pts" else "Ainda não jogou"}",
                                    fontSize = 11.sp,
                                    color = DarkForestText
                                )
                                Text(
                                    text = "@${challenge.opponent}: ${if (challenge.opponentScore >= 0) "${challenge.opponentScore} pts" else "Ainda não jogou"}",
                                    fontSize = 11.sp,
                                    color = DarkForestText
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Actions based on state
                        if (challenge.status == "pending" && !isChallenger) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.playButtonClick(); viewModel.acceptChallenge(challenge) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Aceitar", fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.playButtonClick(); viewModel.declineChallenge(challenge) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                    border = BorderStroke(1.dp, Color.Red),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Recusar", fontWeight = FontWeight.Bold)
                                }
                            }
                        } else if (challenge.status == "pending" && isChallenger) {
                            OutlinedButton(
                                onClick = { viewModel.playButtonClick(); viewModel.declineChallenge(challenge) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                border = BorderStroke(1.dp, Color.Red),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Cancelar Convite")
                            }
                        } else if (challenge.status == "accepted") {
                            val userHasPlayed = if (isChallenger) challenge.challengerScore >= 0 else challenge.opponentScore >= 0
                            if (!userHasPlayed) {
                                Button(
                                    onClick = { viewModel.playButtonClick(); viewModel.playChallengeMatch(challenge) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC78414)),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("⚔️ JOGAR DESAFIO AGORA", fontWeight = FontWeight.Black, color = Color.White)
                                }
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Sua pontuação foi registrada! Aguardando oponente jogar.",
                                        fontSize = 11.sp,
                                        color = MutedGreyGreen,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        } else if (challenge.status == "completed") {
                            val msg = when (challenge.winner) {
                                viewModel.firebaseUsername.value -> "🏆 VOCÊ VENCEU! +${challenge.betAmount * 2} Moedas adicionadas."
                                "draw" -> "🤝 DEU EMPATE! Ambas as apostas foram devolvidas."
                                else -> "☠️ VOCÊ PERDEU! @${challenge.winner} faturou o pote."
                            }
                            Text(
                                text = msg,
                                fontWeight = FontWeight.Bold,
                                color = if (challenge.winner == viewModel.firebaseUsername.value) ForestGreen else if (challenge.winner == "draw") Color.Gray else Color.Red,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FriendsTabContent(viewModel: InsectGameViewModel, friends: Map<String, String>) {
    var searchInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Invite system row
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderLightSystem)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "👥 Convidar Amigos por Apelido",
                        fontWeight = FontWeight.Bold,
                        color = DarkForestText,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchInput,
                            onValueChange = { searchInput = it.lowercase().replace(" ", "") },
                            label = { Text("Apelido do Jogador") },
                            placeholder = { Text("ex: esmagador99") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ForestGreen)
                        )

                        Button(
                            onClick = {
                                viewModel.playButtonClick()
                                viewModel.sendFriendRequest(searchInput)
                                searchInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                            modifier = Modifier.height(56.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Adicionar", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // List header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Gerenciar Amizades", color = SageGreenDense, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                IconButton(onClick = { viewModel.playButtonClick(); viewModel.refreshFriends() }) {
                    Icon(Icons.Default.Refresh, "Atualizar", tint = ForestGreen)
                }
            }
        }

        val friendList = friends.toList()
        if (friendList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Nenhum amigo adicionado ainda. Convide seus colegas de chinelo!",
                        color = MutedGreyGreen,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(friendList) { (friendName, status) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderLightSystem)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(SageGreenLight, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("👤", fontSize = 20.sp)
                            }
                            Column {
                                Text(
                                    text = "@$friendName",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = DarkForestText
                                )
                                Text(
                                    text = when (status) {
                                        "accepted" -> "Amigos"
                                        "pending_sent" -> "Convite enviado"
                                        "pending_received" -> "Te enviou solicitação"
                                        else -> status
                                    },
                                    fontSize = 11.sp,
                                    color = MutedGreyGreen
                                )
                            }
                        }

                        // Actions
                        if (status == "pending_received") {
                            Button(
                                onClick = { viewModel.playButtonClick(); viewModel.acceptFriendRequest(friendName) },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Aceitar", fontSize = 12.sp, color = Color.White)
                            }
                        } else if (status == "accepted") {
                            Icon(Icons.Default.CheckCircle, "Amigos", tint = ForestGreen)
                        } else {
                            Icon(Icons.Default.HourglassEmpty, "Aguardando", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OnlineRankingTabContent(
    viewModel: InsectGameViewModel,
    ranking: List<PlayerProfile>,
    currentUser: String?
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Líderes Mundiais Ativos 🏆",
                    color = SageGreenDense,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                IconButton(onClick = { viewModel.playButtonClick(); viewModel.refreshGlobalRanking() }) {
                    Icon(Icons.Default.Refresh, "Atualizar", tint = ForestGreen)
                }
            }
        }

        if (ranking.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Nenhum jogador no ranking... Seja o primeiro!",
                        color = MutedGreyGreen,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(ranking.size) { index ->
                val player = ranking[index]
                val isMe = (currentUser != null && player.nickname == currentUser)

                val rankNum = index + 1
                val medal = when (rankNum) {
                    1 -> "🥇 "
                    2 -> "🥈 "
                    3 -> "🥉 "
                    else -> "⚓ "
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isMe) SageGreenLight else Color.White
                    ),
                    border = if (isMe) {
                        BorderStroke(1.5.dp, ForestGreen)
                    } else {
                        BorderStroke(1.dp, BorderLightSystem)
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "$rankNum",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                color = if (isMe) ForestGreen else DarkForestText,
                                modifier = Modifier.width(20.dp)
                            )
                            Text(AVATAR_EMOJIS.getOrElse(player.avatarId) { "👵" }, fontSize = 24.sp)
                            
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = player.nickname,
                                        color = DarkForestText,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    if (isMe) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "(Você)",
                                            fontSize = 9.sp,
                                            color = ForestGreen,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = "Esmagou: ${player.totalSquashed} bichos",
                                    fontSize = 10.sp,
                                    color = MutedGreyGreen
                                )
                            }
                        }

                        Text(
                            text = "$medal${player.highScoreEndless} pts",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = ForestGreen
                        )
                    }
                }
            }
        }
    }
}
