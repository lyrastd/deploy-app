package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LyraColorScheme = darkColorScheme(
    primary = LyraPrimary,
    secondary = LyraSecondary,
    tertiary = LyraTertiary,
    background = DarkBackground,
    surface = DarkSurface,
    onPrimary = Color(0xFF04060C),
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    error = LyraGlowRed
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LyraColorScheme,
        typography = Typography,
        content = content
    )
}
