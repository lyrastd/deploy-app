package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_channels")
data class SavedChannel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val streamUrl: String,
    val category: String = "Geral",
    val resolution: String = "1080p",
    val isFavorite: Boolean = false,
    val lastUsed: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_preferences")
data class UserPreference(
    @PrimaryKey val id: Int = 1,
    val genrePreferences: String = "Notícias, Esportes, Tecnologia, Natureza",
    val personalizedEpgJson: String = ""
)
