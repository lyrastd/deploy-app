package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [PlayerProfile::class], version = 4, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract val playerDao: PlayerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bug_smasher_database"
                )
                .addCallback(DatabaseCallback())
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Pre-populate simulated players for the leaderboard
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        val dao = database.playerDao
                        val currentProfiles = dao.getAllProfiles()
                        if (currentProfiles.isEmpty()) {
                            // Let's seed some fun simulated accounts with different scores and achievements
                            val players = listOf(
                                PlayerProfile(
                                    nickname = "Esmagador99",
                                    avatarId = 1,
                                    totalSquashed = 2300,
                                    highScoreEndless = 450,
                                    levelReached = 8,
                                    gold = 1200,
                                    diamonds = 12
                                ),
                                PlayerProfile(
                                    nickname = "ChineladaVeloz",
                                    avatarId = 2,
                                    totalSquashed = 1950,
                                    highScoreEndless = 380,
                                    levelReached = 6,
                                    gold = 850,
                                    diamonds = 5
                                ),
                                PlayerProfile(
                                    nickname = "DonaRute_DoCapacho",
                                    avatarId = 3,
                                    totalSquashed = 1450,
                                    highScoreEndless = 295,
                                    levelReached = 5,
                                    gold = 520,
                                    diamonds = 4
                                ),
                                PlayerProfile(
                                    nickname = "MembroDoGreenpeace", // Funny bio: is protective but plays anyway
                                    avatarId = 4,
                                    totalSquashed = 400,
                                    highScoreEndless = 90,
                                    levelReached = 2,
                                    gold = 150,
                                    diamonds = 2
                                ),
                                PlayerProfile(
                                    nickname = "DedosDeAço",
                                    avatarId = 5,
                                    totalSquashed = 3100,
                                    highScoreEndless = 580,
                                    levelReached = 10,
                                    gold = 2500,
                                    diamonds = 15
                                ),
                                // Active default user
                                PlayerProfile(
                                    nickname = "Jogador",
                                    avatarId = 0,
                                    isCurrentUser = true,
                                    gold = 2000,
                                    diamonds = 3
                                )
                            )
                            for (p in players) {
                                dao.insertPlayer(p)
                            }
                        }
                    }
                }
            }
        }
    }
}
