package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlin.random.Random

class PlayerRepository(private val playerDao: PlayerDao) {
    val allProfiles: Flow<List<PlayerProfile>> = playerDao.getAllProfilesFlow()
    val currentPlayer: Flow<PlayerProfile?> = playerDao.getCurrentPlayerFlow()

    suspend fun getAllProfilesDirect(): List<PlayerProfile> = withContext(Dispatchers.IO) {
        playerDao.getAllProfiles()
    }

    suspend fun getCurrentPlayerDirect(): PlayerProfile? = withContext(Dispatchers.IO) {
        playerDao.getCurrentPlayer()
    }

    suspend fun getPlayerById(id: Int): PlayerProfile? = withContext(Dispatchers.IO) {
        playerDao.getPlayerById(id)
    }

    suspend fun insert(player: PlayerProfile): Long = withContext(Dispatchers.IO) {
        playerDao.insertPlayer(player)
    }

    suspend fun update(player: PlayerProfile) = withContext(Dispatchers.IO) {
        playerDao.updatePlayer(player)
    }

    suspend fun delete(player: PlayerProfile) = withContext(Dispatchers.IO) {
        playerDao.deletePlayer(player)
    }

    suspend fun setActivePlayer(playerId: Int) = withContext(Dispatchers.IO) {
        playerDao.setActivePlayer(playerId)
    }

    // Dynamic Simulated Competition: other players progress a bit when called!
    suspend fun simulateLiveCompetitionProgress() = withContext(Dispatchers.IO) {
        val all = playerDao.getAllProfiles()
        for (profile in all) {
            // Only update automated players, i.e., those that are NOT current user
            if (!profile.isCurrentUser) {
                val shouldGrow = Random.nextFloat() < 0.40f // 40% chance of highscore growth
                if (shouldGrow) {
                    val squashedDelta = Random.nextInt(15, 60)
                    val scoreDelta = Random.nextInt(5, 25)
                    val newGoldDelta = Random.nextInt(10, 50)
                    val newReached = if (Random.nextFloat() < 0.15f && profile.levelReached < 10) profile.levelReached + 1 else profile.levelReached
                    
                    val updated = profile.copy(
                        totalSquashed = profile.totalSquashed + squashedDelta,
                        highScoreEndless = profile.highScoreEndless + scoreDelta,
                        gold = profile.gold + newGoldDelta,
                        levelReached = newReached
                    )
                    playerDao.updatePlayer(updated)
                }
            }
        }
    }
}
