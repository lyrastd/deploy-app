package com.example.data

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.UUID

object FirebaseManager {
    private const val TAG = "FirebaseManager"
    private const val DATABASE_URL = "https://assistantcreator-79401-default-rtdb.firebaseio.com"
    private const val API_KEY = "AIzaSyAQWV02yApwC2sKfyea2PQWGQXEXn5TZgg"
    
    @Volatile
    private var isDatabasePublic = false
    
    private val client = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val request = chain.request()
            var response = chain.proceed(request)
            val urlString = request.url.toString()
            if (!response.isSuccessful && response.code == 401 && urlString.startsWith(DATABASE_URL)) {
                val url = request.url
                if (url.queryParameter("auth") != null) {
                    val newUrl = url.newBuilder().removeAllQueryParameters("auth").build()
                    Log.d(TAG, "Database request returned 401. Retrying WITHOUT auth parameter: $newUrl")
                    response.close()
                    val newRequest = request.newBuilder().url(newUrl).build()
                    response = chain.proceed(newRequest)
                    if (response.isSuccessful) {
                        isDatabasePublic = true
                    }
                }
            }
            response
        }
        .build()
        
    private val mediaTypeJson = "application/json; charset=utf-8".toMediaType()

    private var cachedIdToken: String? = null

    init {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                wipeDatabaseAccounts(listOf("thiagu.mangara@gmail.com", "lyrastd.smartsolutions@gmail.com", "lyrastudio.smartsolutions@gmail.com"))
            } catch (e: Exception) {
                Log.e(TAG, "Error performing startup superuser database cleanup", e)
            }
        }
    }

    // Register a standard Firebase sign-in for Google/password users
    private suspend fun fetchAnonymousToken(): String? = withContext(Dispatchers.IO) {
        val url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$API_KEY"
        val bodyJson = JSONObject().apply {
            put("returnSecureToken", true)
        }
        val body = bodyJson.toString().toRequestBody(mediaTypeJson)
        val request = Request.Builder().url(url).post(body).build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val respStr = response.body?.string() ?: return@withContext null
                    val json = JSONObject(respStr)
                    return@withContext json.optString("idToken", null)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching anonymous token", e)
        }
        return@withContext null
    }

    // Shadow system guest token fallback if anonymous sign-in is disabled in Firebase Console
    private suspend fun fetchSystemGuestToken(): String? = withContext(Dispatchers.IO) {
        val email = "system_guest@esmagainsetos.com"
        val password = "system_guest_passwd_88!"
        
        // Try sign in first
        val signInUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$API_KEY"
        val bodyJson = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("returnSecureToken", true)
        }
        var body = bodyJson.toString().toRequestBody(mediaTypeJson)
        var request = Request.Builder().url(signInUrl).post(body).build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val respStr = response.body?.string() ?: return@withContext null
                    val json = JSONObject(respStr)
                    return@withContext json.optString("idToken", null)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error logging in system guest", e)
        }

        // If sign in fails, try sign up
        val signUpUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$API_KEY"
        request = Request.Builder().url(signUpUrl).post(body).build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val respStr = response.body?.string() ?: return@withContext null
                    val json = JSONObject(respStr)
                    return@withContext json.optString("idToken", null)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error registering system guest", e)
        }
        return@withContext null
    }

    private suspend fun getOrFetchToken(): String? {
        if (cachedIdToken != null) return cachedIdToken
        
        // 1. Try anonymous token first
        val anon = fetchAnonymousToken()
        if (anon != null) {
            cachedIdToken = anon
            return anon
        }
        
        // 2. Try shadow system guest token
        val systemToken = fetchSystemGuestToken()
        if (systemToken != null) {
            cachedIdToken = systemToken
            return systemToken
        }
        
        return null
    }

    private suspend fun appendAuth(url: String): String {
        if (isDatabasePublic) return url
        val token = getOrFetchToken()
        return if (token != null) {
            if (url.contains("?")) "$url&auth=$token" else "$url?auth=$token"
        } else {
            url
        }
    }

    private suspend fun authenticateAuthUser(email: String, password: String): String? = withContext(Dispatchers.IO) {
        val url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$API_KEY"
        val bodyJson = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("returnSecureToken", true)
        }
        val body = bodyJson.toString().toRequestBody(mediaTypeJson)
        val request = Request.Builder().url(url).post(body).build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val respStr = response.body?.string() ?: return@withContext null
                    val json = JSONObject(respStr)
                    return@withContext json.optString("idToken", null)
                } else {
                    Log.e(TAG, "signInWithPassword failed: ${response.code} - ${response.body?.string()}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in authenticateAuthUser", e)
        }
        return@withContext null
    }

    sealed class AuthResult {
        data class Success(val idToken: String) : AuthResult()
        data class Error(val message: String) : AuthResult()
    }

    private suspend fun performSignUp(email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$API_KEY"
        val bodyJson = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("returnSecureToken", true)
        }
        val body = bodyJson.toString().toRequestBody(mediaTypeJson)
        val request = Request.Builder().url(url).post(body).build()
        try {
            client.newCall(request).execute().use { response ->
                val respStr = response.body?.string()
                if (response.isSuccessful && respStr != null) {
                    val json = JSONObject(respStr)
                    val token = json.optString("idToken", "")
                    return@withContext AuthResult.Success(token)
                } else if (respStr != null) {
                    try {
                        val errorObj = JSONObject(respStr).optJSONObject("error")
                        val errorMsg = errorObj?.optString("message") ?: ""
                        if (errorMsg == "EMAIL_EXISTS") {
                            val cleanEmail = email.lowercase().trim()
                            if (cleanEmail == "thiagu.mangara@gmail.com" || cleanEmail == "lyrastd.smartsolutions@gmail.com") {
                                val token = authenticateAuthUser(email, password)
                                if (token != null) {
                                    return@withContext AuthResult.Success(token)
                                }
                            }
                            return@withContext AuthResult.Error("Este e-mail já está registrado.")
                        } else if (errorMsg.startsWith("WEAK_PASSWORD")) {
                            return@withContext AuthResult.Error("A senha é muito fraca (mínimo de 6 caracteres).")
                        } else if (errorMsg == "INVALID_EMAIL") {
                            return@withContext AuthResult.Error("E-mail inválido.")
                        }
                        return@withContext AuthResult.Error("Erro do Firebase Auth: $errorMsg")
                    } catch (e: Exception) {
                        return@withContext AuthResult.Error("Erro de cadastro: Código ${response.code}")
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext AuthResult.Error("Conexão falhou: ${e.message}")
        }
        return@withContext AuthResult.Error("Erro desconhecido de cadastro.")
    }

    // Helper to sanitize emails as Firebase keys
    fun sanitizeEmail(email: String): String {
        return email.lowercase().replace(".", "_").replace("@", "_")
    }

    // Check if username is already taken
    suspend fun isUsernameTaken(username: String): Boolean = withContext(Dispatchers.IO) {
        val cleanUsername = username.lowercase().trim().replace(" ", "")
        if (cleanUsername.isEmpty()) return@withContext true
        val url = appendAuth("$DATABASE_URL/users/$cleanUsername.json")
        
        val request = Request.Builder()
            .url(url)
            .get()
            .build()
        
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val bodyString = response.body?.string()
                if (bodyString == null) return@withContext false
                val trimmed = bodyString.trim()
                if (trimmed == "null" || trimmed.isEmpty()) return@withContext false
                
                // If body has error field (like Permission Denied), don't block
                val isError = try {
                    val json = JSONObject(trimmed)
                    json.has("error")
                } catch (e: Exception) {
                    false
                }
                if (isError) return@withContext false
                
                // Ensure it is a valid JSON object depicting user fields
                val hasUsername = try {
                    val json = JSONObject(trimmed)
                    json.has("username")
                } catch (e: Exception) {
                    false
                }
                return@withContext hasUsername
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking username uniqueness", e)
            return@withContext false
        }
    }

    // Register a new user
    suspend fun registerUser(
        email: String,
        password: String,
        username: String,
        avatarId: Int,
        onSuccess: (PlayerProfile) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val cleanUsername = username.lowercase().trim().replace(" ", "")
        val cleanEmail = email.lowercase().trim()
        val isSuperuserEmail = cleanEmail == "thiagu.mangara@gmail.com" || cleanEmail == "lyrastd.smartsolutions@gmail.com"

        if (cleanUsername.isEmpty()) {
            onError("Nome de usuário não pode ser vazio.")
            return@withContext
        }
        if (cleanEmail.isEmpty() || password.isEmpty()) {
            onError("E-mail e senha não podem ser vazios.")
            return@withContext
        }

        // 1. Authenticate / get guest token to perform uniqueness checks
        val guestToken = getOrFetchToken()
        if (guestToken == null) {
            onError("Falha na conexão de autenticação do servidor (Sem Token).")
            return@withContext
        }

        if (!isSuperuserEmail && isUsernameTaken(cleanUsername)) {
            onError("O nome de usuário '$cleanUsername' já está em uso.")
            return@withContext
        }

        // 2. Clear token cache and register email & password in Firebase Auth REST API
        when (val authRes = performSignUp(cleanEmail, password)) {
            is AuthResult.Error -> {
                onError(authRes.message)
                return@withContext
            }
            is AuthResult.Success -> {
                cachedIdToken = authRes.idToken
            }
        }

        // 3. Register custom RTDB database structures under the user's authentic token
        val sanitizedEmail = sanitizeEmail(cleanEmail)
        val authUrl = appendAuth("$DATABASE_URL/auth_accounts/$sanitizedEmail.json")
        val authJson = JSONObject().apply {
            put("email", cleanEmail)
            put("password", password)
            put("username", cleanUsername)
        }
        val authBody = authJson.toString().toRequestBody(mediaTypeJson)
        val authRequest = Request.Builder().url(authUrl).put(authBody).build()

        try {
            client.newCall(authRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    onError("Falha ao registrar credenciais de autenticação no banco.")
                    return@withContext
                }
            }
        } catch (e: Exception) {
            onError("Erro de conexão ao criar conta: ${e.message}")
            return@withContext
        }

        // 4. Map email to username for sign-in lookup
        val emailMapUrl = appendAuth("$DATABASE_URL/emails/$sanitizedEmail.json")
        val emailMapBody = "\"$cleanUsername\"".toRequestBody(mediaTypeJson)
        val emailMapRequest = Request.Builder().url(emailMapUrl).put(emailMapBody).build()
        try {
            client.newCall(emailMapRequest).execute().use { res ->
                if (!res.isSuccessful) Log.e(TAG, "Failed mapping email to username")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error mapping email", e)
        }

        // 5. Create user details profile in Realtime DB
        val userDetailsUrl = appendAuth("$DATABASE_URL/users/$cleanUsername.json")
        val profile = PlayerProfile(
            nickname = cleanUsername,
            avatarId = avatarId,
            gold = if (isSuperuserEmail) 999999 else 100,
            highScoreEndless = 0,
            totalSquashed = 0,
            levelReached = if (isSuperuserEmail) 8 else 1,
            isCurrentUser = true,
            firebaseEmail = cleanEmail,
            onlineUsername = cleanUsername,
            instagram = null,
            sprayCount = if (isSuperuserEmail) 99 else 3,
            freezeCount = if (isSuperuserEmail) 99 else 3,
            tripleSquashCount = if (isSuperuserEmail) 99 else 1,
            diamonds = if (isSuperuserEmail) 9999 else 0,
            purchasedScenarios = if (isSuperuserEmail) "kitchen,wood,picnic,sand,garden,textile,sewer,space" else "kitchen",
            purchasedSkins = if (isSuperuserEmail) "default,green,blue,rainbow" else "default"
        )
        val userJson = JSONObject().apply {
            put("username", cleanUsername)
            put("email", cleanEmail)
            put("avatarId", avatarId)
            put("gold", if (isSuperuserEmail) 999999 else 100)
            put("highScoreEndless", 0)
            put("totalSquashed", 0)
            put("levelReached", if (isSuperuserEmail) 8 else 1)
            put("purchasedScenarios", if (isSuperuserEmail) "kitchen,wood,picnic,sand,garden,textile,sewer,space" else "kitchen")
            put("purchasedSkins", if (isSuperuserEmail) "default,green,blue,rainbow" else "default")
            put("selectedScenario", "kitchen")
            put("selectedSkin", "default")
            put("sprayCount", if (isSuperuserEmail) 99 else 3)
            put("freezeCount", if (isSuperuserEmail) 99 else 3)
            put("tripleSquashCount", if (isSuperuserEmail) 99 else 1)
            put("diamonds", if (isSuperuserEmail) 9999 else 0)
            put("instagram", "")
        }
        val userBody = userJson.toString().toRequestBody(mediaTypeJson)
        val userRequest = Request.Builder().url(userDetailsUrl).put(userBody).build()

        try {
            client.newCall(userRequest).execute().use { response ->
                if (response.isSuccessful) {
                    onSuccess(profile)
                } else {
                    onError("Falha ao inicializar o perfil do jogador no servidor ${response.code}.")
                }
            }
        } catch (e: Exception) {
            onError("Erro de conexão ao criar perfil: ${e.message}")
        }
    }

    // Login user
    suspend fun loginUser(
        email: String,
        password: String,
        onSuccess: (PlayerProfile) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val cleanEmail = email.lowercase().trim()
        val isSuperuserEmail = cleanEmail == "thiagu.mangara@gmail.com" || cleanEmail == "lyrastd.smartsolutions@gmail.com"
        if (cleanEmail.isEmpty() || password.isEmpty()) {
            onError("E-mail e senha não podem ser vazios.")
            return@withContext
        }

        // Authenticate with Firebase Auth REST API first to verify password and configure token
        val authIdToken = authenticateAuthUser(cleanEmail, password)
        if (authIdToken == null) {
            onError("E-mail ou senha incorretos (ou falha na autenticação do Firebase).")
            return@withContext
        }
        cachedIdToken = authIdToken

        // Now fetch auth details from RTDB securely with our freshly minted account token
        val sanitizedEmail = sanitizeEmail(cleanEmail)
        val authUrl = appendAuth("$DATABASE_URL/auth_accounts/$sanitizedEmail.json")
        val authRequest = Request.Builder().url(authUrl).get().build()

        try {
            client.newCall(authRequest).execute().use { response ->
                val bodyString = response.body?.string()
                if (bodyString == null || bodyString.trim() == "null") {
                    onError("Usuário do banco de dados não encontrado.")
                    return@withContext
                }

                val authJson = JSONObject(bodyString)
                val username = authJson.optString("username", "")
                val finalUsername = if (username.isNotEmpty()) username else "thiagu"

                // Fetch detailed profile from Firebase RTDB
                val userDetailsUrl = appendAuth("$DATABASE_URL/users/$finalUsername.json")
                val profileRequest = Request.Builder().url(userDetailsUrl).get().build()
                client.newCall(profileRequest).execute().use { detailsResponse ->
                    val detailsString = detailsResponse.body?.string()
                    val userJson = if (detailsString == null || detailsString.trim() == "null" || detailsString.trim().isEmpty()) {
                        JSONObject()
                    } else {
                        JSONObject(detailsString)
                    }

                    val profile = PlayerProfile(
                        nickname = finalUsername,
                        avatarId = userJson.optInt("avatarId", 0),
                        gold = if (isSuperuserEmail) 999999 else userJson.optInt("gold", 100),
                        highScoreEndless = userJson.optInt("highScoreEndless", 0),
                        totalSquashed = userJson.optInt("totalSquashed", 0),
                        levelReached = if (isSuperuserEmail) 8 else userJson.optInt("levelReached", 1),
                        isCurrentUser = true,
                        purchasedScenarios = if (isSuperuserEmail) "kitchen,wood,picnic,sand,garden,textile,sewer,space" else userJson.optString("purchasedScenarios", "kitchen"),
                        purchasedSkins = if (isSuperuserEmail) "default,green,blue,rainbow" else userJson.optString("purchasedSkins", "default"),
                        selectedScenario = userJson.optString("selectedScenario", "kitchen"),
                        selectedSkin = userJson.optString("selectedSkin", "default"),
                        sprayCount = if (isSuperuserEmail) 99 else userJson.optInt("sprayCount", 3),
                        freezeCount = if (isSuperuserEmail) 99 else userJson.optInt("freezeCount", 3),
                        tripleSquashCount = if (isSuperuserEmail) 99 else userJson.optInt("tripleSquashCount", 1),
                        diamonds = if (isSuperuserEmail) 9999 else userJson.optInt("diamonds", 0),
                        firebaseEmail = cleanEmail,
                        onlineUsername = finalUsername,
                        instagram = if (userJson.has("instagram") && !userJson.isNull("instagram")) {
                            val v = userJson.optString("instagram", null)
                            if (v == null || v == "null" || v.isBlank()) null else v
                        } else null
                    )
                    onSuccess(profile)
                }
            }
        } catch (e: Exception) {
            onError("Erro de conexão ao carregar perfil: ${e.message}")
        }
    }

    // Google Sign-In / Account Authentication
    suspend fun authenticateWithGoogle(
        email: String,
        onSuccess: (PlayerProfile) -> Unit,
        onNeedsRegistration: (String) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val cleanEmail = email.lowercase().trim()
        val sanitizedEmail = sanitizeEmail(cleanEmail)
        val isSuperuserEmail = cleanEmail == "thiagu.mangara@gmail.com" || cleanEmail == "lyrastd.smartsolutions@gmail.com"
        
        // Ensure we're authenticated to see if they already exist
        val systemToken = getOrFetchToken()
        if (systemToken == null) {
            onError("Falha na autenticação com o Firebase (Sem Token).")
            return@withContext
        }

        // Check if email already registered
        val emailLookupUrl = appendAuth("$DATABASE_URL/emails/$sanitizedEmail.json")
        val request = Request.Builder().url(emailLookupUrl).get().build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    onError("Erro ao verificar conta Google com o Firebase (Código ${response.code}).")
                    return@withContext
                }
                val body = response.body?.string()
                val trimmed = body?.trim() ?: "null"
                
                val isQuotedString = trimmed.startsWith("\"") && trimmed.endsWith("\"") && trimmed.length > 2
                
                if (!isQuotedString && trimmed != "null" && trimmed.isNotEmpty()) {
                    // Check for firebase error object
                    val isFirebaseError = try {
                        val json = JSONObject(trimmed)
                        json.has("error")
                    } catch (e: Exception) {
                        false
                    }
                    if (isFirebaseError) {
                        val errorContent = JSONObject(trimmed).optString("error", "Erro desconhecido")
                        onError("Erro do Firebase: $errorContent")
                        return@withContext
                    }
                }
                
                if (!isQuotedString) {
                    // Not registered yet!
                    onNeedsRegistration(cleanEmail)
                } else {
                    // Already registered! Load username and fetch profile
                    val username = trimmed.replace("\"", "") // Remove quotes
                    val userDetailsUrl = appendAuth("$DATABASE_URL/users/$username.json")
                    val profileRequest = Request.Builder().url(userDetailsUrl).get().build()
                    client.newCall(profileRequest).execute().use { detailsResponse ->
                        val detailsString = detailsResponse.body?.string()
                        val userJson = if (detailsString == null || detailsString.trim() == "null" || detailsString.trim().isEmpty()) {
                            JSONObject()
                        } else {
                            JSONObject(detailsString)
                        }
                        
                        val profile = PlayerProfile(
                            nickname = username,
                            avatarId = userJson.optInt("avatarId", 0),
                            gold = if (isSuperuserEmail) 999999 else userJson.optInt("gold", 100),
                            highScoreEndless = userJson.optInt("highScoreEndless", 0),
                            totalSquashed = userJson.optInt("totalSquashed", 0),
                            levelReached = if (isSuperuserEmail) 8 else userJson.optInt("levelReached", 1),
                            isCurrentUser = true,
                            purchasedScenarios = if (isSuperuserEmail) "kitchen,wood,picnic,sand,garden,textile,sewer,space" else userJson.optString("purchasedScenarios", "kitchen"),
                            purchasedSkins = if (isSuperuserEmail) "default,green,blue,rainbow" else userJson.optString("purchasedSkins", "default"),
                            selectedScenario = userJson.optString("selectedScenario", "kitchen"),
                            selectedSkin = userJson.optString("selectedSkin", "default"),
                            sprayCount = if (isSuperuserEmail) 99 else userJson.optInt("sprayCount", 3),
                            freezeCount = if (isSuperuserEmail) 99 else userJson.optInt("freezeCount", 3),
                            tripleSquashCount = if (isSuperuserEmail) 99 else userJson.optInt("tripleSquashCount", 1),
                            diamonds = if (isSuperuserEmail) 9999 else userJson.optInt("diamonds", 0),
                            firebaseEmail = cleanEmail,
                            onlineUsername = username,
                            instagram = if (userJson.has("instagram") && !userJson.isNull("instagram")) {
                                val v = userJson.optString("instagram", null)
                                if (v == null || v == "null" || v.isBlank()) null else v
                            } else null
                        )
                        onSuccess(profile)
                    }
                }
            }
        } catch (e: Exception) {
            onError("Erro de conexão ao Google Auth: ${e.message}")
        }
    }

    suspend fun registerGoogleUser(
        email: String,
        username: String,
        avatarId: Int,
        onSuccess: (PlayerProfile) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val randomPassword = "GoogleAuth_${UUID.randomUUID().toString().take(12)}"
        registerUser(
            email = email,
            password = randomPassword,
            username = username,
            avatarId = avatarId,
            onSuccess = onSuccess,
            onError = onError
        )
    }

    // Sync profile metrics back to Firebase RTDB
    suspend fun syncProfile(profile: PlayerProfile) = withContext(Dispatchers.IO) {
        val username = profile.onlineUsername ?: return@withContext
        val url = appendAuth("$DATABASE_URL/users/$username.json")
        
        // Load existing user details to merge friends and challenges so they aren't overwritten
        var friendsObj = JSONObject()
        var challengesObj = JSONObject()
        try {
            val getRequest = Request.Builder().url(url).get().build()
            client.newCall(getRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string()
                    if (bodyString != null && bodyString.trim() != "null") {
                        val root = JSONObject(bodyString)
                        friendsObj = root.optJSONObject("friends") ?: JSONObject()
                        challengesObj = root.optJSONObject("challenges") ?: JSONObject()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching profile for merging key stats", e)
        }

        val userJson = JSONObject().apply {
            put("username", username)
            put("email", profile.firebaseEmail)
            put("avatarId", profile.avatarId)
            put("gold", profile.gold)
            put("highScoreEndless", profile.highScoreEndless)
            put("totalSquashed", profile.totalSquashed)
            put("levelReached", profile.levelReached)
            put("purchasedScenarios", profile.purchasedScenarios)
            put("purchasedSkins", profile.purchasedSkins)
            put("selectedScenario", profile.selectedScenario)
            put("selectedSkin", profile.selectedSkin)
            put("sprayCount", profile.sprayCount)
            put("freezeCount", profile.freezeCount)
            put("tripleSquashCount", profile.tripleSquashCount)
            put("diamonds", profile.diamonds)
            put("instagram", profile.instagram ?: "")
            if (friendsObj.length() > 0) put("friends", friendsObj)
            if (challengesObj.length() > 0) put("challenges", challengesObj)
        }

        val body = userJson.toString().toRequestBody(mediaTypeJson)
        val request = Request.Builder().url(url).put(body).build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Failed to sync player stats: ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing player stats", e)
        }
    }

    // Fetch all usernames and scores to construct Global Ranking
    suspend fun fetchGlobalRanking(): List<PlayerProfile> = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/users.json")
        val request = Request.Builder().url(url).get().build()
        val list = mutableListOf<PlayerProfile>()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()
                val bodyString = response.body?.string() ?: return@withContext emptyList()
                if (bodyString.trim() == "null" || bodyString.trim().isEmpty()) return@withContext emptyList()

                val root = JSONObject(bodyString)
                val keys = root.keys()
                while (keys.hasNext()) {
                    val username = keys.next()
                    val userJson = root.getJSONObject(username)
                    
                    val profile = PlayerProfile(
                        id = username.hashCode(),
                        nickname = username,
                        avatarId = userJson.optInt("avatarId", 0),
                        gold = userJson.optInt("gold", 100),
                        highScoreEndless = userJson.optInt("highScoreEndless", 0),
                        totalSquashed = userJson.optInt("totalSquashed", 0),
                        levelReached = userJson.optInt("levelReached", 1),
                        isCurrentUser = false,
                        purchasedScenarios = userJson.optString("purchasedScenarios", "kitchen"),
                        purchasedSkins = userJson.optString("purchasedSkins", "default"),
                        selectedScenario = userJson.optString("selectedScenario", "kitchen"),
                        selectedSkin = userJson.optString("selectedSkin", "default"),
                        sprayCount = userJson.optInt("sprayCount", 3),
                        freezeCount = userJson.optInt("freezeCount", 3),
                        tripleSquashCount = userJson.optInt("tripleSquashCount", 1),
                        diamonds = userJson.optInt("diamonds", 0),
                        firebaseEmail = userJson.optString("email", ""),
                        onlineUsername = username,
                        instagram = if (userJson.has("instagram") && !userJson.isNull("instagram")) {
                            val v = userJson.optString("instagram", null)
                            if (v == null || v == "null" || v.isBlank()) null else v
                        } else null
                    )
                    list.add(profile)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching global ranking", e)
        }
        return@withContext list.sortedByDescending { it.highScoreEndless }
    }

    // Friend list functions: Send request
    suspend fun sendFriendRequest(
        fromUser: String,
        toUser: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val cleanTo = toUser.lowercase().trim()
        if (cleanTo == fromUser) {
            onError("Você não pode adicionar a si mesmo.")
            return@withContext
        }

        // Check if target user exists
        if (!isUsernameTaken(cleanTo)) {
            onError("Jogador '$cleanTo' não existe.")
            return@withContext
        }

        // Set friend flags on both user paths
        val fromUrl = appendAuth("$DATABASE_URL/users/$fromUser/friends/$cleanTo.json")
        val toUrl = appendAuth("$DATABASE_URL/users/$cleanTo/friends/$fromUser.json")

        try {
            // Write statuses: "pending_sent" on sender, "pending_received" on recipient
            val fromBody = "\"pending_sent\"".toRequestBody(mediaTypeJson)
            val toBody = "\"pending_received\"".toRequestBody(mediaTypeJson)

            val fromReq = Request.Builder().url(fromUrl).put(fromBody).build()
            val toReq = Request.Builder().url(toUrl).put(toBody).build()

            val resFrom = client.newCall(fromReq).execute()
            val resTo = client.newCall(toReq).execute()

            if (resFrom.isSuccessful && resTo.isSuccessful) {
                onSuccess()
            } else {
                onError("Falha ao salvar as amizades nos servidores.")
            }
            resFrom.close()
            resTo.close()
        } catch (e: Exception) {
            onError("Erro de conexão ao adicionar amigo: ${e.message}")
        }
    }

    // Accept friend request
    suspend fun acceptFriendRequest(
        fromUser: String,
        toUser: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val fromUrl = appendAuth("$DATABASE_URL/users/$fromUser/friends/$toUser.json")
        val toUrl = appendAuth("$DATABASE_URL/users/$toUser/friends/$fromUser.json")

        try {
            val body = "\"accepted\"".toRequestBody(mediaTypeJson)
            
            val req1 = Request.Builder().url(fromUrl).put(body).build()
            val req2 = Request.Builder().url(toUrl).put(body).build()

            val res1 = client.newCall(req1).execute()
            val res2 = client.newCall(req2).execute()

            if (res1.isSuccessful && res2.isSuccessful) {
                onSuccess()
            } else {
                onError("Erro ao registrar a aceitação da amizade.")
            }
            res1.close()
            res2.close()
        } catch (e: Exception) {
            onError("Falha na amizade: ${e.message}")
        }
    }

    // Fetch friend list map for a user
    suspend fun fetchFriendsList(username: String): Map<String, String> = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/users/$username/friends.json")
        val request = Request.Builder().url(url).get().build()
        val friends = mutableMapOf<String, String>()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyMap()
                val body = response.body?.string() ?: return@withContext emptyMap()
                if (body.trim() == "null" || body.trim().isEmpty()) return@withContext emptyMap()

                val root = JSONObject(body)
                val keys = root.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    friends[key] = root.getString(key)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching friends map for $username", e)
        }
        return@withContext friends
    }

    // --- Challenges engine ---
    suspend fun createChallenge(
        challenger: String,
        opponent: String,
        betAmount: Int,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val challengeId = "chal_" + UUID.randomUUID().toString().replace("-", "").take(12)
        val urlDetails = appendAuth("$DATABASE_URL/challenges/$challengeId.json")

        val challengeJson = JSONObject().apply {
            put("id", challengeId)
            put("challenger", challenger)
            put("opponent", opponent)
            put("betAmount", betAmount)
            put("status", "pending")
            put("challengerScore", -1)
            put("opponentScore", -1)
            put("winner", "")
            put("timestamp", System.currentTimeMillis())
        }

        try {
            val body = challengeJson.toString().toRequestBody(mediaTypeJson)
            val req1 = Request.Builder().url(urlDetails).put(body).build()
            
            client.newCall(req1).execute().use { res1 ->
                if (!res1.isSuccessful) {
                    onError("Falha ao registrar detalhes do desafio.")
                    return@withContext
                }
            }

            // Write reference under user schedules
            val refChallengerUrl = appendAuth("$DATABASE_URL/users/$challenger/challenges/$challengeId.json")
            val refOpponentUrl = appendAuth("$DATABASE_URL/users/$opponent/challenges/$challengeId.json")

            val refBody = "\"pending\"".toRequestBody(mediaTypeJson)
            val reqChallenger = Request.Builder().url(refChallengerUrl).put(refBody).build()
            val reqOpponent = Request.Builder().url(refOpponentUrl).put(refBody).build()

            client.newCall(reqChallenger).execute().close()
            client.newCall(reqOpponent).execute().close()

            onSuccess(challengeId)
        } catch (e: Exception) {
            onError("Conexão falhou ao desafiar: ${e.message}")
        }
    }

    // Accept Challenge
    suspend fun acceptChallenge(
        challengeId: String,
        challenger: String,
        opponent: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/challenges/$challengeId/status.json")
        val refChallenger = appendAuth("$DATABASE_URL/users/$challenger/challenges/$challengeId.json")
        val refOpponent = appendAuth("$DATABASE_URL/users/$opponent/challenges/$challengeId.json")

        try {
            val sBody = "\"accepted\"".toRequestBody(mediaTypeJson)
            
            val rStatus = Request.Builder().url(url).put(sBody).build()
            val rC = Request.Builder().url(refChallenger).put(sBody).build()
            val rO = Request.Builder().url(refOpponent).put(sBody).build()

            val resStatus = client.newCall(rStatus).execute()
            val resC = client.newCall(rC).execute()
            val resO = client.newCall(rO).execute()

            if (resStatus.isSuccessful && resC.isSuccessful && resO.isSuccessful) {
                onSuccess()
            } else {
                onError("Erro ao registrar a aceitação.")
            }
            resStatus.close()
            resC.close()
            resO.close()
        } catch (e: Exception) {
            onError("Erro de conexão ao aceitar: ${e.message}")
        }
    }

    // Decline Challenge
    suspend fun declineChallenge(
        challengeId: String,
        challenger: String,
        opponent: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/challenges/$challengeId/status.json")
        val refChallenger = appendAuth("$DATABASE_URL/users/$challenger/challenges/$challengeId.json")
        val refOpponent = appendAuth("$DATABASE_URL/users/$opponent/challenges/$challengeId.json")

        try {
            val sBody = "\"declined\"".toRequestBody(mediaTypeJson)
            
            val rStatus = Request.Builder().url(url).put(sBody).build()
            val rC = Request.Builder().url(refChallenger).put(sBody).build()
            val rO = Request.Builder().url(refOpponent).put(sBody).build()

            val resStatus = client.newCall(rStatus).execute()
            val resC = client.newCall(rC).execute()
            val resO = client.newCall(rO).execute()

            if (resStatus.isSuccessful && resC.isSuccessful && resO.isSuccessful) {
                onSuccess()
            } else {
                onError("Erro ao registrar cancelamento.")
            }
            resStatus.close()
            resC.close()
            resO.close()
        } catch (e: Exception) {
            onError("Erro de conexão ao cancelar: ${e.message}")
        }
    }

    // Submit user challenge score
    suspend fun submitChallengeScore(
        challengeId: String,
        isChallenger: Boolean,
        score: Int,
        onSuccess: (JSONObject) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val scoreField = if (isChallenger) "challengerScore" else "opponentScore"
        val scoreUrl = appendAuth("$DATABASE_URL/challenges/$challengeId/$scoreField.json")
        val mainUrl = appendAuth("$DATABASE_URL/challenges/$challengeId.json")

        try {
            // Write individual score
            val scBody = "$score".toRequestBody(mediaTypeJson)
            val scoreReq = Request.Builder().url(scoreUrl).put(scBody).build()
            client.newCall(scoreReq).execute().close()

            // Fetch detail to evaluate completion
            val detailReq = Request.Builder().url(mainUrl).get().build()
            client.newCall(detailReq).execute().use { response ->
                val body = response.body?.string() ?: return@withContext
                val challengeJson = JSONObject(body)

                val cScore = challengeJson.optInt("challengerScore", -1)
                val oScore = challengeJson.optInt("opponentScore", -1)

                if (cScore >= 0 && oScore >= 0) {
                    val winnerName = when {
                        cScore > oScore -> challengeJson.getString("challenger")
                        oScore > cScore -> challengeJson.getString("opponent")
                        else -> "draw"
                    }

                    challengeJson.put("status", "completed")
                    challengeJson.put("winner", winnerName)

                    val updateBody = challengeJson.toString().toRequestBody(mediaTypeJson)
                    val updateReq = Request.Builder().url(mainUrl).put(updateBody).build()
                    client.newCall(updateReq).execute().use { upRes ->
                        if (upRes.isSuccessful) {
                            onSuccess(challengeJson)
                        } else {
                            onError("Falha em atualizar a conclusão do desafio.")
                        }
                    }

                    val refChName = challengeJson.getString("challenger")
                    val refOpName = challengeJson.getString("opponent")
                    val refChallengerUrl = appendAuth("$DATABASE_URL/users/$refChName/challenges/$challengeId.json")
                    val refOpponentUrl = appendAuth("$DATABASE_URL/users/$refOpName/challenges/$challengeId.json")

                    val sBody = "\"completed\"".toRequestBody(mediaTypeJson)
                    client.newCall(Request.Builder().url(refChallengerUrl).put(sBody).build()).execute().close()
                    client.newCall(Request.Builder().url(refOpponentUrl).put(sBody).build()).execute().close()

                } else {
                    onSuccess(challengeJson)
                }
            }
        } catch (e: Exception) {
            onError("Conexão falhou ao submeter pontuação: ${e.message}")
        }
    }

    // Fetch individual challenge details
    suspend fun getChallengeDetails(challengeId: String): FirebaseChallenge? = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/challenges/$challengeId.json")
        val request = Request.Builder().url(url).get().build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: return@withContext null
                if (body.trim() == "null" || body.trim().isEmpty()) return@withContext null

                val json = JSONObject(body)
                return@withContext FirebaseChallenge(
                    id = json.optString("id", ""),
                    challenger = json.optString("challenger", ""),
                    opponent = json.optString("opponent", ""),
                    betAmount = json.optInt("betAmount", 0),
                    status = json.optString("status", ""),
                    challengerScore = json.optInt("challengerScore", -1),
                    opponentScore = json.optInt("opponentScore", -1),
                    winner = json.optString("winner", ""),
                    timestamp = json.optLong("timestamp", 0)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching challenge specs for $challengeId", e)
        }
        return@withContext null
    }

    // Fetch list of challenge IDs for a user with their statuses
    suspend fun fetchChallengesForUser(username: String): List<FirebaseChallenge> = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/users/$username/challenges.json")
        val request = Request.Builder().url(url).get().build()
        val list = mutableListOf<FirebaseChallenge>()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()
                val body = response.body?.string() ?: return@withContext emptyList()
                if (body.trim() == "null" || body.trim().isEmpty()) return@withContext emptyList()

                val root = JSONObject(body)
                val keys = root.keys()
                while (keys.hasNext()) {
                    val challengeId = keys.next()
                    val details = getChallengeDetails(challengeId)
                    if (details != null) {
                        list.add(details)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching challenges list for $username", e)
        }
        return@withContext list.sortedByDescending { it.timestamp }
    }

    // Fetch global Pix configuration
    suspend fun getGlobalPixConfig(): JSONObject? = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/global_config/pix.json")
        val request = Request.Builder().url(url).get().build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: return@withContext null
                if (body.trim() == "null" || body.trim().isEmpty()) return@withContext null
                return@withContext JSONObject(body)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching global Pix config", e)
        }
        return@withContext null
    }

    // Update global Pix configuration
    suspend fun updateGlobalPixConfig(pixKey: String, qrCodeBase64: String): Boolean = withContext(Dispatchers.IO) {
        val url = appendAuth("$DATABASE_URL/global_config/pix.json")
        val payload = JSONObject().apply {
            put("pixKey", pixKey)
            put("qrCodeBase64", qrCodeBase64)
        }
        val body = payload.toString().toRequestBody(mediaTypeJson)
        val request = Request.Builder().url(url).put(body).build()
        try {
            client.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting global Pix config", e)
            return@withContext false
        }
    }

    private suspend fun wipeDatabaseAccounts(emails: List<String>) {
        val guestToken = getOrFetchToken()
        for (email in emails) {
            val cleanEmail = email.lowercase().trim()
            val sanitizedEmail = sanitizeEmail(cleanEmail)
            
            // 1. Get mapped username
            val emailMapUrl = appendAuth("$DATABASE_URL/emails/$sanitizedEmail.json")
            val getReq = Request.Builder().url(emailMapUrl).get().build()
            var username: String? = null
            try {
                client.newCall(getReq).execute().use { res ->
                    if (res.isSuccessful) {
                        val body = res.body?.string()?.trim() ?: "null"
                        if (body != "null" && body.isNotEmpty()) {
                            username = body.replace("\"", "")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get username for $cleanEmail during wipe", e)
            }
            
            // 2. Delete emails/$sanitizedEmail.json
            try {
                val deleteEmailReq = Request.Builder().url(emailMapUrl).delete().build()
                client.newCall(deleteEmailReq).execute().close()
                Log.d(TAG, "Wiped email mapping for $cleanEmail")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete email mapping for $cleanEmail", e)
            }
            
            // 3. Delete auth_accounts/$sanitizedEmail.json
            try {
                val authUrl = appendAuth("$DATABASE_URL/auth_accounts/$sanitizedEmail.json")
                val deleteAuthReq = Request.Builder().url(authUrl).delete().build()
                client.newCall(deleteAuthReq).execute().close()
                Log.d(TAG, "Wiped auth account for $cleanEmail")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete auth account for $cleanEmail", e)
            }
            
            // 4. Delete users/$username.json (if found)
            username?.let { name ->
                val userDetailsUrl = appendAuth("$DATABASE_URL/users/$name.json")
                try {
                    val deleteUserReq = Request.Builder().url(userDetailsUrl).delete().build()
                    client.newCall(deleteUserReq).execute().close()
                    Log.d(TAG, "Wiped user details for $name")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to delete user details for $name", e)
                }
            }
        }
    }
}
