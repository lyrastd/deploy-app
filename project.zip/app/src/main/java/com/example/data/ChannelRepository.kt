package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ChannelRepository(private val dao: ChannelDao) {

    val allSavedChannels: Flow<List<SavedChannel>> = dao.getAllSavedChannels()
    val favoriteChannels: Flow<List<SavedChannel>> = dao.getFavoriteChannels()
    val userPreferenceFlow: Flow<UserPreference?> = dao.getUserPreferenceFlow()

    suspend fun insertChannel(channel: SavedChannel) {
        dao.insertChannel(channel)
    }

    suspend fun deleteChannel(channel: SavedChannel) {
        dao.deleteChannel(channel)
    }

    suspend fun setFavorite(channelId: Int, isFavorite: Boolean) {
        dao.setFavorite(channelId, isFavorite)
    }

    suspend fun updateLastUsed(channelId: Int) {
        dao.updateLastUsed(channelId, System.currentTimeMillis())
    }

    suspend fun getUserPreference(): UserPreference {
        return dao.getUserPreference() ?: UserPreference(1, "Notícias, Tecnologia, Ciência", "")
    }

    suspend fun saveUserPreference(prefs: UserPreference) {
        dao.saveUserPreference(prefs)
    }

    // Ensures that default streams exist if the DB is blank on first launch.
    suspend fun prepopulateIfEmpty() {
        val firstList = allSavedChannels.firstOrNull()
        if (firstList.isNullOrEmpty()) {
            val defaults = listOf(
                SavedChannel(
                    name = "NASA TV",
                    streamUrl = "https://ntv1.akamaized.net/hls/live/2014027/NASA-NTV1-HLS/master.m3u8",
                    category = "Ciência",
                    resolution = "1080p",
                    isFavorite = true
                ),
                SavedChannel(
                    name = "Al Jazeera English",
                    streamUrl = "https://live-aljazeera.akamaized.net/aljazeera/english/index.m3u8",
                    category = "Notícias",
                    resolution = "1080p",
                    isFavorite = true
                ),
                SavedChannel(
                    name = "France 24",
                    streamUrl = "https://static.france24.com/live/F24_EN_LO_HLS/live_web.m3u8",
                    category = "Notícias",
                    resolution = "720p",
                    isFavorite = false
                ),
                SavedChannel(
                    name = "DW English",
                    streamUrl = "https://dwstream4-lh.akamaihd.net/i/dwstream4_live@131316/master.m3u8",
                    category = "Notícias",
                    resolution = "720p",
                    isFavorite = false
                ),
                SavedChannel(
                    name = "Gatinhos Brincando",
                    streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    category = "Entretenimento",
                    resolution = "1080p",
                    isFavorite = true
                ),
                SavedChannel(
                    name = "Natureza Selvagem",
                    streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                    category = "Natureza",
                    resolution = "1080p",
                    isFavorite = true
                )
            )
            for (channel in defaults) {
                dao.insertChannel(channel)
            }
        }
    }
}
