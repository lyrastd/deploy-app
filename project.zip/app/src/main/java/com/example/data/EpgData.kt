package com.example.data

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ProgramItem(
    val title: String,
    val time: String, // HH:mm format
    val durationMin: Int,
    val description: String
)

@JsonClass(generateAdapter = true)
data class ChannelEpg(
    val channelName: String,
    val programs: List<ProgramItem>
)

@JsonClass(generateAdapter = true)
data class EpgContainer(
    val epgList: List<ChannelEpg>
)
