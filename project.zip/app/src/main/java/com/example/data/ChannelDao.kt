package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChannelDao {
    @Query("SELECT * FROM saved_channels ORDER BY lastUsed DESC")
    fun getAllSavedChannels(): Flow<List<SavedChannel>>

    @Query("SELECT * FROM saved_channels WHERE isFavorite = 1 ORDER BY name ASC")
    fun getFavoriteChannels(): Flow<List<SavedChannel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: SavedChannel)

    @Delete
    suspend fun deleteChannel(channel: SavedChannel)

    @Query("UPDATE saved_channels SET isFavorite = :isFav WHERE id = :channelId")
    suspend fun setFavorite(channelId: Int, isFav: Boolean)

    @Query("UPDATE saved_channels SET lastUsed = :timestamp WHERE id = :channelId")
    suspend fun updateLastUsed(channelId: Int, timestamp: Long)

    @Query("SELECT * FROM user_preferences WHERE id = 1 LIMIT 1")
    fun getUserPreferenceFlow(): Flow<UserPreference?>

    @Query("SELECT * FROM user_preferences WHERE id = 1 LIMIT 1")
    suspend fun getUserPreference(): UserPreference?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserPreference(prefs: UserPreference)
}
