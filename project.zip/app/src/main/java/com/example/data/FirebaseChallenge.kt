package com.example.data

data class FirebaseChallenge(
    val id: String = "",
    val challenger: String = "",
    val opponent: String = "",
    val betAmount: Int = 0,
    val status: String = "",
    val challengerScore: Int = -1,
    val opponentScore: Int = -1,
    val winner: String = "",
    val timestamp: Long = 0
)
