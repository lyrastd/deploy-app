package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_profiles")
data class PlayerProfile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nickname: String,
    val avatarId: Int = 0, // Icon resources/emoji index
    val totalSquashed: Int = 0,
    val highScoreEndless: Int = 0,
    val levelReached: Int = 1, // Phase completed/accessible
    val gold: Int = 100, // Initial gold budget to buy starting powerups/skins
    val isCurrentUser: Boolean = false,
    val purchasedScenarios: String = "kitchen", // comma separated
    val purchasedSkins: String = "default", // comma separated
    val selectedScenario: String = "kitchen",
    val selectedSkin: String = "default",
    val sprayCount: Int = 3, // Powerup inventory
    val freezeCount: Int = 3, // Powerup inventory
    val tripleSquashCount: Int = 1, // Powerup shoe/damage boost inventory
    val firebaseEmail: String? = null,
    val onlineUsername: String? = null,
    val instagram: String? = null
)
