package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player_profiles ORDER BY highScoreEndless DESC")
    fun getAllProfilesFlow(): Flow<List<PlayerProfile>>

    @Query("SELECT * FROM player_profiles ORDER BY highScoreEndless DESC")
    suspend fun getAllProfiles(): List<PlayerProfile>

    @Query("SELECT * FROM player_profiles WHERE isCurrentUser = 1 LIMIT 1")
    fun getCurrentPlayerFlow(): Flow<PlayerProfile?>

    @Query("SELECT * FROM player_profiles WHERE isCurrentUser = 1 LIMIT 1")
    suspend fun getCurrentPlayer(): PlayerProfile?

    @Query("SELECT * FROM player_profiles WHERE id = :id LIMIT 1")
    suspend fun getPlayerById(id: Int): PlayerProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerProfile): Long

    @Update
    suspend fun updatePlayer(player: PlayerProfile)

    @Delete
    suspend fun deletePlayer(player: PlayerProfile)

    @Transaction
    suspend fun setActivePlayer(playerId: Int) {
        val all = getAllProfiles()
        all.forEach {
            if (it.id == playerId && !it.isCurrentUser) {
                updatePlayer(it.copy(isCurrentUser = true))
            } else if (it.id != playerId && it.isCurrentUser) {
                updatePlayer(it.copy(isCurrentUser = false))
            }
        }
    }
}
