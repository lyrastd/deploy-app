package com.example.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PlayerProfile
import com.example.data.PlayerRepository
import com.example.data.FirebaseManager
import com.example.data.FirebaseChallenge
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

sealed interface GameState {
    object Idle : GameState
    object Playing : GameState
    object Paused : GameState
    data class GameOver(val finalScore: Int, val goldEarned: Int) : GameState
    data class Victory(val finalScore: Int, val goldEarned: Int, val nextLevelUnlocked: Boolean) : GameState
}

class InsectGameViewModel(
    application: Application,
    val repository: PlayerRepository
) : AndroidViewModel(application) {

    private val soundManager = SoundEffectManager(application)
    private var isSeeding = false

    // Firebase Multiplayer & Competitive states
    val firebaseUserEmail = MutableStateFlow<String?>(null)
    val firebaseUsername = MutableStateFlow<String?>(null)
    val globalRankingList = MutableStateFlow<List<PlayerProfile>>(emptyList())
    val friendsMap = MutableStateFlow<Map<String, String>>(emptyMap())
    val challengesList = MutableStateFlow<List<FirebaseChallenge>>(emptyList())
    val activeChallengeToPlay = MutableStateFlow<FirebaseChallenge?>(null)
    val authError = MutableStateFlow<String?>(null)
    val authSuccessMessage = MutableStateFlow<String?>(null)
    val isLoadingOnline = MutableStateFlow(false)

    // Global Pix variables & Superuser indicators
    val globalPixKey = MutableStateFlow("00020101021126580014br.gov.bcb.pix0136lyrastudio.smartsolutions@gmail.com5204000053039865802BR5910LyraStudio6009SAO PAULO62070503***6304E07B")
    val globalPixQrBase64 = MutableStateFlow<String?>(null)
    val isSuperuser = MutableStateFlow(false)
    val currentGameScenario = MutableStateFlow<ScenarioType>(ScenarioType.KITCHEN)

    init {
        soundManager.playMusic(MusicTheme.LOBBY)
        fetchGlobalPixConfig()
        // Check for cached online user profiles and trigger sync
        viewModelScope.launch {
            repository.currentPlayer.collect { current ->
                if (current == null) {
                    if (!isSeeding) {
                        val all = repository.getAllProfilesDirect()
                        if (all.isEmpty()) {
                            isSeeding = true
                            seedDefaultProfiles()
                            isSeeding = false
                        } else {
                            val first = all.firstOrNull()
                            if (first != null) {
                                repository.setActivePlayer(first.id)
                            }
                        }
                    }
                } else {
                    val activeScn = ScenarioType.values().find { it.id == current.selectedScenario } ?: ScenarioType.KITCHEN
                    currentGameScenario.value = activeScn

                    if (current.onlineUsername != null) {
                        firebaseUserEmail.value = current.firebaseEmail
                        firebaseUsername.value = current.onlineUsername
                        // Sync online states
                        refreshGlobalRanking()
                        refreshFriends()
                        refreshChallenges()
                        
                        // Automatically enable superuser mode if they log in as superuser
                        if (current.firebaseEmail == "lyrastudio.smartsolutions@gmail.com" || current.onlineUsername == "admin") {
                            isSuperuser.value = true
                            val updated = current.copy(
                                gold = 999999,
                                levelReached = 15,
                                purchasedSkins = "default,green,blue,rainbow",
                                purchasedScenarios = "kitchen,picnic,garden,sewer,wood,textile,sand,space",
                                sprayCount = 999,
                                freezeCount = 999,
                                tripleSquashCount = 999
                            )
                            if (updated != current) {
                                repository.update(updated)
                                FirebaseManager.syncProfile(updated)
                            } else {
                                FirebaseManager.syncProfile(current)
                            }
                        } else {
                            isSuperuser.value = false
                            FirebaseManager.syncProfile(current)
                        }
                    } else {
                        // Clear online states on guest offline profile activation
                        isSuperuser.value = false
                        firebaseUserEmail.value = null
                        firebaseUsername.value = null
                        friendsMap.value = emptyMap()
                        challengesList.value = emptyList()
                        activeChallengeToPlay.value = null
                    }
                }
            }
        }
    }

    fun playButtonClick() {
        soundManager.playButtonClick()
    }

    // Game loop control
    private var gameJob: Job? = null
    private var lastTickTime: Long = 0

    // Mutable states that drive the layout
    val currentProfileState = repository.currentPlayer.map { p ->
        if (p == null) null
        else if (p.onlineUsername == null || p.firebaseEmail == null) {
            p.copy(
                gold = 0,
                diamonds = 0,
                levelReached = 1,
                totalSquashed = 0,
                highScoreEndless = 0
            )
        } else if (p.firebaseEmail.trim().lowercase() == "thiagu.mangara@gmail.com") {
            p.copy(
                gold = 999999,
                diamonds = 9999,
                levelReached = 15,
                purchasedScenarios = "kitchen,wood,picnic,sand,garden,textile,sewer,space",
                purchasedSkins = "default,green,blue,rainbow",
                sprayCount = 99,
                freezeCount = 99,
                tripleSquashCount = 99
            )
        } else {
            p
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = null
    )

    val currentGameState = MutableStateFlow<GameState>(GameState.Idle)
    val score = MutableStateFlow(0)
    val goldEarned = MutableStateFlow(0)
    val lives = MutableStateFlow(3)
    val damage = MutableStateFlow(0f)
    val timeLeftSec = MutableStateFlow(30)
    
    val activeBugs = MutableStateFlow<List<BugInstance>>(emptyList())
    val activeSplatters = MutableStateFlow<List<SplatterInstance>>(emptyList())
    val activeVFX = MutableStateFlow<List<GameVFX>>(emptyList())
    val frameTick = MutableStateFlow(0)

    // Powerup statuses (durations in ms)
    val freezeDurationLeftMs = MutableStateFlow(0L)
    val shoeDurationLeftMs = MutableStateFlow(0L)
    val poisonDurationLeftMs = MutableStateFlow(0L)
    val isScreenPoisoned = MutableStateFlow(false)

    // Continue flow states
    val showContinueDialog = MutableStateFlow(false)
    val continuesUsed = MutableStateFlow(0)

    // Temporary drops and poison clouds
    val activeDrops = MutableStateFlow<List<TemporaryDrop>>(emptyList())
    val poisonClouds = MutableStateFlow<List<PoisonCloud>>(emptyList())
    val activePoisonGunTimeLeftMs = MutableStateFlow(0L)
    val activePoisonTrailTimeLeftMs = MutableStateFlow(0L)
    private var lastDropSpawnSec = 0L

    // Current setup config
    private var currentLevel: CampaignLevel? = null
    private var isEndlessMode = false
    private var tickCount = 0L
    private var virtualTickAccumulator = 0f
    private var bugIdCounter = 0L
    private var splatterIdCounter = 0L
    private var vfxIdCounter = 0L

    // For screen shake feedback
    val isScreenHurt = MutableStateFlow(false)
    val isScreenShake = MutableStateFlow(false)

    // Stats and Level/XP scoring integration
    val totalTaps = MutableStateFlow(0)
    val successfulHits = MutableStateFlow(0)
    val comboCount = MutableStateFlow(0)
    val maxComboReached = MutableStateFlow(0)
    val lastSquashTimeMs = MutableStateFlow(0L)

    // Audio configurations
    val soundMuted = MutableStateFlow(soundManager.getMuted())

    fun toggleMute() {
        soundMuted.value = soundManager.toggleMute()
    }

    // Initialize/Start a fresh Campaign Level match
    fun startCampaign(level: CampaignLevel) {
        if (firebaseUsername.value == null && level.id > 1) {
            return
        }
        viewModelScope.launch {
            // Cancel any running match
            stopGameLoop()
            
            val profile = repository.getCurrentPlayerDirect() ?: return@launch
            currentLevel = level
            isEndlessMode = false
            currentGameScenario.value = level.scenario

            // Set up initial state
            score.value = 0
            goldEarned.value = 0
            lives.value = 3
            damage.value = 0f
            continuesUsed.value = 0
            showContinueDialog.value = false
            timeLeftSec.value = level.timeLimitSec
            activeBugs.value = emptyList()
            activeSplatters.value = emptyList()
            activeVFX.value = emptyList()
            freezeDurationLeftMs.value = 0
            shoeDurationLeftMs.value = 0
            poisonDurationLeftMs.value = 0L
            isScreenPoisoned.value = false
            activeDrops.value = emptyList()
            poisonClouds.value = emptyList()
            activePoisonGunTimeLeftMs.value = 0L
            activePoisonTrailTimeLeftMs.value = 0L
            lastDropSpawnSec = 0L
            tickCount = 0
            virtualTickAccumulator = 0f
            totalTaps.value = 0
            successfulHits.value = 0
            comboCount.value = 0
            maxComboReached.value = 0
            lastSquashTimeMs.value = 0L
            
            currentGameState.value = GameState.Playing
            
            // Set up scenario background music
            val theme = when (level.scenario) {
                ScenarioType.KITCHEN, ScenarioType.WOOD -> MusicTheme.KITCHEN
                ScenarioType.PICNIC, ScenarioType.TEXTILE -> MusicTheme.PICNIC
                ScenarioType.GARDEN, ScenarioType.SAND -> MusicTheme.GARDEN
                ScenarioType.SEWER, ScenarioType.SPACE -> MusicTheme.SEWER
            }
            soundManager.playMusic(theme)
            
            // Run loop
            startGameLoop()
            
            // Initial spawn pop
            spawnBugsCluster(3)
        }
    }

    // Initialize/Start a fresh Endless Ranked Match
    fun startEndless() {
        if (firebaseUsername.value == null) {
            return
        }
        viewModelScope.launch {
            stopGameLoop()
            
            currentLevel = null
            isEndlessMode = true

            // Set up initial state
            score.value = 0
            goldEarned.value = 0
            lives.value = 5 // Bonus live for endless
            damage.value = 0f
            continuesUsed.value = 0
            showContinueDialog.value = false
            timeLeftSec.value = 9999 // Effectively infinite countdown
            activeBugs.value = emptyList()
            activeSplatters.value = emptyList()
            activeVFX.value = emptyList()
            freezeDurationLeftMs.value = 0
            shoeDurationLeftMs.value = 0
            poisonDurationLeftMs.value = 0L
            isScreenPoisoned.value = false
            activeDrops.value = emptyList()
            poisonClouds.value = emptyList()
            activePoisonGunTimeLeftMs.value = 0L
            activePoisonTrailTimeLeftMs.value = 0L
            lastDropSpawnSec = 0L
            tickCount = 0
            virtualTickAccumulator = 0f
            totalTaps.value = 0
            successfulHits.value = 0
            comboCount.value = 0
            maxComboReached.value = 0
            lastSquashTimeMs.value = 0L

            currentGameState.value = GameState.Playing
            
            // Set up scenario background music based on unlocked/selected scenario
            val scnId = repository.getCurrentPlayerDirect()?.selectedScenario ?: "kitchen"
            val activeScn = ScenarioType.values().find { it.id == scnId } ?: ScenarioType.KITCHEN
            currentGameScenario.value = activeScn

            val theme = when (scnId) {
                "kitchen", "wood" -> MusicTheme.KITCHEN
                "picnic", "textile" -> MusicTheme.PICNIC
                "garden", "sand" -> MusicTheme.GARDEN
                "sewer", "space" -> MusicTheme.SEWER
                else -> MusicTheme.KITCHEN
            }
            soundManager.playMusic(theme)

            startGameLoop()
            
            spawnBugsCluster(4)
        }
    }

    fun retryCurrentMatch() {
        val lvl = currentLevel
        if (isEndlessMode) {
            startEndless()
        } else if (lvl != null) {
            startCampaign(lvl)
        }
    }

    fun pauseGame() {
        playButtonClick()
        if (currentGameState.value is GameState.Playing) {
            currentGameState.value = GameState.Paused
        }
    }

    fun resumeGame() {
        playButtonClick()
        if (currentGameState.value is GameState.Paused) {
            currentGameState.value = GameState.Playing
        }
    }

    fun quitToMenu() {
        stopGameLoop()
        currentGameState.value = GameState.Idle
        soundManager.playMusic(MusicTheme.LOBBY)
    }

    private fun startGameLoop() {
        // Driven smoothly by Compose UI's VSYNC frame clock inside LaunchedEffect!
        // This completely eliminates frame-rate update jitter and mismatching intervals.
    }

    private fun stopGameLoop() {
        // Automatically paused/stopped cleanly via the Compose UI's lifecycle
    }

    // Master Game Tick Execution
    fun gameTick(deltaMs: Long) {
        frameTick.value++
        // Handle powerup freeze cooldown countdown
        if (freezeDurationLeftMs.value > 0) {
            freezeDurationLeftMs.value = maxOf(0L, freezeDurationLeftMs.value - deltaMs)
        }
        // Handle shoe heavy boost cooldown countdown
        if (shoeDurationLeftMs.value > 0) {
            shoeDurationLeftMs.value = maxOf(0L, shoeDurationLeftMs.value - deltaMs)
        }
        // Handle poison duration countdown
        if (poisonDurationLeftMs.value > 0) {
            poisonDurationLeftMs.value = maxOf(0L, poisonDurationLeftMs.value - deltaMs)
        }
        isScreenPoisoned.value = poisonDurationLeftMs.value > 0

        // Handle temporary scenario weapons countdown
        if (activePoisonGunTimeLeftMs.value > 0L) {
            activePoisonGunTimeLeftMs.value = maxOf(0L, activePoisonGunTimeLeftMs.value - deltaMs)
        }
        if (activePoisonTrailTimeLeftMs.value > 0L) {
            activePoisonTrailTimeLeftMs.value = maxOf(0L, activePoisonTrailTimeLeftMs.value - deltaMs)
        }

        // Dissipate/aging of active poison clouds
        val remainingClouds = poisonClouds.value.filter { cloud ->
            (System.currentTimeMillis() - cloud.spawnTimeMs) < cloud.durationMs
        }
        if (remainingClouds.size != poisonClouds.value.size) {
            poisonClouds.value = remainingClouds
        }

        // Filter expired scenario drops and move active hearts downwards
        val now = System.currentTimeMillis()
        val updatedDrops = activeDrops.value.map { drop ->
            if (drop.type == TemporaryDropType.HEART) {
                // Heart drop falls down slowly! (approx 0.11f units of screen height per second)
                val fallDistance = 0.11f * (deltaMs / 1000f)
                drop.copy(y = drop.y + fallDistance)
            } else {
                drop
            }
        }.filter { drop ->
            (now - drop.spawnTimeMs) < drop.durationMs && drop.y <= 1.1f
        }
        if (updatedDrops != activeDrops.value) {
            activeDrops.value = updatedDrops
        }

        val isFrozen = freezeDurationLeftMs.value > 0

        // Convert actual elapsed time to 60 FPS tick equivalents to preserve original spawning and level parameters
        val virtualTicksElapsed = deltaMs / 16.67f
        virtualTickAccumulator += virtualTicksElapsed
        
        val wholeTicksToProcess = virtualTickAccumulator.toInt()
        if (wholeTicksToProcess > 0) {
            virtualTickAccumulator -= wholeTicksToProcess
            for (step in 1..wholeTicksToProcess) {
                tickCount++
                
                // 1. Time countdown execution (60 virtual ticks = 1 actual second)
                if (tickCount % 60 == 0L) {
                    if (!isEndlessMode) {
                        timeLeftSec.value = maxOf(0, timeLeftSec.value - 1)
                        if (timeLeftSec.value <= 0) {
                            evaluateMatchEnd()
                        }
                    } else {
                        // In endless, score increases by +1 per second of survival!
                        score.value += 1
                    }

                    if (poisonDurationLeftMs.value > 0L) {
                        score.value = maxOf(0, score.value - 15)
                        spawnFloatingVFX(0.5f, 0.45f, "-15 PTS: ENVENENADO! ☣️", 0xFF4CAF50)
                    }
                }

                // 2. Spawn simulation logic
                val spawnSpeedFactor = if (isEndlessMode) {
                    1 + (tickCount / 1200) // Increase density every 20 seconds
                } else {
                    // Increase spawn frequency/density for later campaign levels
                    val levelId = currentLevel?.id ?: 1
                    1 + (levelId / 4) // level 1-3 = 1x, level 4-7 = 2x, level 8 = 3x
                }

                val spawnInterval = if (isEndlessMode) {
                    maxOf(50, 160 - (tickCount / 200).toInt()) // Much faster spawns over time in endless
                } else {
                    // Campaign matches: progressively tighter intervals as catalog level increases
                    val levelId = currentLevel?.id ?: 1
                    maxOf(60, 150 - levelId * 11) // Level 1 = 139 ticks, Level 8 = 62 ticks (fast enxames!)
                }

                if (tickCount % spawnInterval == 0L) {
                    // Extra random spawn burst chance (+40% chance for extra crawler)
                    val burstExtra = if (Random.nextFloat() > 0.60f) 1 else 0
                    val amountToSpawn = Random.nextInt(1, 2 * spawnSpeedFactor.toInt() + 1) + burstExtra
                    spawnBugsCluster(amountToSpawn)
                }

                // Spawn a temporary scenario collectible drop (approx every 10 seconds, where 1 sec = 60 virtual ticks)
                if (currentGameState.value == GameState.Playing && tickCount > 0 && tickCount % 550 == 0L) {
                    val roll = Random.nextFloat()
                    val dropType = if (roll < 0.15f) {
                        // 15% chance to spawn a heart (rare)
                        TemporaryDropType.HEART
                    } else if (roll < 0.58f) {
                        TemporaryDropType.POISON_GUN
                    } else {
                        TemporaryDropType.GREEN_POISON
                    }
                    val rx = 0.12f + Random.nextFloat() * 0.76f
                    // If it is a heart, start at the top of the screen (y = -0.05f) to fall caindo girando, else spawn in-place
                    val ry = if (dropType == TemporaryDropType.HEART) -0.05f else (0.18f + Random.nextFloat() * 0.60f)
                    val newDrop = TemporaryDrop(
                        id = System.currentTimeMillis() + Random.nextInt(1000),
                        x = rx,
                        y = ry,
                        type = dropType,
                        spawnTimeMs = System.currentTimeMillis(),
                        durationMs = if (dropType == TemporaryDropType.HEART) 15000L else 10000L
                    )
                    activeDrops.value = activeDrops.value + newDrop
                    
                    // Display floating drop popup notice
                    if (dropType == TemporaryDropType.HEART) {
                        spawnFloatingVFX(rx, 0.15f, "VIDA EXTRA CAINDO! ❤️", 0xFFFF4444)
                    } else {
                        spawnFloatingVFX(rx, ry - 0.05f, "ITEM SURGIU! 🎁", dropType.color)
                    }
                }
            }
        }

        // 3. Spatially move bugs
        val currentBugs = activeBugs.value
        val bugsToKeep = mutableListOf<BugInstance>()
        
        val timeScale = if (isFrozen) 0.3f else 1.0f // Freeze slows bugs by 70%

        // Scenario-based speed scaling
        val scenarioMultiplier = when (currentLevel?.scenario) {
            ScenarioType.KITCHEN -> 1.0f
            ScenarioType.WOOD -> 1.12f
            ScenarioType.PICNIC -> 1.22f
            ScenarioType.SAND -> 1.34f
            ScenarioType.GARDEN -> 1.45f
            ScenarioType.TEXTILE -> 1.56f
            ScenarioType.SEWER -> 1.70f
            ScenarioType.SPACE -> 1.90f
            else -> if (isEndlessMode) 1.0f + (tickCount.toFloat() / 2400f).coerceAtMost(0.8f) else 1.0f
        }

        // Express movement delta time as virtual tick step for exact physical speed retention across any refresh rate
        val dt = deltaMs / 16.67f

        for (bug in currentBugs) {
            if (bug.isSmashed) {
                continue
            }

            // Increment the sinusoidal path timer by actual elapsed milliseconds to prevent stutter
            val newDirectionTimer = bug.directionChangeTimer + deltaMs

            // Consistent, ultra-smooth speed factor per bug ID with high variability
            // Introduce a randomized speed oscillation per ID to make movement highly organic
            val speedOscillation = 1.0f + kotlin.math.sin((newDirectionTimer * 0.002f) + bug.id) * 0.18f
            val idSpeedVar = (0.80f + (bug.id % 5) * 0.12f) * speedOscillation // higher range: 0.8f to 1.28f * wave
            val baseSpeedVal = bug.type.baseSpeed * 0.0155f // slightly increased default base speed!
            val actualSpeed = baseSpeedVal * idSpeedVar * timeScale * scenarioMultiplier

            var newX = bug.x
            var newY = bug.y
            var newPathParam = bug.pathParam

            when (bug.type) {
                BugType.ANT -> {
                    // Ants: occasionally run in panic bursts with high zig-zag wiggles
                    val isPanicked = (getStableRandom(bug.id, (newDirectionTimer / 1000).toInt()) > 0.62f)
                    val antSpeed = if (isPanicked) actualSpeed * 1.85f else actualSpeed
                    val t = (newDirectionTimer + bug.id * 800) * (if (isPanicked) 0.028f else 0.011f)
                    val dx = kotlin.math.sin(t) * (if (isPanicked) 0.0035f else 0.0007f) * dt
                    val dy = antSpeed * dt
                    newX += dx
                    newY += dy
                }
                BugType.TERMITE -> {
                    // Termites: diagonal swift sweeps that bounce sharply off boundaries and do sudden dash sprints
                    val speedBurst = 1.0f + kotlin.math.sin((newDirectionTimer * 0.012f) + bug.id).coerceAtLeast(0f) * 1.1f
                    val t = (newDirectionTimer + bug.id * 600) * 0.025f
                    val dx = (newPathParam + kotlin.math.sin(t) * 0.45f) * actualSpeed * speedBurst * dt
                    val dy = actualSpeed * speedBurst * dt
                    newX += dx
                    newY += dy
                }
                BugType.COCKROACH -> {
                    // Cockroaches: The master of chaotic stops and sprints!
                    // Freezes completely on random interval to look around, then rushes off in a sudden blitz direction
                    val cycleTime = (newDirectionTimer + bug.id * 153) % 2000
                    val isFreezing = cycleTime < 280
                    val isSprinting = cycleTime in 280..800
                    val roachSpeed = when {
                        isFreezing -> 0f
                        isSprinting -> actualSpeed * 2.6f
                        else -> actualSpeed * 1.3f
                    }
                    val t = (newDirectionTimer + bug.id * 2000) * 0.032f
                    val erraticSteer = kotlin.math.sin(t.toDouble()).toFloat() * 1.6f + kotlin.math.cos((t * 2.33f).toDouble()).toFloat() * 1.0f
                    val dx = (newPathParam * 0.7f + erraticSteer) * roachSpeed * dt
                    val dy = roachSpeed * 0.95f * dt
                    newX += dx
                    newY += dy
                }
                BugType.SPIDER -> {
                    // Spiders: High yoyo oscillation bounce!
                    // They descend, retract up, sway strongly, then drop very fast
                    val yoyoCycle = kotlin.math.sin((newDirectionTimer * 0.0032f) + bug.id)
                    val verticalRatio = if (yoyoCycle < -0.35f) -0.45f else 1.35f
                    val t = (newDirectionTimer + bug.id * 1800) * 0.014f
                    val dx = kotlin.math.sin(t) * 0.0075f * dt
                    val dy = actualSpeed * verticalRatio * dt
                    newX += dx
                    newY += dy
                }
                BugType.BEETLE -> {
                    // Beetles: Slow heavy tank, but sways heavily, and rushes like a mad bull if they've been hurt!
                    val isHurt = bug.hp < BugType.BEETLE.baseHp
                    val speedScale = if (isHurt) 2.4f else 0.9f
                    // Add random heavy swerving
                    val t = (newDirectionTimer + bug.id * 2500) * 0.012f
                    val swerve = kotlin.math.sin(t) * (if (isHurt) 0.004f else 0.0006f) * dt
                    newX += swerve
                    newY += actualSpeed * speedScale * dt
                }
                BugType.WASP -> {
                    // Wasps: Fly in circular looping flight sweeps and unpredictable cross-winds
                    val t = (newDirectionTimer + bug.id * 3500) * 0.011f
                    val windSteer = kotlin.math.sin(t) * (1.6f + kotlin.math.sin(t * 2.1f) * 1.2f)
                    val dx = windSteer * actualSpeed * dt
                    // Sometimes dive or soar back up
                    val diveFactor = 0.8f + kotlin.math.cos(t * 2.4f) * 0.75f
                    val dy = actualSpeed * diveFactor * dt
                    newX += dx
                    newY += dy
                }
                BugType.SCORPION -> {
                    // Scorpion: custom slow crawling, then a rapid tail wiggle and forward lunge
                    val cycleTime = (newDirectionTimer + bug.id * 333L) % 2500L
                    val isLunging = cycleTime > 1800L
                    val scorpSpeed = if (isLunging) actualSpeed * 2.5f else actualSpeed * 0.7f
                    val t = (newDirectionTimer + bug.id * 1000L).toFloat() * 0.022f
                    val dx = kotlin.math.sin(t) * (if (isLunging) 0.009f else 0.002f) * dt
                    val dy = scorpSpeed * dt
                    newX += dx
                    newY += dy
                }
                BugType.CENTIPEDE -> {
                    // Centipede: rapid high frequency horizontal zig-zag serpentine wiggle, moving fast downwards
                    val t = (newDirectionTimer + bug.id * 500L).toFloat() * 0.038f // extremely wiggly!
                    val dx = kotlin.math.sin(t) * 0.016f * dt
                    val dy = actualSpeed * 1.15f * dt
                    newX += dx
                    newY += dy
                }
            }

            // Lock boundaries for horizontal to prevent bugs going out of screen boundaries
            if (newX < 0.02f) {
                newX = 0.02f
                newPathParam = -newPathParam // Bounce
            }
            if (newX > 0.98f) {
                newX = 0.98f
                newPathParam = -newPathParam // Bounce
            }

            // Dynamic angle interpolation matching actual movement vector
            val dXActual = newX - bug.x
            val dYActual = newY - bug.y
            var newAngle = bug.angle
            if (dXActual != 0f || dYActual != 0f) {
                val angleRad = kotlin.math.atan2(dXActual.toDouble(), dYActual.toDouble())
                val targetAngle = 180f - Math.toDegrees(angleRad).toFloat()
                
                // Keep interpolation smooth and wrap-safe
                var diff = targetAngle - bug.angle
                if (diff.isFinite()) {
                    diff = ((diff + 180f) % 360f)
                    if (diff < 0f) diff += 360f
                    diff -= 180f
                } else {
                    diff = 0f
                }
                newAngle = bug.angle + diff * (0.08f * dt).coerceAtMost(1.0f) // Frame-rate independent turning scaled by real time delta
            }

            // 3.1. Poison cloud infection check
            var bugInfected = bug.isInfected
            var infectTimer = bug.infectionTimerMs

            if (!bugInfected && !bug.type.avoidance && poisonClouds.value.isNotEmpty()) {
                val inCloud = poisonClouds.value.any { cloud ->
                    val dx = cloud.x - bug.x
                    val dy = cloud.y - bug.y
                    kotlin.math.sqrt(dx * dx + dy * dy) < cloud.radius
                }
                if (inCloud) {
                    bugInfected = true
                    infectTimer = 1800L // ~2 seconds life expectancy
                    spawnFloatingVFX(bug.x, bug.y, "INFECTADO! ☣️", 0xFF4CAF50)
                }
            }

            if (bugInfected) {
                infectTimer = maxOf(0L, infectTimer - deltaMs)
                if (infectTimer <= 0L) {
                    // Died from chemical infection!
                    val cashGained = bug.type.goldValue
                    goldEarned.value += cashGained
                    score.value += bug.type.points

                    val p = currentProfileState.value
                    val splatSkin = p?.selectedSkin ?: "default"
                    addSplatter(bug.x, bug.y, splatSkin, bug.type)

                    soundManager.playSquishSound(isHeavy = bug.type == BugType.BEETLE || bug.type == BugType.CENTIPEDE)
                    
                    spawnFloatingVFX(bug.x, bug.y, "+${bug.type.points} PTS ☣️", 0xFF4CAF50)
                    if (cashGained > 0) {
                        spawnFloatingVFX(bug.x + 0.03f, bug.y - 0.02f, "+$cashGained 🪙", 0xFFFFD700)
                    }

                    currentLevel?.let { lvl ->
                        if (score.value >= lvl.targetScore) {
                            evaluateMatchEnd()
                        }
                    }
                    continue // Skip adding to bugsToKeep so it dies
                }
            }

            // Check escape boundary (off bottom edge)
            if (newY > 1.05f) {
                // Escaped! Adds damage if it's NOT a WASP
                if (bug.type != BugType.WASP) {
                    applyDamage(25f, newX, 0.9f, "DANO! +25%", 0xFFFF4444)
                }
            } else {
                bugsToKeep.add(
                    bug.copy(
                        x = newX,
                        y = newY,
                        angle = newAngle,
                        directionChangeTimer = newDirectionTimer,
                        pathParam = newPathParam,
                        isInfected = bugInfected,
                        infectionTimerMs = infectTimer
                    )
                )
            }
        }
        activeBugs.value = bugsToKeep

        // 4. Update visual flotation VFX (Floating scores)
        val currentVFX = activeVFX.value.toMutableList()
        val vfxToKeep = mutableListOf<GameVFX>()
        val currentTime = System.currentTimeMillis()
        for (vfx in currentVFX) {
            if (currentTime - vfx.creationTime < 1300) {
                vfx.yOffset -= 0.005f // floating up
                vfx.alpha = 1f - ((currentTime - vfx.creationTime).toFloat() / 1300f) // fading out
                vfxToKeep.add(vfx)
            }
        }
        activeVFX.value = vfxToKeep

        // Keep splatters tidy if too many (max 40)
        if (activeSplatters.value.size > 40) {
            activeSplatters.value = activeSplatters.value.drop(activeSplatters.value.size - 40)
        }
    }

    private fun triggerScreenHurt() {
        viewModelScope.launch {
            isScreenHurt.value = true
            isScreenShake.value = true
            soundManager.playDamage()
            delay(150)
            isScreenHurt.value = false
            delay(150)
            isScreenShake.value = false
        }
    }

    fun applyDamage(amount: Float, sourceX: Float, sourceY: Float, message: String, color: Long) {
        val newDamage = damage.value + amount
        if (newDamage >= 100f) {
            triggerScreenHurt()
            if (lives.value > 0) {
                lives.value = maxOf(1, lives.value) - 1
                damage.value = 0f
                soundManager.playLevelWin()
                spawnFloatingVFX(0.5f, 0.5f, "SALVO POR UMA VIDA! ❤️", 0xFFFF4444)
            } else {
                damage.value = 100f
                spawnFloatingVFX(sourceX, sourceY, message, color)
                evaluateMatchEnd()
            }
        } else {
            damage.value = newDamage
            triggerScreenHurt()
            spawnFloatingVFX(sourceX, sourceY, message, color)
        }
    }

    // Helper wiggle parameter for wasps (returns left or right direction)
    private fun BugInstance.wiggleTime(): Float {
        // Simple helper to know if flying left or right
        return if (this.angle > 180f) 1.0f else -1.0f
    }

    // Spawn a wave of bugs at the top edge of screen
    private fun spawnBugsCluster(count: Int) {
        val currentList = activeBugs.value.toMutableList()
        val profile = currentProfileState.value
        val allowed = currentLevel?.allowedSpecies ?: listOf(BugType.ANT, BugType.COCKROACH, BugType.TERMITE, BugType.SPIDER, BugType.BEETLE, BugType.WASP, BugType.SCORPION, BugType.CENTIPEDE)

        for (i in 0 until count) {
            val type = allowed[Random.nextInt(allowed.size)]
            val spawnX = Random.nextFloat() * 0.90f + 0.05f
            val spawnY = -0.05f - (Random.nextFloat() * 0.15f) // Stagger spawn slightly above top
            
            // Cockroaches, termites can have random initial angular slopes
            val randomSlope = Random.nextFloat() * 2f - 1f
            val angleDeg = if (randomSlope > 0) 210f else 150f

            val bug = BugInstance(
                id = ++bugIdCounter,
                type = type,
                x = spawnX,
                y = spawnY,
                hp = type.baseHp,
                angle = angleDeg,
                pathParam = randomSlope
            )
            currentList.add(bug)
        }
        activeBugs.value = currentList
    }

    fun advanceToNextCampaignLevelOrMenu() {
        val lvl = currentLevel
        if (lvl != null && lvl.id < 8) {
            val nextLvl = com.example.game.LevelCatalog.levels.find { it.id == lvl.id + 1 }
            if (nextLvl != null) {
                playButtonClick()
                startCampaign(nextLvl)
                return
            }
        }
        playButtonClick()
        quitToMenu()
    }

    fun squashBugDirectly(bugId: Long) {
        val bugs = activeBugs.value.toMutableList()
        val index = bugs.indexOfFirst { it.id == bugId }
        if (index != -1) {
            val bug = bugs[index]
            if (!bug.isSmashed) {
                bugs[index] = bug.copy(isSmashed = true)
                val goldMultiplier = 1
                val cashGained = bug.type.goldValue * goldMultiplier
                goldEarned.value += cashGained
                score.value += bug.type.points

                val p = currentProfileState.value
                val splatSkin = p?.selectedSkin ?: "default"
                addSplatter(bug.x, bug.y, splatSkin, bug.type)

                soundManager.playSquishSound(isHeavy = bug.type == BugType.BEETLE || bug.type == BugType.CENTIPEDE)
                val feedbackText = "+${bug.type.points} PTS"
                val popColor = when (bug.type) {
                    BugType.BEETLE -> 0xFFFFD700
                    BugType.SPIDER -> 0xFFD8BFD8
                    BugType.CENTIPEDE -> 0xFF39FF14
                    else -> 0xFF81C784
                }
                spawnFloatingVFX(bug.x, bug.y, feedbackText, popColor)
                if (cashGained > 0) {
                    spawnFloatingVFX(bug.x + 0.03f, bug.y - 0.02f, "+$cashGained 🪙", 0xFFFFD700)
                }

                currentLevel?.let { lvl ->
                    if (score.value >= lvl.targetScore) {
                        evaluateMatchEnd()
                    }
                }
            }
        }
        activeBugs.value = bugs
    }

    fun handlePointerInput(relX: Float, relY: Float, isDragging: Boolean) {
        if (currentGameState.value !is GameState.Playing) return

        // 1. Hit-test for temporary collectible scenario drops first
        val drops = activeDrops.value.toMutableList()
        val hitDropIndex = drops.indexOfFirst { drop ->
            val dx = drop.x - relX
            val dy = drop.y - relY
            kotlin.math.sqrt(dx * dx + dy * dy) < 0.08f
        }
        if (hitDropIndex != -1) {
            val drop = drops.removeAt(hitDropIndex)
            activeDrops.value = drops
            
            // Collect/Activate temporary item!
            if (drop.type == TemporaryDropType.POISON_GUN) {
                soundManager.playItemCollect()
                activePoisonGunTimeLeftMs.value = 10000L // 10 seconds of poison spray gun
                activePoisonTrailTimeLeftMs.value = 0L
                spawnFloatingVFX(drop.x, drop.y, "PISTOLA DE VENENO! 🔫", 0xFF00E5FF)
            } else if (drop.type == TemporaryDropType.GREEN_POISON) {
                soundManager.playItemCollect()
                activePoisonTrailTimeLeftMs.value = 10000L // 10 seconds of chemical trail painting
                activePoisonGunTimeLeftMs.value = 0L
                spawnFloatingVFX(drop.x, drop.y, "☣️ VENENO QUÍMICO! ☣️", 0xFF4CAF50)
            } else if (drop.type == TemporaryDropType.HEART) {
                soundManager.playLifeCollect()
                lives.value = lives.value + 1
                spawnFloatingVFX(drop.x, drop.y, "+1 VIDA! ❤️", 0xFFFF4444)
            }
            return
        }

        // 2. Process active temporary powers or standard taps
        if (activePoisonGunTimeLeftMs.value > 0L) {
            // Poison gun: continuously squeezes bugs within a small circle
            soundManager.playPistolUse()
            val bugs = activeBugs.value
            for (bug in bugs) {
                if (bug.isSmashed) continue
                if (bug.type.avoidance) continue // Prevent trivialized wasp/scorpion hitting
                
                val dx = bug.x - relX
                val dy = bug.y - relY
                val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                if (dist < 0.08f) {
                    squashBugDirectly(bug.id)
                }
            }
            // Spark continuous chemical green/blue splash pops
            if (Random.nextFloat() > 0.65f) {
                spawnFloatingVFX(relX, relY, "💥", 0xFF00E5FF)
            }
        } else if (activePoisonTrailTimeLeftMs.value > 0L) {
            // Dragging paint trail: add a new poison cloud at pointer if not overly dense
            val clouds = poisonClouds.value.toMutableList()
            val closeToAny = clouds.any { c ->
                val dx = c.x - relX
                val dy = c.y - relY
                kotlin.math.sqrt(dx * dx + dy * dy) < 0.05f
            }
            if (!closeToAny) {
                soundManager.playPoisonUse()
                val newCloud = PoisonCloud(
                    id = System.currentTimeMillis() + Random.nextInt(100),
                    x = relX,
                    y = relY,
                    spawnTimeMs = System.currentTimeMillis()
                )
                poisonClouds.value = clouds + newCloud
            }
        } else {
            // No custom item active and no drop hit -> classic single tap
            if (!isDragging) {
                registerTap(relX, relY)
            }
        }
    }

    // Tap-to-squish Action Hit-Test (Tap coordinates in relative 0f..1f range)
    fun registerTap(relX: Float, relY: Float) {
        if (currentGameState.value !is GameState.Playing) return

        totalTaps.value++

        val bugs = activeBugs.value.toMutableList()
        var hitAny = false

        // Custom shoes/double tap radius
        val isShoeActive = shoeDurationLeftMs.value > 0
        val damageDeal = if (isShoeActive) 3 else 1
        // Define hitbox distance depending on whether a heavy shoe expansion is active
        // Decreased normal trigger radius from 0.075f to 0.045f so that normal taps require precision, and shoe mode expands it.
        val hitRadius = if (isShoeActive) 0.12f else 0.045f

        // Search from newest to oldest (top layer first!)
        for (i in bugs.indices.reversed()) {
            val bug = bugs[i]
            if (bug.isSmashed) continue

            // Determine relative distance
            val dx = bug.x - relX
            val dy = bug.y - relY
            val dist = kotlin.math.sqrt(dx * dx + dy * dy)

            if (dist < hitRadius) {
                hitAny = true
                successfulHits.value++
                         if (bug.type.avoidance) {
                    // Oops! Tapped wasp or scorpion! Obstacle penalty
                    comboCount.value = 0
                    score.value = maxOf(0, score.value + bug.type.points)
                    val dmgAmount = if (bug.type == BugType.SCORPION) 30f else 25f
                    val msg = if (bug.type == BugType.SCORPION) {
                        poisonDurationLeftMs.value = 4000L // 4 seconds of poison drain!
                        "VENENO! +30% DANO 🦂☠️"
                    } else {
                        "VESPA! +25% DANO 🐝☠️"
                    }
                    val colHex = if (bug.type == BugType.SCORPION) 0xFF4CAF50 else 0xFFFF1111
                    applyDamage(dmgAmount, bug.x, bug.y, msg, colHex)
                    bugs[i] = bug.copy(isSmashed = true) // Remove from active screen
                } else {
                    // Normal bug hit!
                    val newHp = bug.hp - damageDeal
                    
                    if (newHp <= 0) {
                        // Smashed!
                        bugs[i] = bug.copy(hp = newHp, isSmashed = true)
                        
                        // Combo system calculations
                        val now = System.currentTimeMillis()
                        val lastSquash = lastSquashTimeMs.value
                        val comboWindowMs = 1500L
                        var currentCombo = comboCount.value
                        if (now - lastSquash <= comboWindowMs) {
                            currentCombo++
                        } else {
                            currentCombo = 1
                        }
                        comboCount.value = currentCombo
                        maxComboReached.value = maxOf(maxComboReached.value, currentCombo)
                        lastSquashTimeMs.value = now

                        val comboBonusScore = (currentCombo - 1) * 3
                        val scoreToAdd = bug.type.points + comboBonusScore

                        val goldMultiplier = 1
                        val comboGoldBonus = if (currentCombo >= 5) 2 else if (currentCombo >= 3) 1 else 0
                        val cashGained = bug.type.goldValue * goldMultiplier + comboGoldBonus
                        goldEarned.value += cashGained
                        score.value += scoreToAdd
 
                        // Launch visual splat on exact coordinates
                        val p = currentProfileState.value
                        val splatSkin = p?.selectedSkin ?: "default"
                        addSplatter(bug.x, bug.y, splatSkin, bug.type)
 
                        soundManager.playSquishSound(isHeavy = bug.type == BugType.BEETLE || bug.type == BugType.CENTIPEDE)
                        
                        // Floating score popup! Show "COMBO" if fast tap
                        val feedbackText = if (currentCombo > 1) {
                            "+$scoreToAdd PTS (COMBO x$currentCombo! 🔥)"
                        } else {
                            "+$scoreToAdd PTS"
                        }
                        val popColor = when (bug.type) {
                            BugType.BEETLE -> 0xFFFFD700 // Gold
                            BugType.SPIDER -> 0xFFD8BFD8 // Light magenta
                            BugType.CENTIPEDE -> 0xFF39FF14 // Neon green
                            else -> if (currentCombo > 3) 0xFFFF9800 else 0xFF81C784 // Orange / Green
                        }
                        spawnFloatingVFX(bug.x, bug.y, feedbackText, popColor)

                        // If gold was earned, show a tiny gold popup too!
                        if (cashGained > 0) {
                            spawnFloatingVFX(bug.x + 0.03f, bug.y - 0.02f, "+$cashGained 🪙", 0xFFFFD700)
                        }

                        // Check campaign goal reached instantly
                        currentLevel?.let { lvl ->
                            if (score.value >= lvl.targetScore) {
                                evaluateMatchEnd()
                            }
                        }
                    } else {
                        // Beetle cracking feedback!
                        bugs[i] = bug.copy(hp = newHp)
                        soundManager.playSquishSound(isHeavy = true)
                        spawnFloatingVFX(bug.x, bug.y, "RACHOU! 💢", 0xFFE0E0E0)
                        // Trigger screen shake for power feels
                        triggerMinorScreenShake()
                    }
                }
                break // Only hit ONE bug per finger touch (prevents cheap multi-killing from one tap unless powerup is used)
            }
        }

        if (!hitAny) {
            comboCount.value = 0
        }

        activeBugs.value = bugs
    }

    private fun triggerMinorScreenShake() {
        viewModelScope.launch {
            isScreenShake.value = true
            delay(80)
            isScreenShake.value = false
        }
    }

    private fun addSplatter(x: Float, y: Float, skinId: String, bugType: BugType) {
        val list = activeSplatters.value.toMutableList()
        val splat = SplatterInstance(
            id = ++splatterIdCounter,
            x = x,
            y = y,
            skinId = skinId,
            bugType = bugType,
            sizeDp = bugType.sizeDp + 15, // splatters a bit larger than actual bug
            timestamp = System.currentTimeMillis()
        )
        list.add(splat)
        activeSplatters.value = list
    }

    private fun spawnFloatingVFX(x: Float, y: Float, text: String, colorHex: Long) {
        val list = activeVFX.value.toMutableList()
        val vfx = GameVFX(
            id = ++vfxIdCounter,
            x = x,
            y = y,
            text = text,
            color = colorHex,
            creationTime = System.currentTimeMillis()
        )
        list.add(vfx)
        activeVFX.value = list
    }

    // Trigger powerful spray powerup clear! Clears all insects currently on screen.
    fun useSprayPowerup() {
        val profile = currentProfileState.value ?: return
        if (profile.sprayCount <= 0 || currentGameState.value !is GameState.Playing) return

        viewModelScope.launch {
            // Deduct from profile
            repository.update(profile.copy(sprayCount = profile.sprayCount - 1))
            
            // Blast feedback
            soundManager.playExplodeInsects()
            triggerMinorScreenShake()
            
            val bugs = activeBugs.value
            var totalPoints = 0
            var gatheredGold = 0
            val updatedBugs = bugs.map { bug ->
                if (!bug.isSmashed && !bug.type.avoidance) {
                    totalPoints += bug.type.points
                    gatheredGold += bug.type.goldValue
                    addSplatter(bug.x, bug.y, profile.selectedSkin, bug.type)
                    bug.copy(isSmashed = true)
                } else {
                    bug
                }
            }

            score.value += totalPoints
            goldEarned.value += gatheredGold
            activeBugs.value = updatedBugs.filter { !it.isSmashed }

            spawnFloatingVFX(0.5f, 0.4f, "DEDETIZAÇÃO COMPLETA! +$totalPoints PTS 💨💥", 0xFF4FC3F7)
            
            // Check campaign goals
            currentLevel?.let { lvl ->
                if (score.value >= lvl.targetScore) {
                    evaluateMatchEnd()
                }
            }
        }
    }

    // Trigger ICE Freeze clock powerup: slows time down significantly!
    fun useFreezePowerup() {
        val profile = currentProfileState.value ?: return
        if (profile.freezeCount <= 0 || currentGameState.value !is GameState.Playing) return

        viewModelScope.launch {
            repository.update(profile.copy(freezeCount = profile.freezeCount - 1))
            freezeDurationLeftMs.value = 6000L // 6 seconds freeze
            soundManager.playPowerupSplat()
            spawnFloatingVFX(0.5f, 0.3f, "CONGELADO! ❄️🕒", 0xFFE0F7FA)
        }
    }

    // Trigger Heavy shoe stomp increase width
    fun useShoePowerup() {
        val profile = currentProfileState.value ?: return
        if (profile.tripleSquashCount <= 0 || currentGameState.value !is GameState.Playing) return

        viewModelScope.launch {
            repository.update(profile.copy(tripleSquashCount = profile.tripleSquashCount - 1))
            shoeDurationLeftMs.value = 8000L // 8 seconds heavy hits
            soundManager.playPowerupSplat()
            spawnFloatingVFX(0.5f, 0.5f, "SUPER SAPATO ATIVADO! 🥾💥", 0xFFFFE082)
        }
    }

    // End-of-game Match calculations and Room database updates
    private fun evaluateMatchEnd() {
        stopGameLoop()
        val currentScore = score.value
        val goldEarnedTotal = goldEarned.value

        viewModelScope.launch {
            val profile = repository.getCurrentPlayerDirect() ?: return@launch
            
            // If campaign and they won, they get victory!
            val lvl = currentLevel
            val isCampaign = !isEndlessMode && lvl != null
            val won = isCampaign && currentScore >= (lvl?.targetScore ?: 0)
            
            if (isCampaign && won) {
                // Handle normal Campaign Victory directly (no continue prompt needed for absolute victory!)
                soundManager.playLevelWin()
                soundManager.playMusic(MusicTheme.LOBBY)
                
                val isGuest = profile.onlineUsername == null
                val nextLevelUnlocked = !isGuest && (profile.levelReached == lvl!!.id && lvl!!.id < LevelCatalog.levels.size)
                val updatedReached = if (nextLevelUnlocked) lvl!!.id + 1 else profile.levelReached
                val totalWinnerGold = if (isGuest) 0 else (goldEarnedTotal + lvl!!.goldReward)

                if (!isGuest) {
                    val updatedProf = profile.copy(
                        totalSquashed = profile.totalSquashed + currentScore / 15,
                        gold = profile.gold + totalWinnerGold,
                        levelReached = updatedReached
                    )
                    repository.update(updatedProf)
                    if (profile.onlineUsername != null) {
                        FirebaseManager.syncProfile(updatedProf)
                    }
                }
                currentGameState.value = GameState.Victory(currentScore, totalWinnerGold, nextLevelUnlocked)
                
                // Progress other simulated player highscores as well to compete!
                repository.simulateLiveCompetitionProgress()
            } else {
                // If it's a loss (either ran out of lives, or failed target score in campaign)
                val isGuest = profile.onlineUsername == null
                if (isGuest) {
                    showContinueDialog.value = false
                    soundManager.playMusic(MusicTheme.LOBBY)
                    currentGameState.value = GameState.GameOver(currentScore, 0)
                } else {
                    // Intercept with the custom Continue Dialog flow!
                    showContinueDialog.value = true
                }
            }
        }
    }

    fun declineContinue() {
        viewModelScope.launch {
            val profile = repository.getCurrentPlayerDirect() ?: return@launch
            
            // "se o usuário não quiser continuar, deve perder todo progresso, bloqueando novamente as fases desbloqueadas."
            val updatedProf = profile.copy(levelReached = 1)
            repository.update(updatedProf)
            if (profile.onlineUsername != null) {
                FirebaseManager.syncProfile(updatedProf)
            }
            
            showContinueDialog.value = false
            executeNormalGameOver(updatedProf, score.value, goldEarned.value)
        }
    }

    fun acceptContinue() {
        viewModelScope.launch {
            val profile = repository.getCurrentPlayerDirect() ?: return@launch
            val count = continuesUsed.value
            if (count < 3) {
                // Free continue!
                continuesUsed.value = count + 1
                performContinueResume()
            } else {
                // Premium continue: costs 1 diamond 💎
                if (profile.diamonds >= 1) {
                    val updatedProf = profile.copy(diamonds = profile.diamonds - 1)
                    repository.update(updatedProf)
                    if (profile.onlineUsername != null) {
                        FirebaseManager.syncProfile(updatedProf)
                    }
                    continuesUsed.value = count + 1
                    performContinueResume()
                } else {
                    // Cannot afford diamond continue
                    soundManager.playObstacleHit()
                }
            }
        }
    }

    private fun performContinueResume() {
        // Restore lives based on mode
        lives.value = if (isEndlessMode) 5 else 3
        damage.value = 0f
        
        // Restore timer if campaign
        if (!isEndlessMode) {
            timeLeftSec.value = maxOf(30, currentLevel?.timeLimitSec ?: 30)
        }
        
        // Clear obstacles/enemies to grant breathing room after continuing
        activeBugs.value = emptyList()
        poisonClouds.value = emptyList()
        activeDrops.value = emptyList()
        
        showContinueDialog.value = false
        currentGameState.value = GameState.Playing
        
        // Play confirming capture sound or custom life collect sound
        soundManager.playLifeCollect()
        
        // Resume game ticker loop
        startGameLoop()
    }

    private fun executeNormalGameOver(profile: PlayerProfile, currentScore: Int, goldEarnedTotal: Int) {
        viewModelScope.launch {
            val challenge = activeChallengeToPlay.value
            if (isEndlessMode && challenge != null) {
                val isNewHighscore = currentScore > profile.highScoreEndless
                val updatedProf = profile.copy(
                    totalSquashed = profile.totalSquashed + (currentScore / 10).toInt(),
                    highScoreEndless = if (isNewHighscore) currentScore else profile.highScoreEndless,
                    gold = profile.gold + goldEarnedTotal
                )
                repository.update(updatedProf)
                FirebaseManager.syncProfile(updatedProf)

                soundManager.playGameOver()
                soundManager.playMusic(MusicTheme.LOBBY)
                currentGameState.value = GameState.GameOver(currentScore, goldEarnedTotal)

                // Submit score to Firebase Realtime Database
                val isChallenger = (profile.onlineUsername == challenge.challenger)
                isLoadingOnline.value = true
                FirebaseManager.submitChallengeScore(challenge.id, isChallenger, currentScore, { updatedJson ->
                    isLoadingOnline.value = false
                    activeChallengeToPlay.value = null
                    refreshChallenges()
                    
                    val status = updatedJson.optString("status", "")
                    val winner = updatedJson.optString("winner", "")
                    if (status == "completed") {
                        viewModelScope.launch {
                            val activeP = repository.getCurrentPlayerDirect() ?: return@launch
                            var finalGold = activeP.gold
                            if (winner == activeP.onlineUsername) {
                                finalGold += challenge.betAmount * 2
                                authSuccessMessage.value = "Desafio Concluído! VOCÊ SE SAGROU CAMPEÃO de ${updatedJson.optInt("challengerScore")}x${updatedJson.optInt("opponentScore")} contra @${if (isChallenger) challenge.opponent else challenge.challenger} e ganhou ${challenge.betAmount * 2} Moedas!"
                            } else if (winner == "draw") {
                                finalGold += challenge.betAmount
                                authSuccessMessage.value = "Desafio Concluído! DEU EMPATE (${updatedJson.optInt("challengerScore")}x${updatedJson.optInt("opponentScore")})! Moedas devolvidas."
                            } else {
                                authError.value = "Desafio Concluído! Você perdeu o duelo de ${updatedJson.optInt("challengerScore")}x${updatedJson.optInt("opponentScore")} contra @$winner."
                            }
                            val updated = activeP.copy(gold = finalGold)
                            repository.update(updated)
                            FirebaseManager.syncProfile(updated)
                        }
                    } else {
                        authSuccessMessage.value = "Sua pontuação de $currentScore pontos foi submetida! Aguardando oponente jogar."
                    }
                }, { err ->
                    isLoadingOnline.value = false
                    activeChallengeToPlay.value = null
                    authError.value = "Falha ao submeter score do desafio: $err"
                })
            } else if (isEndlessMode) {
                // Regular Endless Ranked Match
                val isNewHighscore = currentScore > profile.highScoreEndless
                val updatedProf = profile.copy(
                    totalSquashed = profile.totalSquashed + (currentScore / 10).toInt(),
                    highScoreEndless = if (isNewHighscore) currentScore else profile.highScoreEndless,
                    gold = profile.gold + goldEarnedTotal
                )
                repository.update(updatedProf)
                if (profile.onlineUsername != null) {
                    FirebaseManager.syncProfile(updatedProf)
                    refreshGlobalRanking()
                }
                soundManager.playGameOver()
                soundManager.playMusic(MusicTheme.LOBBY)
                currentGameState.value = GameState.GameOver(currentScore, goldEarnedTotal)
                
                // Simulate and progress our opponents locally
                repository.simulateLiveCompetitionProgress()
            } else {
                // Regular campaign map match
                soundManager.playGameOver()
                soundManager.playMusic(MusicTheme.LOBBY)
                currentGameState.value = GameState.GameOver(currentScore, goldEarnedTotal)
            }
        }
    }

    // Shop actions
    fun buyPowerup(type: String, price: Int) {
        viewModelScope.launch {
            val p = repository.getCurrentPlayerDirect() ?: return@launch
            if (p.gold < price) {
                soundManager.playObstacleHit()
                return@launch
            }
            val updated = when (type) {
                "spray" -> p.copy(gold = p.gold - price, sprayCount = p.sprayCount + 1)
                "freeze" -> p.copy(gold = p.gold - price, freezeCount = p.freezeCount + 1)
                "shoe" -> p.copy(gold = p.gold - price, tripleSquashCount = p.tripleSquashCount + 1)
                "diamond" -> p.copy(gold = p.gold - price, diamonds = p.diamonds + 1)
                else -> p
            }
            repository.update(updated)
            if (p.onlineUsername != null) {
                FirebaseManager.syncProfile(updated)
            }
            soundManager.playLevelWin()
        }
    }

    fun buyScenario(scenarioId: String, price: Int) {
        viewModelScope.launch {
            val p = repository.getCurrentPlayerDirect() ?: return@launch
            if (p.gold < price) {
                soundManager.playObstacleHit()
                return@launch
            }
            val list = p.purchasedScenarios.split(",").toMutableSet()
            if (list.contains(scenarioId)) return@launch

            list.add(scenarioId)
            val updated = p.copy(
                gold = p.gold - price,
                purchasedScenarios = list.joinToString(",")
            )
            repository.update(updated)
            if (p.onlineUsername != null) {
                FirebaseManager.syncProfile(updated)
            }
            soundManager.playLevelWin()
        }
    }

    fun selectScenario(scenarioId: String) {
        viewModelScope.launch {
            val p = repository.getCurrentPlayerDirect() ?: return@launch
            val list = p.purchasedScenarios.split(",")
            if (!list.contains(scenarioId)) return@launch
            val updated = p.copy(selectedScenario = scenarioId)
            repository.update(updated)
            currentGameScenario.value = ScenarioType.values().find { it.id == scenarioId } ?: ScenarioType.KITCHEN
            if (p.onlineUsername != null) {
                FirebaseManager.syncProfile(updated)
            }
        }
    }

    fun buySkin(skinId: String, price: Int) {
        viewModelScope.launch {
            val p = repository.getCurrentPlayerDirect() ?: return@launch
            if (p.gold < price) {
                soundManager.playObstacleHit()
                return@launch
            }
            val list = p.purchasedSkins.split(",").toMutableSet()
            if (list.contains(skinId)) return@launch

            list.add(skinId)
            val updated = p.copy(
                gold = p.gold - price,
                purchasedSkins = list.joinToString(",")
            )
            repository.update(updated)
            if (p.onlineUsername != null) {
                FirebaseManager.syncProfile(updated)
            }
            soundManager.playLevelWin()
        }
    }

    fun selectSkin(skinId: String) {
        viewModelScope.launch {
            val p = repository.getCurrentPlayerDirect() ?: return@launch
            val list = p.purchasedSkins.split(",")
            if (!list.contains(skinId)) return@launch
            val updated = p.copy(selectedSkin = skinId)
            repository.update(updated)
            if (p.onlineUsername != null) {
                FirebaseManager.syncProfile(updated)
            }
        }
    }

    // Profile actions
    fun createAndSwitchProfile(nickname: String, avatarIndex: Int) {
        viewModelScope.launch {
            val formatted = if (nickname.isBlank()) "Inseto_Slayer" else nickname.trim()
            val newProfile = PlayerProfile(
                nickname = formatted,
                avatarId = avatarIndex,
                gold = 100,
                isCurrentUser = true
            )
            val newId = repository.insert(newProfile)
            repository.setActivePlayer(newId.toInt())
            soundManager.playLevelWin()
        }
    }

    fun deleteProfile(profileId: Int) {
        viewModelScope.launch {
            val p = repository.getPlayerById(profileId) ?: return@launch
            if (p.isCurrentUser) {
                // If deleting active player, try to find another to set active first
                repository.delete(p)
                val all = repository.getCurrentPlayerDirect() // null or other
                if (all == null) {
                    // Try to activate any remaining player
                    val listFlow = repository.allProfiles
                    // In ViewModel scope access database directly to find first
                    val list = repository.allProfiles
                    // We can choose active
                }
            } else {
                repository.delete(p)
            }
        }
    }

    fun switchActiveProfile(profileId: Int) {
        viewModelScope.launch {
            repository.setActivePlayer(profileId)
            soundManager.playLevelWin()
        }
    }

    fun updateInstagram(handle: String) {
        viewModelScope.launch {
            val current = currentProfileState.value
            if (current != null) {
                val cleanHandle = handle.trim().removePrefix("@")
                val updated = current.copy(instagram = if (cleanHandle.isEmpty()) null else cleanHandle)
                repository.update(updated)
                if (updated.onlineUsername != null) {
                    FirebaseManager.syncProfile(updated)
                    refreshGlobalRanking()
                }
            }
        }
    }

    // --- Firebase Actions ---

    fun registerOnlineUser(email: String, password: String, username: String, avatarId: Int) {
        val cleanUser = username.lowercase().trim().replace(" ", "")
        if (cleanUser.isEmpty()) {
            authError.value = "O nome de usuário não pode ser vazio."
            return
        }
        isLoadingOnline.value = true
        authError.value = null
        authSuccessMessage.value = null
        
        viewModelScope.launch {
            FirebaseManager.registerUser(
                email = email,
                password = password,
                username = cleanUser,
                avatarId = avatarId,
                onSuccess = { profile ->
                    isLoadingOnline.value = false
                    firebaseUserEmail.value = profile.firebaseEmail
                    firebaseUsername.value = profile.onlineUsername
                    authSuccessMessage.value = "Conta criada com sucesso! Bem-vindo, @$cleanUser."
                    
                    // Insert into local DB as currently active user
                    viewModelScope.launch {
                        val newId = repository.insert(profile)
                        repository.setActivePlayer(newId.toInt())
                        refreshGlobalRanking()
                        refreshFriends()
                        refreshChallenges()
                    }
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun loginOnlineUser(email: String, password: String) {
        isLoadingOnline.value = true
        authError.value = null
        authSuccessMessage.value = null
        
        viewModelScope.launch {
            FirebaseManager.loginUser(
                email = email,
                password = password,
                onSuccess = { profile ->
                    isLoadingOnline.value = false
                    firebaseUserEmail.value = profile.firebaseEmail
                    firebaseUsername.value = profile.onlineUsername
                    authSuccessMessage.value = "Login realizado com sucesso!"
                    
                    // Add/update details in local Room and make active
                    viewModelScope.launch {
                        // Access a direct list state of profiles from Db
                        val current = repository.getCurrentPlayerDirect()
                        
                        val finalId = if (current != null && current.onlineUsername == profile.onlineUsername) {
                            // Update local copy
                            val updated = profile.copy(id = current.id)
                            repository.update(updated)
                            current.id
                        } else {
                            // Insert fresh online copy
                            repository.insert(profile).toInt()
                        }
                        
                        repository.setActivePlayer(finalId)
                        refreshGlobalRanking()
                        refreshFriends()
                        refreshChallenges()
                    }
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun logoutUser() {
        playButtonClick()
        authSuccessMessage.value = "Desconectado do servidor."
        
        // Switch back to an offline Guest profile
        viewModelScope.launch {
            val all = repository.getAllProfilesDirect()
            val existingGuest = all.find { it.nickname == "Jogador" && it.firebaseEmail == null }
            if (existingGuest != null) {
                repository.setActivePlayer(existingGuest.id)
            } else {
                val guest = PlayerProfile(nickname = "Jogador", avatarId = 0, isCurrentUser = true)
                val newId = repository.insert(guest)
                repository.setActivePlayer(newId.toInt())
            }
        }
    }

    fun refreshGlobalRanking() {
        viewModelScope.launch {
            val ranking = FirebaseManager.fetchGlobalRanking()
            val currentNickname = firebaseUsername.value
            
            val formatted = ranking.map { p ->
                if (currentNickname != null && p.nickname == currentNickname) {
                    p.copy(isCurrentUser = true)
                } else {
                    p.copy(isCurrentUser = false)
                }
            }
            globalRankingList.value = formatted
        }
    }

    fun refreshFriends() {
        val user = firebaseUsername.value ?: return
        viewModelScope.launch {
            friendsMap.value = FirebaseManager.fetchFriendsList(user)
        }
    }

    fun refreshChallenges() {
        val user = firebaseUsername.value ?: return
        viewModelScope.launch {
            challengesList.value = FirebaseManager.fetchChallengesForUser(user)
        }
    }

    fun sendFriendRequest(targetUsername: String) {
        val fromUser = firebaseUsername.value ?: return
        val target = targetUsername.lowercase().trim().replace(" ", "")
        if (target.isEmpty()) {
            authError.value = "Digite um nome de usuário."
            return
        }
        isLoadingOnline.value = true
        authError.value = null
        authSuccessMessage.value = null
        
        viewModelScope.launch {
            FirebaseManager.sendFriendRequest(
                fromUser = fromUser,
                toUser = target,
                onSuccess = {
                    isLoadingOnline.value = false
                    authSuccessMessage.value = "Solicitação de amizade enviada para @$target!"
                    refreshFriends()
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun acceptFriendRequest(targetUsername: String) {
        val currentUser = firebaseUsername.value ?: return
        isLoadingOnline.value = true
        authError.value = null
        authSuccessMessage.value = null
        
        viewModelScope.launch {
            FirebaseManager.acceptFriendRequest(
                fromUser = currentUser,
                toUser = targetUsername,
                onSuccess = {
                    isLoadingOnline.value = false
                    authSuccessMessage.value = "Você agora é amigo de @$targetUsername!"
                    refreshFriends()
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun sendChallenge(targetUsername: String, betAmount: Int) {
        val currentUr = firebaseUsername.value ?: return
        if (betAmount < 0) {
            authError.value = "Valor de aposta inválido."
            return
        }
        
        viewModelScope.launch {
            val profile = repository.getCurrentPlayerDirect() ?: return@launch
            if (profile.gold < betAmount) {
                authError.value = "Você não possui moedas suficientes para apostar $betAmount."
                return@launch
            }
            
            isLoadingOnline.value = true
            authError.value = null
            authSuccessMessage.value = null
            
            FirebaseManager.createChallenge(
                challenger = currentUr,
                opponent = targetUsername,
                betAmount = betAmount,
                onSuccess = { challengeId ->
                    isLoadingOnline.value = false
                    authSuccessMessage.value = "Desafio enviado para @$targetUsername valendo $betAmount Moedas!"
                    
                    viewModelScope.launch {
                        val updated = profile.copy(gold = profile.gold - betAmount)
                        repository.update(updated)
                        FirebaseManager.syncProfile(updated)
                    }
                    refreshChallenges()
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun acceptChallenge(challenge: FirebaseChallenge) {
        val currentUr = firebaseUsername.value ?: return
        
        viewModelScope.launch {
            val profile = repository.getCurrentPlayerDirect() ?: return@launch
            if (profile.gold < challenge.betAmount) {
                authError.value = "Você não tem moedas suficientes para aceitar este desafio ($challenge.betAmount)."
                return@launch
            }
            
            isLoadingOnline.value = true
            authError.value = null
            authSuccessMessage.value = null
            
            FirebaseManager.acceptChallenge(
                challengeId = challenge.id,
                challenger = challenge.challenger,
                opponent = challenge.opponent,
                onSuccess = {
                    isLoadingOnline.value = false
                    authSuccessMessage.value = "Desafio aceito! Pronto para esmagar!"
                    
                    viewModelScope.launch {
                        val updated = profile.copy(gold = profile.gold - challenge.betAmount)
                        repository.update(updated)
                        FirebaseManager.syncProfile(updated)
                    }
                    refreshChallenges()
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun declineChallenge(challenge: FirebaseChallenge) {
        viewModelScope.launch {
            isLoadingOnline.value = true
            authError.value = null
            authSuccessMessage.value = null
            
            val isChallenger = (firebaseUsername.value == challenge.challenger)
            
            FirebaseManager.declineChallenge(
                challengeId = challenge.id,
                challenger = challenge.challenger,
                opponent = challenge.opponent,
                onSuccess = {
                    isLoadingOnline.value = false
                    authSuccessMessage.value = "Desafio recusado."
                    
                    // Refund gold to the challenger if the challenger has paid
                    if (isChallenger) {
                        viewModelScope.launch {
                            val profile = repository.getCurrentPlayerDirect()
                            if (profile != null && profile.onlineUsername == challenge.challenger) {
                                val updated = profile.copy(gold = profile.gold + challenge.betAmount)
                                repository.update(updated)
                                FirebaseManager.syncProfile(updated)
                            }
                        }
                    }
                    
                    refreshChallenges()
                },
                onError = { err ->
                    isLoadingOnline.value = false
                    authError.value = err
                }
            )
        }
    }

    fun playChallengeMatch(challenge: FirebaseChallenge) {
        viewModelScope.launch {
            stopGameLoop()
            currentLevel = null
            isEndlessMode = true
            activeChallengeToPlay.value = challenge
            
            score.value = 0
            goldEarned.value = 0
            lives.value = 5
            damage.value = 0f
            timeLeftSec.value = 9999
            activeBugs.value = emptyList()
            activeSplatters.value = emptyList()
            activeVFX.value = emptyList()
            freezeDurationLeftMs.value = 0
            shoeDurationLeftMs.value = 0
            activeDrops.value = emptyList()
            poisonClouds.value = emptyList()
            activePoisonGunTimeLeftMs.value = 0L
            activePoisonTrailTimeLeftMs.value = 0L
            lastDropSpawnSec = 0L
            tickCount = 0
            virtualTickAccumulator = 0f

            currentGameState.value = GameState.Playing
            
            val scnId = repository.getCurrentPlayerDirect()?.selectedScenario ?: "kitchen"
            val activeScn = ScenarioType.values().find { it.id == scnId } ?: ScenarioType.KITCHEN
            currentGameScenario.value = activeScn

            val theme = when (scnId) {
                "kitchen", "wood" -> MusicTheme.KITCHEN
                "picnic", "textile" -> MusicTheme.PICNIC
                "garden", "sand" -> MusicTheme.GARDEN
                "sewer", "space" -> MusicTheme.SEWER
                else -> MusicTheme.KITCHEN
            }
            soundManager.playMusic(theme)
            startGameLoop()
        }
    }

    private suspend fun seedDefaultProfiles() {
        if (repository.getAllProfilesDirect().isNotEmpty()) return
        val players = listOf(
            PlayerProfile(
                nickname = "Esmagador99",
                avatarId = 1,
                totalSquashed = 2300,
                highScoreEndless = 450,
                levelReached = 8,
                gold = 1200
            ),
            PlayerProfile(
                nickname = "ChineladaVeloz",
                avatarId = 2,
                totalSquashed = 1950,
                highScoreEndless = 380,
                levelReached = 6,
                gold = 850
            ),
            PlayerProfile(
                nickname = "DonaRute_DoCapacho",
                avatarId = 3,
                totalSquashed = 1450,
                highScoreEndless = 295,
                levelReached = 5,
                gold = 520
            ),
            PlayerProfile(
                nickname = "MembroDoGreenpeace",
                avatarId = 4,
                totalSquashed = 400,
                highScoreEndless = 90,
                levelReached = 2,
                gold = 150
            ),
            PlayerProfile(
                nickname = "DedosDeAço",
                avatarId = 5,
                totalSquashed = 3100,
                highScoreEndless = 580,
                levelReached = 10,
                gold = 2500
            ),
            PlayerProfile(
                nickname = "Jogador",
                avatarId = 0,
                isCurrentUser = true,
                gold = 100
            )
        )
        for (p in players) {
            repository.insert(p)
        }
    }

    private fun getStableRandom(seed: Long, index: Int): Float {
        var x = (seed xor 0x5DEECE66DL) * 25214903917L + index * 1103515245L + 12345L
        x = x and 0x7fffffffL
        x = (x xor (x ushr 16)) * 0x85ebca6bL
        x = x and 0x7fffffffL
        x = (x xor (x ushr 13)) * 0xc2b2ae35L
        x = x and 0x7fffffffL
        x = x xor (x ushr 16)
        return (x and 0xfffffffL).toFloat() / 0xfffffffL.toFloat()
    }

    fun fetchGlobalPixConfig() {
        viewModelScope.launch {
            try {
                val json = com.example.data.FirebaseManager.getGlobalPixConfig()
                if (json != null) {
                    val key = json.optString("pixKey", "")
                    if (key.isNotEmpty()) {
                        globalPixKey.value = key
                    }
                    val qr = json.optString("qrCodeBase64", "")
                    if (qr.isNotEmpty()) {
                        globalPixQrBase64.value = qr
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("InsectGameViewModel", "Failed to fetch global Pix configurations", e)
            }
        }
    }

    fun saveCustomPixData(key: String, base64: String) {
        viewModelScope.launch {
            isLoadingOnline.value = true
            val success = com.example.data.FirebaseManager.updateGlobalPixConfig(key, base64)
            if (success) {
                globalPixKey.value = key
                globalPixQrBase64.value = base64.ifEmpty { null }
                android.util.Log.d("InsectGameViewModel", "Global Pix successfully updated in server")
            }
            isLoadingOnline.value = false
        }
    }

    override fun onCleared() {
        stopGameLoop()
        soundManager.stopMusic()
        super.onCleared()
    }
}
