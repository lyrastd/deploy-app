package com.example.game

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

enum class MusicTheme {
    LOBBY,
    KITCHEN,
    PICNIC,
    GARDEN,
    SEWER,
    NONE
}

class SoundEffectManager(context: Context) {
    private val attributionContext: Context = context

    private var toneGenerator: ToneGenerator? = null
    private var isMuted = false
    private val musicPlayer = ChiptunePlayer(attributionContext)

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = attributionContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            attributionContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (e: Throwable) {
        null
    }

    fun vibrateWeak() {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(35)
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("SoundEffectManager", "vibrateWeak failed: ${e.message}")
        }
    }

    fun vibrateStrong() {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(300, 220))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(300)
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("SoundEffectManager", "vibrateStrong failed: ${e.message}")
        }
    }

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 65)
        } catch (t: Throwable) {
            Log.e("SoundEffectManager", "Failed to initialize ToneGenerator: ${t.message}")
        }
    }

    fun toggleMute(): Boolean {
        isMuted = !isMuted
        musicPlayer.setMuted(isMuted)
        return isMuted
    }

    fun getMuted(): Boolean = isMuted

    fun playMusic(theme: MusicTheme) {
        musicPlayer.setMuted(isMuted)
        musicPlayer.playTheme(theme)
    }

    fun stopMusic() {
        musicPlayer.stop()
    }

    fun playSquishSound(isHeavy: Boolean = false) {
        vibrateWeak()
        if (isMuted) return
        try {
            if (isHeavy) {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 100)
            } else {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 50)
            }
        } catch (t: Throwable) {}
    }

    fun playButtonClick() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
        } catch (t: Throwable) {}
    }

    fun playObstacleHit() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 150)
        } catch (t: Throwable) {}
    }

    fun playLevelWin() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_SUP_PIP, 100)
            Thread {
                try {
                    Thread.sleep(80)
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_CONFIRM, 120)
                } catch (tx: Throwable) {}
            }.start()
        } catch (t: Throwable) {}
    }

    fun playGameOver() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_CALLDROP_LITE, 200)
        } catch (t: Throwable) {}
    }

    fun playPowerupSplat() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_SUP_CONGESTION, 150)
        } catch (t: Throwable) {}
    }

    fun playDamage() {
        vibrateStrong()
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 120)
            Thread {
                try {
                    Thread.sleep(100)
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_CONGESTION, 150)
                } catch (tx: Throwable) {}
            }.start()
        } catch (t: Throwable) {}
    }

    fun playItemCollect() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_PIP, 60)
            Thread {
                try {
                    Thread.sleep(60)
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_PIP, 80)
                } catch (tx: Throwable) {}
            }.start()
        } catch (t: Throwable) {}
    }

    fun playLifeCollect() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 50)
            Thread {
                try {
                    Thread.sleep(50)
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_PIP, 60)
                    Thread.sleep(60)
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_CONFIRM, 120)
                } catch (tx: Throwable) {}
            }.start()
        } catch (t: Throwable) {}
    }

    fun playExplodeInsects() {
        vibrateWeak()
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_SUP_CONGESTION, 250)
            Thread {
                try {
                    Thread.sleep(100)
                    toneGenerator?.startTone(ToneGenerator.TONE_CDMA_CALLDROP_LITE, 200)
                } catch (tx: Throwable) {}
            }.start()
        } catch (t: Throwable) {}
    }

    private var lastPistolSoundTime = 0L
    fun playPistolUse() {
        if (isMuted) return
        val now = System.currentTimeMillis()
        if (now - lastPistolSoundTime < 180) return
        lastPistolSoundTime = now
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 50)
        } catch (t: Throwable) {}
    }

    private var lastPoisonSoundTime = 0L
    fun playPoisonUse() {
        if (isMuted) return
        val now = System.currentTimeMillis()
        if (now - lastPoisonSoundTime < 250) return
        lastPoisonSoundTime = now
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 100)
        } catch (t: Throwable) {}
    }

    private class ChiptunePlayer(private val appContext: Context) {
        private var isPlaying = false
        private var currentTheme = MusicTheme.NONE
        private var isMuted = false
        private var musicThread: Thread? = null

        private val lobbyMelody = listOf(
            60, 64, 67, 64, 65, 69, 72, 69, 67, 71, 74, 71, 72, 72, 72, 0,
            60, 64, 67, 64, 65, 69, 72, 69, 67, 71, 74, 71, 72, 76, 79, 0
        )
        private val lobbyBass = listOf(
            48, 48, 48, 48, 41, 41, 41, 41, 43, 43, 43, 43, 48, 48, 48, 48,
            48, 48, 48, 48, 41, 41, 41, 41, 43, 43, 43, 43, 48, 48, 48, 48
        )

        private val kitchenMelody = listOf(
            60, 64, 60, 64, 62, 66, 62, 66, 64, 67, 64, 67, 67, 69, 71, 72,
            72, 67, 72, 67, 69, 64, 69, 64, 67, 62, 67, 62, 60, 64, 67, 72
        )
        private val kitchenBass = listOf(
            36, 36, 40, 40, 38, 38, 42, 42, 40, 40, 43, 43, 43, 45, 47, 48,
            48, 48, 43, 43, 45, 45, 40, 40, 43, 43, 38, 38, 36, 40, 43, 48
        )

        private val picnicMelody = listOf(
            67, 64, 67, 64, 69, 65, 69, 65, 71, 67, 71, 67, 72, 72, 72, 0,
            72, 71, 69, 67, 65, 64, 62, 60, 59, 60, 62, 64, 67, 69, 71, 72
        )
        private val picnicBass = listOf(
            48, 48, 43, 43, 45, 45, 41, 41, 43, 43, 38, 38, 48, 48, 48, 48,
            48, 47, 45, 43, 41, 40, 38, 36, 35, 36, 38, 40, 43, 45, 47, 48
        )

        private val gardenMelody = listOf(
            64, 67, 69, 71, 71, 69, 67, 64, 62, 64, 67, 69, 69, 67, 64, 62,
            64, 67, 69, 71, 74, 72, 71, 69, 67, 69, 71, 74, 76, 74, 72, 71
        )
        private val gardenBass = listOf(
            40, 40, 43, 43, 45, 45, 43, 43, 38, 38, 40, 40, 45, 45, 40, 40,
            40, 40, 43, 43, 50, 50, 48, 48, 43, 43, 45, 45, 47, 47, 45, 43
        )

        private val sewerMelody = listOf(
            57, 58, 60, 58, 57, 58, 57, 54, 57, 58, 60, 62, 63, 62, 60, 58,
            57, 58, 60, 62, 63, 65, 66, 65, 63, 62, 60, 58, 57, 53, 54, 50
        )
        private val sewerBass = listOf(
            45, 45, 46, 46, 45, 45, 42, 42, 45, 45, 46, 46, 48, 48, 46, 46,
            45, 45, 46, 46, 48, 48, 50, 50, 48, 48, 46, 46, 45, 41, 42, 38
        )

        fun setMuted(muted: Boolean) {
            isMuted = muted
        }

        @Synchronized
        fun playTheme(theme: MusicTheme) {
            if (currentTheme == theme) return
            currentTheme = theme
            stop()
            if (theme == MusicTheme.NONE) return

            isPlaying = true
            musicThread = Thread {
                var localTrack: AudioTrack? = null
                try {
                    val sampleRate = 22050
                    val minBufferSize = AudioTrack.getMinBufferSize(
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    val bufferSize = Math.max(minBufferSize, 4096)

                    try {
                        val builder = AudioTrack.Builder()
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_GAME)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                    .build()
                            )
                            .setAudioFormat(
                                AudioFormat.Builder()
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setSampleRate(sampleRate)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                    .build()
                            )
                            .setBufferSizeInBytes(bufferSize)
                            .setTransferMode(AudioTrack.MODE_STREAM)

                        val track = builder.build()
                        localTrack = track
                        track.play()
                    } catch (e: Exception) {
                        Log.e("SoundEffectManager", "Can't play AudioTrack: ${e.message}")
                        return@Thread
                    }

                    var stepIndex = 0
                    val stepDurationMs = 175

                    while (isPlaying && currentTheme == theme) {
                        if (isMuted) {
                            try {
                                Thread.sleep(stepDurationMs.toLong())
                            } catch (ie: InterruptedException) {
                                break
                            }
                            continue
                        }

                        val melody = when (theme) {
                            MusicTheme.LOBBY -> lobbyMelody
                            MusicTheme.KITCHEN -> kitchenMelody
                            MusicTheme.PICNIC -> picnicMelody
                            MusicTheme.GARDEN -> gardenMelody
                            MusicTheme.SEWER -> sewerMelody
                            else -> emptyList()
                        }

                        val bass = when (theme) {
                            MusicTheme.LOBBY -> lobbyBass
                            MusicTheme.KITCHEN -> kitchenBass
                            MusicTheme.PICNIC -> picnicBass
                            MusicTheme.GARDEN -> gardenBass
                            MusicTheme.SEWER -> sewerBass
                            else -> emptyList()
                        }

                        if (melody.isEmpty()) {
                            try {
                                Thread.sleep(stepDurationMs.toLong())
                            } catch (ie: InterruptedException) {
                                break
                            }
                            continue
                        }

                        val mNote = melody[stepIndex % melody.size]
                        val bNote = bass[stepIndex % bass.size]

                        val f1 = midiToFreq(mNote)
                        val f2 = midiToFreq(bNote)

                        val samples = generateNoteSamples(f1, f2, stepDurationMs)

                        try {
                            localTrack?.write(samples, 0, samples.size)
                        } catch (e: Exception) {
                            break
                        }

                        stepIndex++
                    }

                    try {
                        localTrack?.stop()
                        localTrack?.release()
                    } catch (e: Exception) {}
                } catch (t: Throwable) {
                    Log.e("SoundEffectManager", "ChiptunePlayer Thread failure", t)
                    try {
                        localTrack?.stop()
                        localTrack?.release()
                    } catch (e: Exception) {}
                }
            }.apply {
                name = "ChiptuneSynthesizerThread"
                priority = Thread.NORM_PRIORITY
                start()
            }
        }

        @Synchronized
        fun stop() {
            isPlaying = false
            musicThread?.interrupt()
            musicThread = null
        }

        private fun midiToFreq(noteId: Int): Double {
            if (noteId <= 0) return 0.0
            return 440.0 * Math.pow(2.0, (noteId - 69) / 12.0)
        }

        private fun generateNoteSamples(f1: Double, f2: Double, stepDurationMs: Int): ShortArray {
            val sampleRate = 22050
            val totalSamples = (sampleRate * stepDurationMs) / 1000
            val samples = ShortArray(totalSamples)

            for (n in 0 until totalSamples) {
                val t = n.toDouble() / sampleRate.toDouble()

                val val1 = if (f1 > 0.0) {
                    if (Math.sin(2.0 * Math.PI * f1 * t) > 0.0) 0.18 else -0.18
                } else {
                    0.0
                }

                val val2 = if (f2 > 0.0) {
                    val period = 1.0 / f2
                    val phase = (t % period) / period
                    if (phase < 0.5) {
                        -0.12 + 0.48 * phase
                    } else {
                        0.36 - 0.48 * phase
                    }
                } else {
                    0.0
                }

                val decay = Math.exp(-4.5 * n.toDouble() / totalSamples.toDouble())

                val mixed = (val1 + val2) * decay
                samples[n] = (mixed * 32767.0).toInt().coerceIn(-32768, 32767).toShort()
            }
            return samples
        }
    }
}
