package com.example.game

enum class BugType(
    val displayName: String,
    val baseHp: Int,
    val points: Int,
    val goldValue: Int,
    val baseSpeed: Float, // Relative speed units per fraction-second
    val sizeDp: Int,
    val avoidance: Boolean = false // If true, tapping this is bad!
) {
    ANT("Formiga", 1, 10, 2, 0.12f, 44),
    TERMITE("Cupim", 1, 15, 3, 0.18f, 38),
    COCKROACH("Barata", 1, 25, 5, 0.14f, 54),
    SPIDER("Aranha", 1, 35, 8, 0.11f, 48),
    BEETLE("Besouro Encouraçado", 3, 60, 15, 0.06f, 62), // Armored!
    WASP("Vespa Assassina", 1, -50, -10, 0.22f, 48, avoidance = true), // Obstacle!
    SCORPION("Escorpião Venenoso", 1, -120, -25, 0.15f, 50, avoidance = true), // Poison hazard
    CENTIPEDE("Centopeia Mutante", 2, 85, 20, 0.24f, 46) // Rapid elite targets
}

enum class ScenarioType(
    val id: String,
    val displayName: String,
    val primaryColor: Long, // Hex representation
    val secondaryColor: Long,
    val cost: Int,
    val description: String,
    val emojiBackground: String // Scenic visual cues
) {
    KITCHEN("kitchen", "Cozinha da Vovó", 0xFFE2E3DD, 0xFFCED0C8, 0, "Chão clássico de azulejos de cerâmica.", "🍳🍽️"),
    WOOD("wood", "Tábua de Madeira", 0xFFD7CCC8, 0xFF8D6E63, 1200, "Piso de madeira rústica com tábuas corridas.", "🪵🪓🔨"),
    PICNIC("picnic", "Toalha de Picnic", 0xFFFFEBEE, 0xFFFFCDD2, 1300, "Estampa xadrez vermelha e branca na grama.", "🧺🍓🍉"),
    SAND("sand", "Areia da Costa", 0xFFFFF9C4, 0xFFFFE082, 1500, "Areia quente da praia esculpida por ventos litorâneos.", "🏖️🐚🦀"),
    GARDEN("garden", "Folhas do Jardim", 0xFFF7FBF1, 0xFFD7E8CD, 1600, "Grama verde-musgo com tons de sálvia orgânica.", "🌳🍃🍂"),
    TEXTILE("textile", "Toalha de Linho", 0xFFE0F2F1, 0xFFB2DFDB, 1800, "Pano de linho tramado azul suave e confortável.", "🧵🪡🎽"),
    SEWER("sewer", "Tubo de Esgoto", 0xFF43493F, 0xFF191D17, 2000, "Grunges escuros, umidade e poças radioativas.", "🚧💧🧪"),
    SPACE("space", "Estação de Metal", 0xFF303030, 0xFF1A1A1A, 2200, "Metal futurista fosco com reentrâncias industriais.", "🚀🚀⚡")
}

data class BugInstance(
    val id: Long,
    val type: BugType,
    val x: Float, // 0.0 -> 1.0 (screen width ratio)
    val y: Float, // 0.0 -> 1.0 (screen height ratio)
    val hp: Int,
    val isSmashed: Boolean = false,
    val angle: Float = 180f, // Orientation angle in degrees
    val scale: Float = 1.0f, // For squeeze / spawn pop effect
    val directionChangeTimer: Long = 0,
    val pathParam: Float = 0f, // Erratic sinus wiggle offsets
    val isInfected: Boolean = false,
    val infectionTimerMs: Long = 0L
)

data class SplatterInstance(
    val id: Long,
    val x: Float,
    val y: Float,
    val skinId: String,
    val bugType: BugType,
    val sizeDp: Int,
    val timestamp: Long
)

data class GameVFX(
    val id: Long,
    val x: Float,
    val y: Float,
    val text: String,
    val color: Long,
    var yOffset: Float = 0f,
    var alpha: Float = 1f,
    val creationTime: Long
)

// Level design structure for Singleplayer Level Select
data class CampaignLevel(
    val id: Int,
    val name: String,
    val scenario: ScenarioType,
    val targetScore: Int,
    val timeLimitSec: Int,
    val description: String,
    val allowedSpecies: List<BugType>,
    val goldReward: Int
)

object LevelCatalog {
    val levels = listOf(
        CampaignLevel(
            id = 1,
            name = "Invasão Silenciosa",
            scenario = ScenarioType.KITCHEN,
            targetScore = 200,
            timeLimitSec = 30,
            description = "Esmague formigas e baratas lentas no chão da cozinha de azulejos. Consiga 200 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.COCKROACH),
            goldReward = 100
        ),
        CampaignLevel(
            id = 2,
            name = "Ataque dos Cupins",
            scenario = ScenarioType.WOOD,
            targetScore = 350,
            timeLimitSec = 35,
            description = "Cupins rápidos grudados na tábua de madeira! Foco na velocidade extrema. Consiga 350 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.TERMITE, BugType.COCKROACH),
            goldReward = 150
        ),
        CampaignLevel(
            id = 3,
            name = "Picnic Sangrento",
            scenario = ScenarioType.PICNIC,
            targetScore = 500,
            timeLimitSec = 40,
            description = "O picnic foi arruinado sobre o pano xadrez! Aranhas ioiô estão descendo. Cuidado com as vespas! Consiga 500 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.SPIDER, BugType.WASP),
            goldReward = 220
        ),
        CampaignLevel(
            id = 4,
            name = "Força Couraçada",
            scenario = ScenarioType.SAND,
            targetScore = 650,
            timeLimitSec = 45,
            description = "Besouros encouraçados invadiram a areia quente. Cuidado: após o primeiro golpe eles entram em fúria! Consiga 650 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.BEETLE, BugType.WASP),
            goldReward = 300
        ),
        CampaignLevel(
            id = 5,
            name = "Folhas que Sobrevivem",
            scenario = ScenarioType.GARDEN,
            targetScore = 800,
            timeLimitSec = 45,
            description = "Sobrevivência no jardim arborizado! Centopeias mutantes super velozes começaram a rastejar! Consiga 800 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.TERMITE, BugType.COCKROACH, BugType.SPIDER, BugType.CENTIPEDE),
            goldReward = 450
        ),
        CampaignLevel(
            id = 6,
            name = "Vespa Fúria",
            scenario = ScenarioType.TEXTILE,
            targetScore = 1000,
            timeLimitSec = 40,
            description = "Enxames de vespas assassinas cruzando o pano fino azul! NÃO toque nas vespas. Consiga 1000 pontos!",
            allowedSpecies = listOf(BugType.COCKROACH, BugType.BEETLE, BugType.WASP, BugType.CENTIPEDE),
            goldReward = 600
        ),
        CampaignLevel(
            id = 7,
            name = "O Esgoto Mutante",
            scenario = ScenarioType.SEWER,
            targetScore = 1300,
            timeLimitSec = 45,
            description = "Tubulação úmida tóxica com escorpiões venenosos ocultos! Se tocados, eles envenenam sua tela! Consiga 1300 pontos!",
            allowedSpecies = listOf(BugType.TERMITE, BugType.COCKROACH, BugType.SPIDER, BugType.BEETLE, BugType.SCORPION, BugType.CENTIPEDE),
            goldReward = 750
        ),
        CampaignLevel(
            id = 8,
            name = "Maratona Pestilenta",
            scenario = ScenarioType.SPACE,
            targetScore = 2000,
            timeLimitSec = 60,
            description = "O derradeiro desafio na estação espacial futurista de metal! Defenda-se contra escorpiões e colossais enxames. Consiga 2000 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.TERMITE, BugType.COCKROACH, BugType.SPIDER, BugType.BEETLE, BugType.WASP, BugType.SCORPION, BugType.CENTIPEDE),
            goldReward = 1200
        ),
        CampaignLevel(
            id = 9,
            name = "Cozinha em Chamas",
            scenario = ScenarioType.KITCHEN,
            targetScore = 2400,
            timeLimitSec = 55,
            description = "Formigas vermelhas de fogo voltaram à cozinha de azulejos, escoltadas por centopeias mutantes velozes! Consiga 2400 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.COCKROACH, BugType.CENTIPEDE, BugType.WASP),
            goldReward = 1500
        ),
        CampaignLevel(
            id = 10,
            name = "O Segredo da Madeira",
            scenario = ScenarioType.WOOD,
            targetScore = 2800,
            timeLimitSec = 60,
            description = "Muitos cupins rápidos e besouros gigantes invadindo a tábua rústica! Mantenha o foco extremo. Consiga 2800 pontos!",
            allowedSpecies = listOf(BugType.TERMITE, BugType.COCKROACH, BugType.BEETLE, BugType.CENTIPEDE),
            goldReward = 1800
        ),
        CampaignLevel(
            id = 11,
            name = "Banquete Noturno",
            scenario = ScenarioType.PICNIC,
            targetScore = 3200,
            timeLimitSec = 60,
            description = "O piquenique noturno atraiu aranhas mutantes gigantes e escorpiões perigosos! Desvie com prudência. Consiga 3200 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.SPIDER, BugType.SCORPION, BugType.CENTIPEDE),
            goldReward = 2000
        ),
        CampaignLevel(
            id = 12,
            name = "Tempestade de Areia",
            scenario = ScenarioType.SAND,
            targetScore = 3600,
            timeLimitSec = 65,
            description = "Invasão frenética de besouros encouraçados e centopeias rápidas na areia escaldante da praia. Consiga 3600 pontos!",
            allowedSpecies = listOf(BugType.BEETLE, BugType.CENTIPEDE, BugType.COCKROACH, BugType.WASP),
            goldReward = 2300
        ),
        CampaignLevel(
            id = 13,
            name = "Eco Sombrio do Jardim",
            scenario = ScenarioType.GARDEN,
            targetScore = 4000,
            timeLimitSec = 70,
            description = "O ecossistema inteiro do jardim atacando ao mesmo tempo. Concentração e agilidade absolutas! Consiga 4000 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.TERMITE, BugType.COCKROACH, BugType.SPIDER, BugType.BEETLE, BugType.CENTIPEDE, BugType.WASP),
            goldReward = 2600
        ),
        CampaignLevel(
            id = 14,
            name = "Caos na Toalha",
            scenario = ScenarioType.TEXTILE,
            targetScore = 4500,
            timeLimitSec = 75,
            description = "Milhares de pragas velozes serpenteando no linho azul confortável! Mantenha os dedos rápidos. Consiga 4500 pontos!",
            allowedSpecies = listOf(BugType.TERMITE, BugType.SPIDER, BugType.CENTIPEDE, BugType.COCKROACH, BugType.SCORPION),
            goldReward = 3000
        ),
        CampaignLevel(
            id = 15,
            name = "Desafio Cósmico Final",
            scenario = ScenarioType.SPACE,
            targetScore = 5500,
            timeLimitSec = 90,
            description = "FASE SUPREMA! Todas as espécies em um enxame frenético infinito na estação espacial sci-fi! Consiga 5500 pontos!",
            allowedSpecies = listOf(BugType.ANT, BugType.TERMITE, BugType.COCKROACH, BugType.SPIDER, BugType.BEETLE, BugType.CENTIPEDE, BugType.WASP, BugType.SCORPION),
            goldReward = 4000
        )
    )
}

enum class TemporaryDropType(val emoji: String, val displayName: String, val color: Long) {
    POISON_GUN("🔫", "Pistola de Veneno", 0xFF00E5FF),
    GREEN_POISON("☣️", "Nuvem Tóxica", 0xFF4CAF50),
    HEART("❤️", "Vida Extra", 0xFFFF4444)
}

data class TemporaryDrop(
    val id: Long,
    val x: Float, // 0.0 -> 1.0 (screen width ratio)
    val y: Float, // 0.0 -> 1.0 (screen height ratio)
    val type: TemporaryDropType,
    val spawnTimeMs: Long,
    val durationMs: Long = 10000L
)

data class PoisonCloud(
    val id: Long,
    val x: Float,
    val y: Float,
    val radius: Float = 0.12f,
    val spawnTimeMs: Long,
    val durationMs: Long = 3500L
)

