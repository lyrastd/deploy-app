package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.AppDatabase
import com.example.data.PlayerRepository
import com.example.game.InsectGameViewModel
import com.example.ui.BugSmasherNavigation
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create Room Database, Repository and ViewModel cleanly
        val database = AppDatabase.getInstance(applicationContext)
        val repository = PlayerRepository(database.playerDao)
        val factory = InsectGameViewModelFactory(application, repository)
        val viewModel = ViewModelProvider(this, factory)[InsectGameViewModel::class.java]

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Full-screen bleed layout handles its own safe-area padded columns
                    BugSmasherNavigation(viewModel)
                }
            }
        }
    }
}

class InsectGameViewModelFactory(
    private val application: Application,
    private val repository: PlayerRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InsectGameViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return InsectGameViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
