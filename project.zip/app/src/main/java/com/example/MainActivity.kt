package com.example

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Message
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import com.example.ui.theme.MyApplicationTheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var onGoogleSignInSuccessJs: ((String, String, String, String) -> Unit)? = null
    private var onGoogleSignInFailureJs: ((String) -> Unit)? = null

    private val legacyGoogleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val idToken = account.idToken
            if (idToken != null) {
                onGoogleSignInSuccessJs?.invoke(
                    idToken,
                    account.email ?: "",
                    account.displayName ?: "",
                    account.photoUrl?.toString() ?: ""
                )
            } else {
                onGoogleSignInFailureJs?.invoke("ID Token is null")
            }
        } catch (e: Exception) {
            onGoogleSignInFailureJs?.invoke(e.localizedMessage ?: "Unknown Google Sign-In error")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SafeWayApp()
            }
        }
    }

    fun startCredentialsFlow(webClientId: String, webView: WebView) {
        val credentialManager = CredentialManager.create(this)
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        lifecycleScope.launch {
            try {
                val result = credentialManager.getCredential(this@MainActivity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken
                    val email = googleIdTokenCredential.id
                    val displayName = googleIdTokenCredential.displayName ?: ""
                    val photoUrl = googleIdTokenCredential.profilePictureUri?.toString() ?: ""
                    
                    webView.post {
                        webView.evaluateJavascript(
                            "javascript:if(window.onGoogleSignInSuccess){ window.onGoogleSignInSuccess('$idToken', '$email', '$displayName', '$photoUrl'); }",
                            null
                        )
                    }
                } else {
                    webView.post {
                        webView.evaluateJavascript(
                            "javascript:if(window.onGoogleSignInFailure){ window.onGoogleSignInFailure('Unsupported credential type'); }",
                            null
                        )
                    }
                }
            } catch (e: androidx.credentials.exceptions.GetCredentialException) {
                // If native Credentials option failed or user cancelled, fallback to legacy Google Sign In
                startLegacyGoogleSignInFlow(webClientId, webView)
            } catch (e: Exception) {
                webView.post {
                    webView.evaluateJavascript(
                        "javascript:if(window.onGoogleSignInFailure){ window.onGoogleSignInFailure('${e.localizedMessage?.replace("'", "\\'") ?: "Unknown auth error"}'); }",
                        null
                    )
                }
            }
        }
    }

    fun startLegacyGoogleSignInFlow(webClientId: String, webView: WebView) {
        onGoogleSignInSuccessJs = { idToken, email, displayName, photoUrl ->
            webView.post {
                webView.evaluateJavascript(
                    "javascript:if(window.onGoogleSignInSuccess){ window.onGoogleSignInSuccess('$idToken', '$email', '$displayName', '$photoUrl'); }",
                    null
                )
            }
        }
        
        onGoogleSignInFailureJs = { errorMessage ->
            webView.post {
                webView.evaluateJavascript(
                    "javascript:if(window.onGoogleSignInFailure){ window.onGoogleSignInFailure('${errorMessage.replace("'", "\\'")}'); }",
                    null
                )
            }
        }

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestIdToken(webClientId)
            .build()

        val googleSignInClient = GoogleSignIn.getClient(this, gso)
        googleSignInClient.signOut().addOnCompleteListener {
            val signInIntent = googleSignInClient.signInIntent
            legacyGoogleSignInLauncher.launch(signInIntent)
        }
    }
}

class SafeWayAuthBridge(
    private val activity: MainActivity,
    private val webView: WebView
) {
    @JavascriptInterface
    fun launchGoogleSignIn(webClientId: String) {
        activity.runOnUiThread {
            activity.startCredentialsFlow(webClientId, webView)
        }
    }

    @JavascriptInterface
    fun launchLegacyGoogleSignIn(webClientId: String) {
        activity.runOnUiThread {
            activity.startLegacyGoogleSignInFlow(webClientId, webView)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafeWayApp() {
    val context = LocalContext.current
    val activity = context as? MainActivity
    
    // Core states
    var mainWebView by remember { mutableStateOf<WebView?>(null) }
    var popupWebView by remember { mutableStateOf<WebView?>(null) }
    
    var mainProgress by remember { mutableStateOf(0) }
    var popupProgress by remember { mutableStateOf(0) }
    
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    
    val targetUrl = "https://lyrastd.github.io/safeway/"
    
    // Back navigation handler
    BackHandler(enabled = true) {
        if (popupWebView != null) {
            val popup = popupWebView
            if (popup != null && popup.canGoBack()) {
                popup.goBack()
            } else {
                popupWebView = null
                popupProgress = 0
            }
        } else {
            if (mainWebView?.canGoBack() == true) {
                mainWebView?.goBack()
            } else {
                activity?.finish()
            }
        }
    }
    
    // Base layout
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Main Web View integration
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    
                    // Essential settings to simulate a standard Chrome Mobile browser
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        setSupportMultipleWindows(true)
                        javaScriptCanOpenWindowsAutomatically = true
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        
                        // Overwrite UserAgent to prevent Google OAuth security block in WebView
                        userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                    }
                    
                    // Allow necessary cookies
                    val cookieManager = CookieManager.getInstance()
                    cookieManager.setAcceptCookie(true)
                    cookieManager.setAcceptThirdPartyCookies(this, true)
                    
                    // Add modern Javascript Interface for Google Federated authentication integration
                    if (activity != null) {
                        addJavascriptInterface(SafeWayAuthBridge(activity, this), "SafeWayAuth")
                    }
                    
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            return false // Maintain hybrid web page standard navigation inside the wrapper
                        }
                        
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            canGoBack = view?.canGoBack() ?: false
                            canGoForward = view?.canGoForward() ?: false
                        }
                        
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            canGoBack = view?.canGoBack() ?: false
                            canGoForward = view?.canGoForward() ?: false
                        }
                    }
                    
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            mainProgress = newProgress
                        }
                        
                        override fun onCreateWindow(
                            view: WebView?,
                            isDialog: Boolean,
                            isUserGesture: Boolean,
                            resultMsg: Message?
                        ): Boolean {
                            if (resultMsg == null) return false
                            
                            val popup = WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    setSupportMultipleWindows(true)
                                    javaScriptCanOpenWindowsAutomatically = true
                                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                    userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                                }
                                
                                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                                
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                        return false
                                    }
                                }
                                
                                webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(v: WebView?, newProgress: Int) {
                                        popupProgress = newProgress
                                    }
                                    
                                    override fun onCloseWindow(window: WebView?) {
                                        popupWebView = null
                                        popupProgress = 0
                                    }
                                }
                            }
                            
                            val transport = resultMsg.obj as WebView.WebViewTransport
                            transport.webView = popup
                            resultMsg.sendToTarget()
                            
                            popupWebView = popup
                            return true
                        }
                    }
                    
                    loadUrl(targetUrl)
                    mainWebView = this
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("main_webview"),
            onRelease = { webView ->
                destroyWebView(webView)
            }
        )
        
        // Progress bar at the very top of the screen
        if (mainProgress < 100) {
            LinearProgressIndicator(
                progress = { mainProgress / 100f },
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .height(3.dp)
                    .testTag("main_progress_bar")
            )
        }
        
        // Popup tab view ("Guia Invisível" Overlay)
        AnimatedVisibility(
            visible = popupWebView != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                if (popupWebView != null) {
                    Column(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Invisible Guide Window header: contains merely security lock visual and dismiss control
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .windowInsetsPadding(WindowInsets.statusBars)
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .testTag("popup_header"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Autenticação Segura",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Autenticação SafeWay",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Conexão criptografada segura via Google",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            
                            IconButton(
                                onClick = {
                                    popupWebView = null
                                    popupProgress = 0
                                },
                                modifier = Modifier.testTag("popup_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Cancelar Autenticação",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        
                        // Subtle high fidelity progress bar inside the auth tab
                        if (popupProgress < 100) {
                            LinearProgressIndicator(
                                progress = { popupProgress / 100f },
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(2.dp)
                                    .testTag("popup_progress_bar")
                            )
                        } else {
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                thickness = 1.dp
                            )
                        }
                        
                        // Popup WebView viewport
                        AndroidView(
                            factory = { popupWebView!! },
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .testTag("popup_webview"),
                            onRelease = { webView ->
                                destroyWebView(webView)
                            }
                        )
                    }
                }
            }
        }
    }
}

private fun destroyWebView(webView: WebView?) {
    if (webView == null) return
    webView.post {
        try {
            val parent = webView.parent as? ViewGroup
            parent?.removeView(webView)
            webView.stopLoading()
            webView.clearHistory()
            webView.removeAllViews()
            webView.destroy()
        } catch (e: Exception) {
            // Safe catch
        }
    }
}
