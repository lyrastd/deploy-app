package com.example

import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ChannelEpg
import com.example.data.SavedChannel
import com.example.ui.SpeechHelper
import com.example.ui.VideoPlayer
import com.example.ui.theme.*
import com.example.viewmodel.TvViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: TvViewModel by viewModels()
    private var speechHelper: SpeechHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()

                // Sync device orientation and status bars with Fullscreen state
                LaunchedEffect(isFullscreen) {
                    adjustScreenAndBars(isFullscreen)
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        viewModel = viewModel,
                        onTriggerSpeech = { startSpeechSession() }
                    )
                }
            }
        }
    }

    private fun adjustScreenAndBars(hide: Boolean) {
        if (hide) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.let { controller ->
                    controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
            }
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.show(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }

    private fun startSpeechSession() {
        if (speechHelper == null) {
            speechHelper = SpeechHelper(
                context = this,
                onTranscript = { text ->
                    viewModel.processVoiceCommand(text)
                },
                onListeningChange = { active ->
                    viewModel.isSpeechListening.value = active
                },
                onError = { error ->
                    viewModel.postStatus(error)
                }
            )
        }
        speechHelper?.startListening()
    }

    override fun onDestroy() {
        speechHelper?.stopListening()
        super.onDestroy()
    }
}

@Composable
fun MainScreen(
    viewModel: TvViewModel,
    onTriggerSpeech: () -> Unit
) {
    val context = LocalContext.current
    val channels by viewModel.channelsState.collectAsStateWithLifecycle()
    val favorites by viewModel.favoriteChannelsState.collectAsStateWithLifecycle()
    val preferences by viewModel.userPreferenceState.collectAsStateWithLifecycle()
    
    val currentChannel by viewModel.currentChannel.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val volume by viewModel.volume.collectAsStateWithLifecycle()
    val isMuted by viewModel.isMuted.collectAsStateWithLifecycle()
    val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()
    
    val isLoading by viewModel.isLoadingNewChannel.collectAsStateWithLifecycle()
    val statusMsg by viewModel.statusMessage.collectAsStateWithLifecycle()
    val errorMsg by viewModel.errorMessage.collectAsStateWithLifecycle()
    
    val voiceListening by viewModel.isSpeechListening.collectAsStateWithLifecycle()
    val voiceTranscript by viewModel.speechTranscript.collectAsStateWithLifecycle()
    
    val epgList by viewModel.personalizedEpg.collectAsStateWithLifecycle()
    val isEpgRefreshing by viewModel.refreshingEpg.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showPreferencesDialog by remember { mutableStateOf(false) }
    var prefInput by remember { mutableStateOf(preferences?.genrePreferences ?: "Notícias, Esportes, Natureza") }

    // Sync preferences input fields
    LaunchedEffect(preferences) {
        preferences?.let {
            prefInput = it.genrePreferences
        }
    }

    // Audio permission launcher
    val voicePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onTriggerSpeech()
        } else {
            viewModel.postStatus("Habilite o microfone para sintonizar por voz!")
        }
    }

    if (isFullscreen) {
        // Landscape Full Screen Video HUD
        Box(modifier = Modifier.fillMaxSize()) {
            VideoPlayer(
                streamUrl = currentChannel?.streamUrl,
                isPlaying = isPlaying,
                volume = volume,
                isMuted = isMuted,
                modifier = Modifier.fillMaxSize()
            )

            // Transparent Controller HUD layer visible on hover/tap
            var showControlsHud by remember { mutableStateOf(true) }
            LaunchedEffect(showControlsHud) {
                if (showControlsHud) {
                    kotlinx.coroutines.delay(5000)
                    showControlsHud = false
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { showControlsHud = !showControlsHud }
            ) {
                AnimatedVisibility(
                    visible = showControlsHud,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f))
                            .padding(24.dp)
                    ) {
                        // Title HUD
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = currentChannel?.name ?: "Sem sinal",
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Sincronia inteligente • ${currentChannel?.resolution ?: "1080p"} HD",
                                    color = LyraPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            IconButton(
                                onClick = { viewModel.toggleFullscreen() },
                                modifier = Modifier
                                    .background(DarkSurfaceElevated, CircleShape)
                                    .testTag("exit_fullscreen_hud")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Sair da tela cheia", tint = Color.White)
                            }
                        }

                        // Bottom controllers HUD
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Play/Pause Action
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { viewModel.isPlaying.value = !isPlaying },
                                    colors = ButtonDefaults.buttonColors(containerColor = LyraPrimary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    if (isPlaying) {
                                        Text("⏸", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    } else {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.Black)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(if (isPlaying) "PAUSAR" else "PLAYER", color = Color.Black, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                // Mute toggle
                                IconButton(onClick = { viewModel.toggleMute() }) {
                                    Text(if (isMuted) "🔇" else "🔊", fontSize = 18.sp)
                                }

                                // Volume Slider
                                Slider(
                                    value = volume,
                                    onValueChange = { viewModel.setVolume(it) },
                                    modifier = Modifier.width(150.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = LyraPrimary,
                                        activeTrackColor = LyraPrimary
                                    )
                                )
                            }

                            // Voice helper tag inside fullscreen
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated.copy(alpha = 0.8f)),
                                shape = RoundedCornerShape(32.dp),
                                onClick = { voicePermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        if (voiceListening) "🔴" else "🎙️",
                                        fontSize = 16.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (voiceListening) "Escutando..." else "Fale 'Lyra TV'",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Standard Portrait Mode Layout with premium Frosted Glass look
        Scaffold(
            containerColor = DarkBackground,
            topBar = {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    DarkBackground,
                                    DarkBackground.copy(alpha = 0.95f)
                                )
                            )
                        )
                        .padding(top = 44.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        Brush.linearGradient(listOf(LyraPrimary, LyraSecondary)),
                                        RoundedCornerShape(12.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Lyra TV Logo",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Lyra TV",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = (-0.5).sp
                                )
                                Text(
                                    text = "AI ENHANCED",
                                    color = LyraPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp
                                )
                            }
                        }

                        // Settings Icon styled with fine glass
                        IconButton(
                            onClick = { showPreferencesDialog = true },
                            modifier = Modifier
                                .background(GlassBgOnly, CircleShape)
                                .border(1.dp, GlassBorderLight, CircleShape)
                                .size(40.dp)
                        ) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = "Personalizar EPG",
                                tint = TextPrimary
                            )
                        }
                    }
                }
            },
            bottomBar = {
                // Bottom voice assistant transcription bar designed as a gorgeous frosted floating plate
                Column(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    DarkBackground.copy(alpha = 0.9f),
                                    DarkBackground
                                )
                            )
                        )
                        .border(1.dp, GlassBorderMuted, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(
                                        if (voiceListening) LyraGlowRed else LyraPrimary,
                                        CircleShape
                                    )
                                    .shadow(4.dp, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (voiceListening) "Escutando Comando..." else "Assistente Lyra TV",
                                    color = if (voiceListening) LyraGlowRed else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = if (voiceTranscript.isNotBlank()) "\"$voiceTranscript\"" else "Fale 'Lyra TV' para sintonizar por voz",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Mic Trigger with Neon Floating Glow Blur Outer shadows
                        Box(contentAlignment = Alignment.Center) {
                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                if (voiceListening) LyraGlowRed.copy(alpha = 0.4f) else LyraPrimary.copy(alpha = 0.25f),
                                                Color.Transparent
                                            )
                                        ),
                                        CircleShape
                                    )
                            )
                            
                            Button(
                                onClick = { voicePermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(
                                        Brush.linearGradient(
                                            colors = if (voiceListening) {
                                                listOf(LyraGlowRed, LyraSecondary)
                                            } else {
                                                listOf(LyraPrimary, LyraSecondary)
                                            }
                                        ),
                                        CircleShape
                                    )
                                    .shadow(8.dp, shape = CircleShape)
                                    .testTag("voice_command_button"),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = if (voiceListening) "📡" else "🎙️",
                                    fontSize = 24.sp
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(DarkBackground)
            ) {
                // 1. Interactive Video Area styled as a floating glass frame
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .border(1.dp, GlassBorderLight, RoundedCornerShape(24.dp))
                            .shadow(16.dp, shape = RoundedCornerShape(24.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            VideoPlayer(
                                streamUrl = currentChannel?.streamUrl,
                                isPlaying = isPlaying,
                                volume = volume,
                                isMuted = isMuted,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Loading Spinner overlay
                            if (isLoading) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.6f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        CircularProgressIndicator(color = LyraPrimary)
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            "IA Sintonizando Sinal Máximo...",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Tiny overlays (Badge + fullscreen trigger)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.TopCenter)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                                        .border(1.dp, GlassBorderLight, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(LyraGlowGreen, CircleShape)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = currentChannel?.name ?: "SEM CANAL",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { viewModel.toggleFullscreen() },
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                        .size(36.dp)
                                        .testTag("full_screen_trigger")
                                ) {
                                    Text(
                                        text = "🖵",
                                        color = Color.White,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Playback Custom Controls Bar (Volume / Play / Mute) wrapped in a Frosted Glass Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .border(1.dp, GlassBorderLight, RoundedCornerShape(24.dp)),
                        colors = CardDefaults.cardColors(containerColor = GlassBgCard),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Channel resolution badge
                                Text(
                                    text = "SINAL HLS • ${currentChannel?.resolution ?: "1080p"} HD",
                                    color = LyraPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )

                                // Favorite status toggle
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { currentChannel?.let { viewModel.toggleFavorite(it) } }
                                ) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = "Favoritar",
                                        tint = if (currentChannel?.isFavorite == true) LyraPrimary else TextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (currentChannel?.isFavorite == true) "Favoritado" else "Favoritar",
                                        color = if (currentChannel?.isFavorite == true) LyraPrimary else TextSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(
                                        onClick = { viewModel.isPlaying.value = !isPlaying },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isPlaying) LyraPrimary else LyraSecondary
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        if (isPlaying) {
                                            Text("⏸", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        } else {
                                            Icon(
                                                Icons.Default.PlayArrow,
                                                contentDescription = "Toggle play",
                                                tint = Color.Black,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            if (isPlaying) "PAUSAR" else "ASSISTIR",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            letterSpacing = 0.5.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    IconButton(
                                        onClick = { viewModel.toggleMute() },
                                        modifier = Modifier
                                            .background(GlassBgOnly, CircleShape)
                                            .size(38.dp)
                                    ) {
                                        Text(if (isMuted) "🔇" else "🔊", fontSize = 16.sp)
                                    }
                                }

                                // Horizontal micro volume feedback slider
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.width(120.dp)
                                ) {
                                    Text("🔈", fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Slider(
                                        value = volume,
                                        onValueChange = { viewModel.setVolume(it) },
                                        modifier = Modifier.weight(1f),
                                        colors = SliderDefaults.colors(
                                            thumbColor = LyraPrimary,
                                            activeTrackColor = LyraPrimary,
                                            inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Status notifications overlays
                item {
                    Column {
                        AnimatedVisibility(visible = statusMsg != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LyraPrimary.copy(alpha = 0.25f))
                                    .padding(vertical = 10.dp, horizontal = 16.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Info, contentDescription = "Status", tint = LyraPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(statusMsg ?: "", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        AnimatedVisibility(visible = errorMsg != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LyraGlowRed.copy(alpha = 0.3f))
                                    .padding(vertical = 10.dp, horizontal = 16.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = "Erro", tint = LyraGlowRed, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(errorMsg ?: "", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // 3. AI Channel Sintonizer Search Bar with modern layout and outline adjustments
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "SINTONIZADOR INTELIGENTE POR IA",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Nome do canal (ex: History, CNN, Esportes)", color = TextSecondary, fontSize = 13.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("channel_search_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = LyraPrimary,
                                    unfocusedBorderColor = GlassBorderLight,
                                    focusedContainerColor = GlassBgCard,
                                    unfocusedContainerColor = GlassBgOnly,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(16.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = {
                                    if (searchQuery.isNotBlank()) {
                                        viewModel.tuneChannelIntelligently(searchQuery)
                                        searchQuery = ""
                                    }
                                })
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Button(
                                onClick = {
                                    if (searchQuery.isNotBlank()) {
                                        viewModel.tuneChannelIntelligently(searchQuery)
                                        searchQuery = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = LyraPrimary),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .height(56.dp)
                                    .testTag("search_action_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = "Sintonizar", tint = Color.Black)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("IA", color = Color.Black, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }

                // 4. Panel Tabs (Canais vs Personalized EPG) styled inside a Frosted Glass Container
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .border(1.dp, GlassBorderMuted, RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = GlassBgOnly),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        TabRow(
                            selectedTabIndex = selectedTabIndex,
                            containerColor = Color.Transparent,
                            contentColor = LyraPrimary,
                            indicator = { tabPositions ->
                                TabRowDefaults.SecondaryIndicator(
                                    Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                    color = LyraPrimary
                                )
                            },
                            divider = {}
                        ) {
                            Tab(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                text = { Text("CANAIS SALVOS (${channels.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                            )
                            Tab(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                text = { Text("MEU GUIA DE TV (IA)", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                // Tab Content Rendering
                if (selectedTabIndex == 0) {
                    // Canais Tab List
                    if (channels.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Info, contentDescription = "Vazio", tint = TextSecondary, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "Nenhum canal sintonizado ainda.",
                                    color = TextSecondary,
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    "Digite no sintonizador acime ou aperte o microfone!",
                                    color = LyraPrimary,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        // Section: Favoritos
                        if (favorites.isNotEmpty()) {
                            item {
                                Text(
                                    text = "FAVORITOS ESTRELA",
                                    color = LyraPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(top = 16.dp, start = 16.dp, end = 16.dp)
                                )
                            }
                            items(favorites) { channel ->
                                ChannelItemRow(
                                    channel = channel,
                                    isSelected = currentChannel?.id == channel.id,
                                    onSelect = { viewModel.selectChannel(channel) },
                                    onFavorite = { viewModel.toggleFavorite(channel) },
                                    onDelete = { viewModel.deleteChannel(channel) }
                                )
                            }
                        }

                        // Section: Outros canais
                        val othersComp = channels.filter { !it.isFavorite }
                        if (othersComp.isNotEmpty()) {
                            item {
                                Text(
                                    text = "HISTÓRICO DE SINTONIAS",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(top = 16.dp, start = 16.dp, end = 16.dp)
                                )
                            }
                            items(othersComp) { channel ->
                                ChannelItemRow(
                                    channel = channel,
                                    isSelected = currentChannel?.id == channel.id,
                                    onSelect = { viewModel.selectChannel(channel) },
                                    onFavorite = { viewModel.toggleFavorite(channel) },
                                    onDelete = { viewModel.deleteChannel(channel) }
                                )
                            }
                        }
                    }
                } else {
                    // Personalized EPG Tab List
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "GRADE DE PROGRAMAÇÃO DIPLOMÁTICA",
                                        color = LyraPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Interesses: $prefInput",
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Button(
                                    onClick = { viewModel.generateEpgForChannels(channels) },
                                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    if (isEpgRefreshing) {
                                        CircularProgressIndicator(color = LyraPrimary, modifier = Modifier.size(12.dp), strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Default.Refresh, contentDescription = "Atualizar", tint = Color.White, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("RE-GERAR", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    if (epgList.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("📺", fontSize = 44.sp)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "Ainda sem canais suficientes para listar programas.",
                                    color = TextSecondary,
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        items(epgList) { channelEpg ->
                            ChannelEpgCard(channelEpg = channelEpg)
                        }
                    }
                }

                // Add blank layout pad for list comfort
                item {
                    Spacer(modifier = Modifier.height(100.dp))
                }
            }
        }
    }

    // Modal preferences dialgoue to alter EPG interest tags
    if (showPreferencesDialog) {
        AlertDialog(
            onDismissRequest = { showPreferencesDialog = false },
            title = {
                Text(
                    "PREFERÊNCIAS DE SINTONIA IA",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Digite abaixo os assuntos e gêneros que você gosta para personalizar sua grade do canal EPG de hoje por IA:",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = prefInput,
                        onValueChange = { prefInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("preferences_dialog_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = LyraPrimary,
                            unfocusedBorderColor = DarkSurfaceElevated,
                            focusedContainerColor = DarkBackground,
                            unfocusedContainerColor = DarkBackground
                        ),
                        placeholder = { Text("Ex: Astronomia, Notícias de Tecnologia, Esportes de Aventura", color = TextSecondary) }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveUserPreference(prefInput)
                        showPreferencesDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LyraPrimary)
                ) {
                    Text("SALVAR", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPreferencesDialog = false }) {
                    Text("CANCELAR", color = Color.White)
                }
            },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun ChannelItemRow(
    channel: SavedChannel,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onSelect() }
            .testTag("channel_row_${channel.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0x2BFFFFFF) else GlassBgCard
        ),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp, 
            if (isSelected) LyraPrimary.copy(alpha = 0.8f) else GlassBorderLight
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = channel.name,
                        color = if (isSelected) LyraPrimary else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) LyraPrimary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.08f),
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = channel.resolution,
                            color = if (isSelected) LyraPrimary else TextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Categoria: ${channel.category}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onFavorite) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = "Favorito",
                        tint = if (channel.isFavorite) LyraPrimary else TextSecondary.copy(alpha = 0.35f)
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Excluir",
                        tint = TextSecondary.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
fun ChannelEpgCard(channelEpg: ChannelEpg) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .border(1.dp, GlassBorderLight, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = GlassBgCard),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📺", fontSize = 16.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = channelEpg.channelName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sequence of 3 shows
            channelEpg.programs.forEachIndexed { index, show ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.width(55.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = show.time,
                            color = if (index == 0) LyraPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    if (index == 0) LyraPrimary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.08f),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${show.durationMin}m",
                                color = if (index == 0) LyraPrimary else TextSecondary,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = show.title,
                            color = if (index == 0) LyraPrimary else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        
                        if (index == 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            // Sleek Frosted Progress bar under first show (HTML: w-full bg-white/10 h-1 rounded-full overflow-hidden -> cyan-500 indicator)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .height(4.dp)
                                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(2.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.75f)
                                        .background(LyraPrimary, RoundedCornerShape(2.dp))
                                        .fillMaxHeight()
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Text(
                            text = show.description,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Progress bar indicator for current active show
                    if (index == 0) {
                        Box(
                            modifier = Modifier
                                .padding(start = 6.dp, top = 4.dp)
                                .background(LyraPrimary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "LIVRE",
                                color = LyraPrimary,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (index < channelEpg.programs.size - 1) {
                    HorizontalDivider(color = GlassBorderMuted, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
    }
}
